# Data availability — credit-supply EER R&R

## Statement of data availability

The analysis panel underlying this paper is derived from three **proprietary, non-redistributable** data products:

1. **DealScan / LPC LoanConnector** (Refinitiv) — syndicated loan microdata, 2000–2024.
2. **Compustat North America + Compustat Global + CRSP** (S&P / Wharton Research Data Services) — firm-level fundamentals.
3. **Trucost environment subset** (S&P Global Sustainable1) — firm-year scope-1/2/3 emissions and emission intensities.

The source data and all record-level datasets derived from them are subject to contractual redistribution restrictions and are not included in this public package. Source-specific construction programs also contain protected field-identification and entity-matching information.

A separate **construction-code package** is available to researchers who independently demonstrate licensed access to all three data products, subject to the providers' terms. That package does not contain source or derived data. The public package contains provider-neutral final-model programs and the verified published outputs.

<!-- TODO(bhavyaa, pre-deposit 2026-11-19): fill in the three bracketed
     fields below once the EER data editor has (a) received the three-tier
     cover letter in release_tiered/EER_COVER_LETTER_DRAFT.md and (b)
     returned written approval of the construction-code restriction. Until
     this bullet is filled in, the PUBLICATION_CHECKLIST.md EER-approval
     box stays unchecked. -->
This arrangement has been proposed to the EER data editor on `[DATE PROPOSED]` and approved on `[DATE APPROVED]` (reference: `[EER TICKET]`).

## Access to proprietary data

Interested researchers must independently obtain licensed access to each source:

### DealScan / LPC LoanConnector
- Vendor: Refinitiv (LSEG Data & Analytics).
- Product: LoanConnector / DealScan syndicated-loan microdata, 2000–2024 vintage used here.
- How to purchase or renew: contact LSEG account management; typical turnaround 2–8 weeks.

### Compustat North America + Compustat Global + CRSP
- Vendor: Wharton Research Data Services (WRDS), S&P Global Market Intelligence, CRSP (University of Chicago Booth).
- Products used: Compustat NA annual (`compustat_na`, fyear 2004–2023), Compustat Global annual (`compustat_global`, fyear 2004–2023), Compustat quarterly (NA + Global, 2000–2024), CRSP annual stock file (merged firm-year table).
- Access path: WRDS subscription via the researcher's institution.

### Trucost environment subset
- Vendor: S&P Global Sustainable1 / Trucost.
- Product: firm-year emissions + intensity subset (variables documented in `01_trucost/trucost_methodology.md` inside the licensed construction-code package, once that package is received).
- Access path: S&P Market Intelligence or direct S&P Global negotiation; typical 6–12 weeks for institutional sign-off.

## Ancillary public inputs (no license required)

The following inputs are public and ship with the licensed construction-code package. Each is consumed only in the panel-building stages (01–05); the neutral analysis input that the public tier reads never carries any of these columns directly.

- **World Bank GDP deflator series** (`WB_deflator.xlsx`, World Bank Open Data, World Development Indicators). Used in `build_regression_panel.R` to deflate loan amounts and Compustat revenue, which feeds the `revenue_deflated` column that the firm-level emission-intensity denominators ultimately use. Series key: `NY.GDP.DEFL.ZS`, cross-country, 2004–2023.
- **OECD STAN industry database** (`oecd_stan_data.csv`, OECD). Used by `add_stan_intensity_to_trucost.R` + `add_stan_intensity_to_panel.R` to build the STAN value-added producer deflator (`valp_deflator`), which produces the `_stan` family of emission-intensity columns used in the STAN robustness (OA Table family `..._stan.tex`).
- **NUTS 2010 postcode gazetteers** (Eurostat, 2016 vintage) — EU firm-location attachment.
- **LAU 2010, 2017, 2024** (Eurostat) — local administrative unit codes for the NUTS-2 ILST robustness.
- **UK LAU** (Office for National Statistics) — UK coverage for the LAU attach.
- **NZBA roster** (Net Zero Banking Alliance official membership list, matched to DealScan lender names by hand — the hand-matching is retained in the licensed tier as it is source-specific).

## Requesting the construction-code package

Researchers who can demonstrate licensed access to all three proprietary sources may request the construction-code package from:

- Bhavyaa Sharma (Stockholm School of Economics - Bhavyaa.Sharma@hhs.se)
- Please include evidence of licensing for each of DealScan, Compustat/CRSP, and Trucost (an account-manager email, a WRDS subscription confirmation, or equivalent).
- The authors will verify licensing status with each provider before any script is transmitted.

Requests for the final analysis data itself (`analysis_input.rds`) can also be made via the same channel, subject to EER data-editor approval and the providers' terms.

## What this package contains

- Provider-neutral final-model code under `code/`.
- Schema documentation at `docs/NEUTRAL_SCHEMA.md`.
- Verified published outputs under `output/` (the exact `.tex` fragments and figures that appear in the manuscript).
- Pre-deposit disclosure scanner at `scan_public_disclosure.sh`.

## What this package does not contain

- Any record-level data from DealScan, Compustat/CRSP, or Trucost.
- Any crosswalk (DealScan↔Compustat, NUTS↔LAU, lender↔NZBA, firm↔NAICS).
- Any source-specific field-selection or entity-matching code.
- The hand-matched NZBA↔DealScan roster.
- The Aldasoro lender filter.
- The source↔neutral ID mapping.
