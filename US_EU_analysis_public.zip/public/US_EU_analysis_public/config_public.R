# ==============================================================================
# config_public.R — paths for the public analysis tier.
#
# All runners under code/06_run_regressions/, code/07_wild_bootstrap/, and
# code/08_build_tables_and_figures/ source this file. It locates the neutral
# `analysis_input.rds` produced by the licensed-scripts tier and the output
# directories under `output/`.
#
# The public tier ships without a data file. A licensed researcher must
# produce `data/analysis_input.rds` by running
# `../licensed_scripts/run_all_licensed.sh` before any public runner can
# execute. See `DATA_AVAILABILITY.md` and `README.md`.
# ==============================================================================

if (Sys.getenv("REPL_ROOT") == "") {
    .find_root <- function(start = getwd()) {
        d <- normalizePath(start, mustWork = FALSE)
        while (d != dirname(d)) {
            if (file.exists(file.path(d, "config_public.R"))) return(d)
            d <- dirname(d)
        }
        stop("Could not locate public tier root. Set REPL_ROOT env var.")
    }
    REPL_ROOT <- .find_root()
} else {
    REPL_ROOT <- Sys.getenv("REPL_ROOT")
}

CODE_DIR    <- file.path(REPL_ROOT, "code")
OUT_TABLES  <- Sys.getenv("OUT_TABLES",  file.path(REPL_ROOT, "output", "tables"))
OUT_FIGURES <- Sys.getenv("OUT_FIGURES", file.path(REPL_ROOT, "output", "figures"))
LOGS_DIR    <- Sys.getenv("LOGS_DIR",    file.path(REPL_ROOT, "logs"))

NEUTRAL_INPUT_PATH <- Sys.getenv(
    "ANALYSIS_INPUT_RDS",
    file.path(REPL_ROOT, "data", "analysis_input.rds")
)

# ------------------------------------------------------------------------------
# Back-compat aliases for a few symbols the stage-06 runners still reference.
# They point at the SAME neutral data file; nothing proprietary.
# ------------------------------------------------------------------------------
NEUTRAL_PANEL <- NEUTRAL_INPUT_PATH
DATA_INTER    <- file.path(REPL_ROOT, "data")  # for incidental small lookups
