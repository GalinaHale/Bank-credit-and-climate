# Exhibit manifest

Mapping from every table and figure that appears in the manuscript (main body + online appendix) to the artifact shipped in this repository and how it is produced.

**Legend**
- *regenerated*: the shipped `.tex` / `.pdf` is reproduced end-to-end from `data/analysis_input.rds` by running `bash run_all.sh`.
- *static*: shipped as a verified copy from the author's build. The public tier does not currently rebuild it end-to-end. See `README.md → What this tier does NOT rebuild`.

Table numbers reflect the current manuscript draft; the shipped `.tex` names are the raw internal names the stage-06 R runners and stage-08 Python chain emit.

## Main body — tables

| Exhibit | Shipped artifact | Status | Generator |
|---|---|---|---|
| Table 1 — US vs EU summary symbols | `output/tables/table1_summary_us_eu_revision.tex` | static | author/coauthor-side builder (not in this tier) |
| Table 2 — reg1 (firm-level intensity) | `output/tables/reg1_us4b_eu_country2b.tex` | regenerated | `code/06_run_regressions/run_new_benchmark_ilst.R` → stage-08 polish |
| Table 3 — reg2 (industry-relative intensity) | `output/tables/reg2_us4b_eu_country2b.tex` | regenerated | `run_new_benchmark_ilst.R` → stage-08 polish |
| Table 4 — reg3 brown subset | `output/tables/reg3brown_us4b_eu_country2b.tex` | regenerated | `run_new_benchmark_ilst.R` → stage-08 polish |
| Table 5 — reg4 non-brown subset | `output/tables/reg4nonbrown_us4b_eu_country2b.tex` | regenerated | `run_new_benchmark_ilst.R` → stage-08 polish |
| Table 6 — reg5 between-industry | `output/tables/reg5_between_us4b_eu_country2b.tex` | regenerated | `run_new_benchmark_reg5_lst.R` → stage-08 polish |
| Table 7 — WILDBS p-values (B = 500) | `output/tables/reg{1..5}_us4b_eu_country2b_WILDBS_B500.tex` | regenerated | `code/08_build_tables_and_figures/build_wildbs_tables.py` pivots the shipped CSV at `code/07_wild_bootstrap/results_csv/wildbs_pvalues_B500.csv` |

## Main body — figures

| Exhibit | Shipped artifact | Status | Generator |
|---|---|---|---|
| Figure 1 — scope-1 intensity density ridge | `output/figures/scope1_intensity_density_ridge_by_region_brown.pdf` | static | `plot_emission_intensity_distributions.R` (licensed construction-code package) |
| Figure 2 — US within-industry forest | `output/figures/fig_within_forest_us_fixed.pdf` | static | coauthor-side forest-plot builder (not in this tier) |
| Figure 3 — EU within-industry forest | `output/figures/fig_within_forest_eu_fixed.pdf` | static | coauthor-side forest-plot builder |
| Figure 4 — US+EU between-industry forest | `output/figures/fig_between_forest_us_eu_fixed.pdf` | static | coauthor-side forest-plot builder |
| Figure (dispersion time-series) | `output/figures/scope1_intensity_dispersion_timeseries.pdf` | static | companion plot script in the licensed package; input snapshot in `output/figures/scope1_intensity_dispersion_snapshot.csv` |

## Online appendix — tables

| Exhibit | Shipped artifact | Status | Generator |
|---|---|---|---|
| A.1 — summary stats (full sample) | `output/tables/summary_stats_full.tex` | static | `summary_stats_A1_A2_replication.R` (licensed package; reads unexported contemporaneous columns) |
| A.2 — summary stats (US / EU split) | `output/tables/summary_stats_us.tex`, `summary_stats_eu.tex` | static | same as A.1 |
| A.3 — sample funnel (DealScan → +Compustat → +Trucost) | `output/tables/sample_funnel_{us,eu,all}.tex` + `sample_funnel_counts.csv` | static | `build_sample_funnel.R` (licensed package) |
| A.5 / A.6 — US bucket-2 variants of reg1-5 | `output/tables/reg{1..5}_us2b_eu_country2b.tex` | regenerated | `run_new_benchmark_ilst.R` + `run_new_benchmark_reg5_lst.R` |
| A.7 — Scope-2 on Scope-1 diagnostic | `output/tables/scope2_on_scope1_intensity.tex` | regenerated | `run_scope2_on_scope1.R` → stage-08 polish |
| A.8 — D.1.3 NUTS static robustness (10 fragments) | `output/tables/us_eu_loan_loggr_regs_*_ilst_nuts{2,3}_2010.tex` | static | author-only runner (licensed `author_only_runners/run_ilst_nuts_regs.R`) |
| A.8-variant — ROBUST NUTS-2 tables (6 fragments) | `output/tables/reg{4nonbrown,5_between}_us{4b,2b}_eu_nuts2_4b_ROBUST{,_age}.tex` | regenerated | `run_new_benchmark_ilst.R` / `run_new_benchmark_reg5_lst.R` / `run_new_benchmark_ilst_age.R` |
| A.9 — bank × industry × year (NZBA × Paris) | `output/tables/bank_industryyear_nonbrown_nzba_paris.tex` | regenerated | `run_bank_industryyear_regs.R` |
| D.1.4 — continuous firm-age robustness (reg1-5 × {4b,2b}) | `output/tables/reg{1..5}_us{4b,2b}_eu_country2b_age.tex` | regenerated (partial) | `run_new_benchmark_ilst_age.R`. The brown-subset specs can exhibit "all variables collinear with FE" on the small post-ILST cell structure (see `project_firm_age_collinear_under_new_ilst` note); those specific tables may fall back to the shipped static copy. |
| E — age-dummy robustness (gt10 + pooled median) | `output/tables/reg{1..5}_us4b_eu_country2b_age_{gt10,median}.tex` | regenerated | `run_new_benchmark_age_dummies.R` |
| FT p90 + time-varying brown | `output/tables/reg{3brown,4nonbrown}_us4b_eu_country2b_{ft_p90,tv}.tex` | regenerated | `run_new_benchmark_thresholds.R` |
| STAN-deflated intensity | `output/tables/reg{1..5}_us4b_eu_country2b_stan.tex` | regenerated | `run_new_benchmark_stan.R`. Deflator inputs: OECD STAN value-added producer deflator + World Bank GDP deflator; both are public and documented in `DATA_AVAILABILITY.md` ("Ancillary public inputs"). The deflators enter upstream in the licensed panel build (`build_regression_panel.R` and `add_stan_intensity_to_*`) — not in this public tier's code — and the neutral panel only carries the already-deflated `_stan` family of intensity columns. |
| drop-2020 | `output/tables/reg{1..5}_us4b_eu_country2b_no2020.tex` | regenerated | `run_new_benchmark_no2020.R` |
| Scope 1+2 sum | `output/tables/reg{1..5}_us4b_eu_country2b_scope12.tex` | regenerated | `run_new_benchmark_scope12sum.R` |
| OA Section C (without-ILST) — 9 fragments | `output/tables/withoutILST/*.tex` | static | end-to-end builder lives in the full replication package; planned port into this tier |

## How to regenerate

- Run everything the public tier regenerates:
  ```bash
  export REPL_ROOT="$(pwd)"
  bash run_all.sh
  ```
- Run just one regression family (example):
  ```bash
  Rscript code/06_run_regressions/run_new_benchmark_ilst.R
  ```
- Verify end-to-end with a classified byte-diff against the bundled reference:
  ```bash
  bash verify_clean_run.sh
  ```

See `README.md` for the full pipeline description and `docs/NEUTRAL_SCHEMA.md` for the data contract.
