# --- portability shim ---
import os
from pathlib import Path
_REPL_ROOT = os.environ.get("REPL_ROOT")
if not _REPL_ROOT:
    _REPL_ROOT = str(Path(__file__).resolve().parent.parent.parent)
_TABLES_DIR = os.environ.get("OUT_TABLES", str(Path(_REPL_ROOT) / "output" / "tables"))
# --- end shim ---

#!/usr/bin/env python3
"""Insert a US / EU panel header into each etable .tex fragment.

For every .tex file under output/tables/tables_vJun2026_ILSTbenchmark/, the
fixest etable output has 8 data columns: cols 1-4 are the U.S. sub-sample
and cols 5-8 the EU sub-sample, but the table itself only labels them by
outcome ("Loan Amount (Growth)", ...). We insert a panel-header row
immediately after the toprule so the U.S./EU split is visible inside each
table.

The insertion is idempotent: files already containing "Panel A: U.S." in
the header are skipped.
"""
from pathlib import Path

ROOT = Path(_TABLES_DIR)

HEADER_LINES = [
    r"   & \multicolumn{4}{c}{\textbf{Panel A: U.S.\ sample}} "
    r"& \multicolumn{4}{c}{\textbf{Panel B: EU sample}}\\",
    r"   \cmidrule(lr){2-5}\cmidrule(lr){6-9}",
]
MARKER = "Panel A: U.S."

def patch_file(path):
    text = path.read_text()
    if MARKER in text:
        return "skip (already patched)"
    if r"\toprule" not in text:
        return "skip (no toprule)"
    # Only the wide 9-col etable output gets the US/EU panel header.
    # Summary tables (5-col `lcccc`) and other shapes must NOT be patched
    # because the multicolumn spans below assume 8 data columns. Look for
    # the tabular column spec line and require it to declare 9 cells.
    is_nine_col = "{lcccccccc}" in text
    if not is_nine_col:
        return "skip (not 9-column tabular)"
    lines = text.splitlines()
    out = []
    inserted = False
    for line in lines:
        out.append(line)
        if not inserted and r"\toprule" in line:
            out.extend(HEADER_LINES)
            inserted = True
    if not inserted:
        return "skip (insertion failed)"
    path.write_text("\n".join(out) + "\n")
    return "patched"

def main():
    files = sorted(ROOT.glob("*.tex"))
    if not files:
        print("No .tex files in", ROOT)
        return
    for f in files:
        status = patch_file(f)
        print("  ", f.name.ljust(60), status)

if __name__ == "__main__":
    main()
