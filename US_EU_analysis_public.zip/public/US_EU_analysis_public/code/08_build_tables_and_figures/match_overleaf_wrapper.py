#!/usr/bin/env python3
"""Match each output .tex fragment's WRAPPER (everything outside the tabular)
to the corresponding Overleaf reference fragment. Preserves my tabular content
(coefficients + stars from the current post-Aldasoro sample) while adopting
Overleaf's exact caption / notes / scalebox / resizebox choice per table.

The Overleaf reference at Revision_Tables/US-EU_analysis/tables/ uses two
different templates depending on the table:

  Style A  (main reg1-5, WILDBS_B500):
      \\begingroup ... \\sbox1{\\footnotesize \\begin{tabular}...\\end{tabular}}%
      \\sbox0{\\scalebox{0.8}{\\usebox1}}%
      \\ifdim\\wd0>\\textwidth \\sbox0{\\resizebox{\\textwidth}{!}{\\usebox1}}% \\fi
      ...\\minipage{\\wd0} ... \\textit{Notes:} ... \\endgroup

  Style B  (robustness _stan, _no2020, _scope12, _age_gt10/_age_median,
            _WILDBS, _ft_p90, _tv, _p90):
      \\begin{table}[H]
      \\centering \\caption{...} \\label{...}
      \\resizebox{\\textwidth}{!}{%\\begin{tabular}...\\end{tabular}%\\ ...}
      \\begin{minipage}{\\textwidth} \\vspace{0.5em}
      \\footnotesize \\emph{Notes:} ...
      \\end{minipage} \\end{table}

For every fragment in OUT_TABLES that has a same-named Overleaf reference, we
replace my wrapper with the reference's wrapper and swap in my tabular. Where
my fragment has no reference counterpart, we leave it unchanged.

Idempotent: safe to run repeatedly.
"""
import os, re
from pathlib import Path

_REPL_ROOT = os.environ.get("REPL_ROOT")
if not _REPL_ROOT:
    _REPL_ROOT = str(Path(__file__).resolve().parent.parent.parent)
_TABLES_DIR = os.environ.get("OUT_TABLES",
                             str(Path(_REPL_ROOT) / "output" / "tables"))

# Wrapper reference directory — the source of truth for Style A / Style B
# wrapper templates. For a clean replication deploy, the package ships a
# frozen copy under tables_reference/. OVERLEAF_REFERENCE_DIR overrides
# (used locally when pulling live wrapper edits from a separate reference
# tree). Stage-08 run.sh only invokes this script when one of the two is
# available, so REF_DIR is always resolvable here.
_PKG_REFERENCE = Path(_REPL_ROOT) / "tables_reference"
REF_DIR = Path(os.environ.get("OVERLEAF_REFERENCE_DIR", str(_PKG_REFERENCE)))
OUT_DIR = Path(_TABLES_DIR)

TAB_RE = re.compile(
    r"\\begin\{tabular\}[\s\S]*?\\end\{tabular\}",
    re.DOTALL,
)


def swap_tabular(reference_text: str, my_tabular: str) -> "str | None":
    """Return reference_text with its tabular replaced by my_tabular.
       Returns None if the reference doesn't contain a tabular block."""
    m = TAB_RE.search(reference_text)
    if not m:
        return None
    return reference_text[: m.start()] + my_tabular + reference_text[m.end() :]


def main() -> None:
    if not REF_DIR.exists():
        print(f"[skip] reference dir does not exist: {REF_DIR}")
        return

    n_replaced = 0
    n_no_ref = 0
    n_no_tab = 0

    for path in sorted(OUT_DIR.glob("*.tex")):
        # WILDBS fragments are built self-contained by
        # build_wildbs_tables.py (with the current significance-tier
        # footer and family-specific hand-written prose). The frozen
        # tables_reference copies lag behind the builder, so swapping
        # in the reference wrapper would downgrade the footer. Skip.
        if "WILDBS" in path.name:
            continue
        ref_path = REF_DIR / path.name
        if not ref_path.exists():
            n_no_ref += 1
            continue

        my_text = path.read_text()
        my_tab = TAB_RE.search(my_text)
        if not my_tab:
            n_no_tab += 1
            print(f"[skip] no tabular in mine: {path.name}")
            continue

        ref_text = ref_path.read_text()
        merged = swap_tabular(ref_text, my_tab.group(0))
        if merged is None:
            n_no_tab += 1
            print(f"[skip] no tabular in ref: {path.name}")
            continue

        if merged == my_text:
            continue

        path.write_text(merged)
        print(f"[wrapped] {path.name}")
        n_replaced += 1

    print(
        f"\n# wrapped from Overleaf reference: {n_replaced}   "
        f"no-ref: {n_no_ref}   no-tabular: {n_no_tab}"
    )


if __name__ == "__main__":
    main()
