#!/usr/bin/env bash
# Stage 08 — assemble final .tex fragments and figures.
#
# fail-fast: each builder either produces a correct output or we stop. The
# earlier `|| echo FAILED (continuing)` guards let a failed builder leave
# stale .tex in output/tables that downstream Overleaf copies would then
# treat as current.
set -euo pipefail
cd "$(dirname "$0")/../.."
export REPL_ROOT="$(pwd)"
mkdir -p "${OUT_TABLES:-$REPL_ROOT/output/tables}" "$REPL_ROOT/output/figures"

echo "[08] build_summary_tables_vJun2026.py"
python3 code/08_build_tables_and_figures/build_summary_tables_vJun2026.py

echo "[08] build_wildbs_tables.py"
python3 code/08_build_tables_and_figures/build_wildbs_tables.py

# plot_emission_intensity_distributions.R reads the raw Trucost intermediate
# and lives in the licensed construction-code package (see
# DATA_AVAILABILITY.md). The verified published Figure
# (scope1_intensity_density_ridge_by_region_brown.pdf) ships in
# output/figures/ for the public tier.

echo "[08] polish_etable_output.py (rename Loan Amount (Growth) → Loan Growth; round R² to 2dp)"
python3 code/08_build_tables_and_figures/polish_etable_output.py

echo "[08] insert_us_eu_panel_header.py (add Panel A / Panel B multicolumn header)"
python3 code/08_build_tables_and_figures/insert_us_eu_panel_header.py

echo "[08] inline_notes_scalebox.py — applying transform"
python3 code/08_build_tables_and_figures/inline_notes_scalebox.py

# match_overleaf_wrapper.py pulls table wrappers from a frozen reference tree
# (public tier now bundles this at $REPL_ROOT/tables_reference/, added
# 2026-11-19). The wrapper match ensures each regenerated .tex adopts the
# exact Style A / Style B wrapper the paper uses, rather than the default
# etable wrapper. Invoked when EITHER:
#   - OVERLEAF_REFERENCE_DIR is set (author-side live-Overleaf pull), or
#   - $REPL_ROOT/tables_reference/ exists (public tier default).
# The Python script's own logic picks between the two (env override first,
# then bundled fallback); we only gate the invocation itself.
if [ -n "${OVERLEAF_REFERENCE_DIR:-}" ] && [ -d "$OVERLEAF_REFERENCE_DIR" ]; then
    echo "[08] match_overleaf_wrapper.py — using OVERLEAF_REFERENCE_DIR=$OVERLEAF_REFERENCE_DIR"
    python3 code/08_build_tables_and_figures/match_overleaf_wrapper.py
elif [ -d "$REPL_ROOT/tables_reference" ]; then
    echo "[08] match_overleaf_wrapper.py — using bundled tables_reference/"
    python3 code/08_build_tables_and_figures/match_overleaf_wrapper.py
else
    echo "[08] match_overleaf_wrapper.py — skipped (no wrapper reference directory)"
fi

echo "[08] suppress_nonconv_cells.py — inject Non-convergence footnote on flagged tables"
python3 code/08_build_tables_and_figures/suppress_nonconv_cells.py

echo "[08] finalize_table_formatting.py — enforce Notes-active / justified / no \\bottomrule\\\\ padding"
python3 code/08_build_tables_and_figures/finalize_table_formatting.py

# The public tier never mirrors to an external Overleaf path. The former
# OVERLEAF_TABLES_DIR optional mirror lived in the author's internal
# workflow; it is not part of the public replication package.
