# Stage 08 — build tables and figures

## What this stage does

Takes the raw `etable` `.tex` fragments that Stage 06 wrote and the WILDBS CSV that Stage 07 produced (or ships pre-computed), and applies the paper's final-formatting chain: labels, panel headers, scalebox, Overleaf wrapper styles, and non-convergence footnotes.

All builders are pure **Python standard-library** scripts (no pandas/numpy). No R script in this stage runs on the public tier.

## Scripts (invoked in order by `run.sh`)

| # | Script | What it does |
|---|---|---|
| 1 | `build_summary_tables_vJun2026.py` | Builds the Table 1 / within / between summary fragments from stage-06 etable outputs. Imports parser/helper functions from `build_summary_tables.py` (helpers-only module). |
| 2 | `build_wildbs_tables.py` | Reads `code/07_wild_bootstrap/results_csv/wildbs_pvalues_B500.csv` and pivots it into `reg{1..5}_us4b_eu_country2b_WILDBS_B500.tex`. |
| 3 | `polish_etable_output.py` | Renames `Loan Amount (Growth)` → `Loan Growth`; rounds `R²` to 2dp; cleans up fixest's default column labels. |
| 4 | `insert_us_eu_panel_header.py` | Adds the `\textbf{Panel A: U.S.\ sample}` / `\textbf{Panel B: EU sample}` multicolumn header + `\cmidrule` to the regression tables. |
| 5 | `inline_notes_scalebox.py` | Wraps the body in `\sbox` + `\scalebox{0.8}`, moves the Notes block into a `\begin{minipage}{\wd0}` block. (Style A wrapper.) |
| 6 | `match_overleaf_wrapper.py` | Adopts the Style A or Style B wrapper per table by looking up the matching file in `tables_reference/` (bundled with the package). `OVERLEAF_REFERENCE_DIR` env var overrides to a live reference tree. |
| 7 | `suppress_nonconv_cells.py` | Injects the `Non-convergence` footnote in tables where feglm_safe flagged the fit. |
| 8 | `finalize_table_formatting.py` | Enforces per-table rules: Notes-active vs commented, `\raggedright`/`\centering` policy, no `\bottomrule\\` padding. |

## Outputs

- `output/tables/*.tex` — in-place polish of the stage-06 regression fragments plus the newly-built `*_WILDBS_B500.tex` and `summary_stats_{us,eu}.tex`.
- `output/figures/` — not touched. Figures 2–4 and the scope-1 density ridge ship as static PDFs in the public tier; the R production scripts live in the Tier-2 package.

## No external copy-out

The public tier never mirrors tables to an external Overleaf path. The former `OVERLEAF_TABLES_DIR` mirror step belonged to the author's internal workflow and is no longer present in this tier's `run.sh`.

## Wall clock

~2 minutes end-to-end.
