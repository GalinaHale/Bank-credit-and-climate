# --- portability shim ---
import os
from pathlib import Path
_REPL_ROOT = os.environ.get("REPL_ROOT")
if not _REPL_ROOT:
    _REPL_ROOT = str(Path(__file__).resolve().parent.parent.parent)
    os.environ["REPL_ROOT"] = _REPL_ROOT
REPL_ROOT = Path(_REPL_ROOT)
CSV_DIR = REPL_ROOT / "code" / "07_wild_bootstrap" / "results_csv"
OUT_DIR = REPL_ROOT / "output" / "tables"
# --- end shim ---

#!/usr/bin/env python3
"""
build_wildbs_tables.py
----------------------
Turn wildbs_pvalues_B{B}.csv into 5 self-contained .tex fragments -- one per
regression family (reg1, reg2, reg3brown, reg4nonbrown, reg5). Same portrait
scalebox(0.8) + inline-notes template as the main benchmark fragments.

CSV schema (post 2026-07 patch): columns family, panel, parameter, side
(= "pre" | "post" | "" for controls), then the per-outcome (b, se, t, p_wcr,
p_wcu, err) blocks for g/h and (b, se, p_pairs, err) for i/l.

12 rows per family per panel: 4 firm controls + 8 Paris interactions
(2 sides x 4 base intensity vars). Layout mirrors the benchmark fragment
row order. Coefs/SEs come from the analytic fixest fit; stars come from
p_wcr (feols) / p_pairs (feglm).
"""

import csv
import os
import math
import re

# ----- config -----
FRAG_DIR = str(OUT_DIR)
B = 500
CSV_IN = os.path.join(FRAG_DIR, f"wildbs_pvalues_B{B}.csv")

# ----- row labels (verbatim from benchmark fragments) -----
CONTROL_LABELS = [
    ("ln_totalassets_lag",           "",     r"Log (Total Assets)$_{t-1}$"),
    ("leverage_ratio_lag",           "",     r"Leverage Ratio$_{t-1}$"),
    ("capex_totalassets_ratio_lag",  "",     r"CAPEX$/$Total Assets$_{t-1}$"),
    ("ebitda_assets_ratio_lag",      "",     r"EBITDA$/$Total Assets$_{t-1}$"),
]

PARIS_ROWS_REG1 = [
    ("scope1_log_intensity_lag",      "pre",  r"Log (Intensity)$_{t-1} (Scope 1)$ $\times$ Pre-Paris"),
    ("scope1_log_intensity_lag",      "post", r"Log (Intensity)$_{t-1}(Scope 1)$ $\times$ Post-Paris"),
    ("scope2_log_intensity_lag",      "pre",  r"Pre-Paris $\times$ Log (Intensity)$_{t-1}(Scope 2)$"),
    ("scope2_log_intensity_lag",      "post", r"Post-Paris $\times$ Log (Intensity)$_{t-1}(Scope 2)$"),
    ("scope1_log_intensity_diff_lag", "pre",  r"Pre-Paris $\times$ $\Delta$(Intensity) (Scope 1)$_{t-1}$"),
    ("scope1_log_intensity_diff_lag", "post", r"Post-Paris $\times$ $\Delta$(Intensity) (Scope 1)$_{t-1}$"),
    ("scope2_log_intensity_diff_lag", "pre",  r"Pre-Paris $\times$ $\Delta$(Intensity)(Scope 2)$_{t-1}$"),
    ("scope2_log_intensity_diff_lag", "post", r"Post-Paris $\times$ $\Delta$(Intensity)(Scope 2)$_{t-1}$"),
]
PARIS_ROWS_REG2 = [
    ("scope1_log_rel_intensity_lag",      "pre",  r"Relative Emission Intensity$_{t-1} (Scope 1)$ $\times$ Pre-Paris"),
    ("scope1_log_rel_intensity_lag",      "post", r"Relative Intensity$_{t-1} (Scope 1)$ $\times$ Post-Paris"),
    ("scope2_log_rel_intensity_lag",      "pre",  r"Pre-Paris $\times$ Relative Emission Intensity$_{t-1}(Scope 2)$"),
    ("scope2_log_rel_intensity_lag",      "post", r"Post-Paris $\times$ Relative Emission Intensity$_{t-1}(Scope 2)$"),
    ("scope1_log_rel_intensity_diff_lag", "pre",  r"Pre-Paris $\times$ $\Delta$ Relative Intensity (Scope1) $_{t-1}$"),
    ("scope1_log_rel_intensity_diff_lag", "post", r"Post-Paris $\times$ $\Delta$ Relative Intensity (Scope1) $_{t-1}$"),
    ("scope2_log_rel_intensity_diff_lag", "pre",  r"Pre-Paris $\times$ $\Delta$ Relative Intensity (Scope2) $_{t-1}$"),
    ("scope2_log_rel_intensity_diff_lag", "post", r"Post-Paris $\times$ $\Delta$ Relative Intensity (Scope2) $_{t-1}$"),
]
PARIS_ROWS_REG5 = [
    ("scope1_log_intensity_industry_lag",      "pre",  r"Log (Industry Intensity)$_{t-1} (Scope 1)$ $\times$ Pre-Paris"),
    ("scope1_log_intensity_industry_lag",      "post", r"Log (Industry Intensity)$_{t-1} (Scope 1)$ $\times$ Post-Paris"),
    ("scope2_log_intensity_industry_lag",      "pre",  r"Pre-Paris $\times$ Log (Industry Intensity)$_{t-1}(Scope 2)$"),
    ("scope2_log_intensity_industry_lag",      "post", r"Post-Paris $\times$ Log (Industry Intensity)$_{t-1}(Scope 2)$"),
    ("scope1_log_intensity_industry_diff_lag", "pre",  r"Pre-Paris $\times$ $\Delta$Log (Industry Intensity) (Scope 1)$_{t-1}$"),
    ("scope1_log_intensity_industry_diff_lag", "post", r"Post-Paris $\times$ $\Delta$Log (Industry Intensity) (Scope 1)$_{t-1}$"),
    ("scope2_log_intensity_industry_diff_lag", "pre",  r"Pre-Paris $\times$ $\Delta$Log (Industry Intensity)(Scope 2)$_{t-1}$"),
    ("scope2_log_intensity_industry_diff_lag", "post", r"Post-Paris $\times$ $\Delta$Log (Industry Intensity)(Scope 2)$_{t-1}$"),
]

ROW_ORDER = {
    "reg1":         CONTROL_LABELS + PARIS_ROWS_REG1,
    "reg2":         CONTROL_LABELS + PARIS_ROWS_REG2,
    "reg3brown":    CONTROL_LABELS + PARIS_ROWS_REG2,
    "reg4nonbrown": CONTROL_LABELS + PARIS_ROWS_REG2,
    "reg5":         CONTROL_LABELS + PARIS_ROWS_REG5,
}

# FE labels per family (matches the benchmark fragments)
FE_ROW = {
    "reg1":         (r"us4b\_ilst", r"eu2b\_ilst", "ILST"),
    "reg2":         (r"us4b\_ilst", r"eu2b\_ilst", "ILST"),
    "reg3brown":    (r"us4b\_ilst", r"eu2b\_ilst", "ILST"),
    "reg4nonbrown": (r"us4b\_ilst", r"eu2b\_ilst", "ILST"),
    "reg5":         (r"us4b\_lst",  r"eu2b\_lst",  "LST"),
}
FAM_NOTE = {
    "reg1": "Full sample.",
    "reg2": "Full sample.",
    "reg3brown":
        "Subsample restricted to brown industries "
        "(industry-year log Scope 1 intensity at or above the pooled P75 "
        "threshold, following the Financial-Times classification).",
    "reg4nonbrown":
        "Subsample restricted to non-brown industries.",
    "reg5":
        "Between-industry variation. Regressors are the SIC 2-digit "
        "industry-average log Scope 1/Scope 2 emission intensities.",
}
# Per-family caption + label for the \begin{table} wrapper. Captions mirror
# the parent benchmark tables in revision_main.tex (General Analysis / Within
# -Industry Analysis - All / Dirty / Non-dirty / Between Industry Analysis),
# prefixed with "Wild Cluster Bootstrap Robustness:" so the appendix reader
# sees instantly that these are robustness variants of the main tables.
FAM_CAPTION = {
    "reg1":         ("Wild Cluster Bootstrap Robustness: General Analysis - US and EU",
                     "table_us_eu_general_wildbs_B500"),
    "reg2":         ("Wild Cluster Bootstrap Robustness: Within-Industry Analysis - All Firms - US and EU",
                     "table_us_eu_within_wildbs_B500"),
    "reg3brown":    ("Wild Cluster Bootstrap Robustness: Within-Industry Analysis - Dirty Industries - US and EU",
                     "table_us_eu_within_brown_wildbs_B500"),
    "reg4nonbrown": ("Wild Cluster Bootstrap Robustness: Within-Industry Analysis - Non-dirty Industries - US and EU",
                     "table_us_eu_within_green_wildbs_B500"),
    "reg5":         ("Wild Cluster Bootstrap Robustness: Between Industry Analysis - US and EU",
                     "table_us_eu_between_wildbs_B500"),
}

# ----- helpers -----
def _f(x):
    if x is None or x == "":
        return float("nan")
    try:
        return float(x)
    except ValueError:
        return float("nan")

def stars(p):
    # Star thresholds match the paper's historical convention
    # (Galina 2026-11-10 request): 0.01 / 0.05 / 0.10 instead of the fixest
    # default 0.001 / 0.01 / 0.05. The underlying bootstrap p-values from
    # the CSV are unchanged; only the threshold tiers move.
    if p is None or math.isnan(p):
        return ""
    if p < 0.01: return r"$^{***}$"
    if p < 0.05: return r"$^{**}$"
    if p < 0.10: return r"$^{*}$"
    return ""

def fmt_coef(b, p):
    if math.isnan(b): return ""
    return f"{b:.3f}" + stars(p)

def fmt_se(se):
    if math.isnan(se): return ""
    return f"({se:.3f})"

# ----- benchmark Observations row (per-column n_obs) -----
# Filename pattern per family -- reg5 uses "_between_" in the filename.
_BENCH_FILE = {
    "reg1":         "reg1_us4b_eu_country2b.tex",
    "reg2":         "reg2_us4b_eu_country2b.tex",
    "reg3brown":    "reg3brown_us4b_eu_country2b.tex",
    "reg4nonbrown": "reg4nonbrown_us4b_eu_country2b.tex",
    "reg5":         "reg5_between_us4b_eu_country2b.tex",
}
_OBS_PAT = re.compile(r"^\s*Observations\s*&(.*)\\\\", re.MULTILINE)

def read_benchmark_obs(family):
    """Return a list of 8 cell strings (US cols 1-4 then EU cols 5-8) from the
    parent benchmark .tex Observations row. Returns None if the benchmark file
    or row can't be found; the caller then falls back to the single-n multicolumn
    display built from n_obs_g."""
    path = os.path.join(FRAG_DIR, _BENCH_FILE[family])
    try:
        with open(path) as fh:
            text = fh.read()
    except FileNotFoundError:
        return None
    m = _OBS_PAT.search(text)
    if not m:
        return None
    cells = [c.strip().rstrip(r"\\").strip() for c in m.group(1).split("&")]
    if len(cells) != 8:
        return None
    return cells

# ----- load csv -----
EXPECTED_UNIQUE_KEYS = 120  # 5 families x 2 panels x 12 (4 controls + 8 Paris)
FAMILIES = ("reg1", "reg2", "reg3brown", "reg4nonbrown", "reg5")
PANELS   = ("us", "eu")

def load_csv(path):
    """Index by (family, panel, parameter, side) -> row dict.

    Enforces integrity: rejects duplicate keys (would indicate an interrupted
    server run concatenating a partial file onto a prior one) and reports
    anything short of the full 120-row grid so an incomplete CSV cannot
    masquerade as finished output.
    """
    rows = {}
    dup_keys = []
    with open(path, newline="") as fh:
        reader = csv.DictReader(fh)
        for r in reader:
            side = r.get("side", "") or ""
            key = (r["family"], r["panel"], r["parameter"], side)
            if key in rows:
                dup_keys.append(key)
            rows[key] = r
    if dup_keys:
        head = ", ".join(f"{k}" for k in dup_keys[:5])
        raise RuntimeError(
            f"wildbs CSV has {len(dup_keys)} duplicate (family,panel,parameter,side) "
            f"keys. First few: {head}. This typically means an interrupted B=500 run "
            f"was concatenated onto a prior one. Re-run the server bootstrap to a "
            f"fresh CSV before building tables."
        )
    # Count the expected per-family rows that are actually present.
    present_by_family = {fam: 0 for fam in FAMILIES}
    for (fam, panel, _param, _side) in rows:
        if fam in present_by_family and panel in PANELS:
            present_by_family[fam] += 1
    missing_by_family = {fam: 24 - n for fam, n in present_by_family.items()
                         if n < 24}  # 24 = 12 params x 2 panels
    if len(rows) < EXPECTED_UNIQUE_KEYS:
        detail = ", ".join(f"{fam} short {n}" for fam, n in missing_by_family.items())
        # Fixed 2026-11-04: fail loudly instead of warn. An incomplete wildbs
        # CSV was silently producing tables with blank rows, which then shipped
        # as "final". Stage 07 is a release blocker if it hasn't completed.
        raise SystemExit(
            f"ERROR: wildbs CSV has {len(rows)}/{EXPECTED_UNIQUE_KEYS} unique rows "
            f"({detail}). The wild-bootstrap server run is incomplete; re-run "
            f"stage 07 to completion before stage 08. Refusing to build "
            f"tables from an incomplete CSV.")
    return rows

# ----- fragment builder -----
# NOTE: the fragment is wrapped in \begin{table}[H] with a per-family \caption
# and \label so that a bare \input{reg*_WILDBS_B500} in revision_online_appendix.tex
# renders with a numbered, captioned table (same convention as the other
# robustness tables such as reg?_*_age_gt10.tex, reg?_*_no2020.tex, etc.).
TEMPLATE_HEAD_FMT = r"""
% Wild cluster bootstrap robustness -- self-contained fragment. Same layout as
% reg?_us4b_eu_country2b.tex but significance stars come from wild cluster
% bootstrap (feols outcomes) / pairs cluster bootstrap (feglm outcomes).
% Coefficients and cluster-robust SEs are from the analytic fixest fit.
\begin{{table}}[H]
\caption{{{caption}}}
\label{{{label}}}
\begingroup
\centering
\sbox1{{\footnotesize
\begin{{tabular}}{{lcccccccc}}
   \toprule
   & \multicolumn{{4}}{{c}}{{\textbf{{Panel A: U.S.\ sample}}}} & \multicolumn{{4}}{{c}}{{\textbf{{Panel B: EU sample}}}}\\
   \cmidrule(lr){{2-5}}\cmidrule(lr){{6-9}}
        & Loan Amount (Growth) & Log(Loan Amount) & New Loan       & First Loan    & Loan Amount (Growth) & Log(Loan Amount) & New Loan      & First Loan\\
        & (1)                  & (2)              & (3)            & (4)           & (5)                  & (6)              & (7)           & (8)\\
        & OLS                  & OLS              & Logit          & Logit         & OLS                  & OLS              & Logit         & Logit\\
   \midrule
"""

def build_fragment(family, csv_rows):
    caption, label = FAM_CAPTION[family]
    out = [TEMPLATE_HEAD_FMT.format(caption=caption, label=label)]
    seen_us_n = seen_eu_n = None

    for (base, side, label) in ROW_ORDER[family]:
        us = csv_rows.get((family, "us", base, side))
        eu = csv_rows.get((family, "eu", base, side))
        if us is None or eu is None:
            # Controls (side == "") predate the 2026-07 patch and may legitimately
            # be absent from older CSVs; skip with a warning. Interaction rows
            # (paris pre/post) are the Table 1 payload; a missing one leaves a
            # blank cell, which must fail the build.
            msg = f"missing ({family}, {base}, side={side!r}) in CSV"
            if side == "":
                print(f"  WARN: {msg} (control row; blank)")
                continue
            raise KeyError(f"build_wildbs_tables: {msg}")

        if seen_us_n is None:
            seen_us_n = int(float(us["n_obs_g"]))
            seen_eu_n = int(float(eu["n_obs_g"]))

        coefs = [
            fmt_coef(_f(us["b_g"]), _f(us["p_wcr_g"])),
            fmt_coef(_f(us["b_h"]), _f(us["p_wcr_h"])),
            fmt_coef(_f(us["b_i"]), _f(us["p_pairs_i"])),
            fmt_coef(_f(us["b_l"]), _f(us["p_pairs_l"])),
            fmt_coef(_f(eu["b_g"]), _f(eu["p_wcr_g"])),
            fmt_coef(_f(eu["b_h"]), _f(eu["p_wcr_h"])),
            fmt_coef(_f(eu["b_i"]), _f(eu["p_pairs_i"])),
            fmt_coef(_f(eu["b_l"]), _f(eu["p_pairs_l"])),
        ]
        ses = [
            fmt_se(_f(us["se_g"])), fmt_se(_f(us["se_h"])),
            fmt_se(_f(us["se_i"])), fmt_se(_f(us["se_l"])),
            fmt_se(_f(eu["se_g"])), fmt_se(_f(eu["se_h"])),
            fmt_se(_f(eu["se_i"])), fmt_se(_f(eu["se_l"])),
        ]
        out.append(f"   {label:<75}& " + " & ".join(coefs) + r"\\" + "\n")
        out.append(f"   {'':<75}& " + " & ".join(ses)   + r"\\" + "\n")

    out.append("    \\\\\n")
    # Per-column Observations row -- pull from the parent benchmark .tex so
    # the WILDBS table honours its own "match the benchmark table" invariant.
    bench_obs = read_benchmark_obs(family)
    if bench_obs is not None:
        out.append(
            "   Observations                                                & "
            + " & ".join(bench_obs) + "\\\\\n"
        )
        out.append("    \\\\\n")
    elif seen_us_n is not None:
        # Fallback: the benchmark .tex wasn't available. Emit the loan-growth
        # n_obs across all four columns of each panel and WARN so the operator
        # knows to regenerate once the benchmark table is in place.
        print(f"  WARN: benchmark .tex for {family} not found; using "
              f"single-n fallback (loan-growth sample only).")
        out.append(
            f"   Observations                                                & "
            f"\\multicolumn{{4}}{{c}}{{{seen_us_n:,}}} & "
            f"\\multicolumn{{4}}{{c}}{{{seen_eu_n:,}}}\\\\\n"
        )
        out.append("    \\\\\n")

    # FE rows
    us_fe, eu_fe, _ = FE_ROW[family]
    out.append(
        r"   Borrower fixed effects                                      & $\checkmark$         & $\checkmark$     & $\checkmark$   & $\checkmark$  & $\checkmark$         & $\checkmark$     & $\checkmark$  & $\checkmark$\\"
        + "\n"
        r"   Lender-Year fixed effects                                   & $\checkmark$         & $\checkmark$     & $\checkmark$   & $\checkmark$  & $\checkmark$         & $\checkmark$     & $\checkmark$  & $\checkmark$\\"
        + "\n"
    )
    out.append(
        f"   {us_fe} fixed effects                                    & "
        r"$\checkmark$         & $\checkmark$     & $\checkmark$   & $\checkmark$  &                      &                  &               & \\"
        + "\n"
    )
    out.append(
        f"   {eu_fe} fixed effects                                    & "
        r"                     &                  &                &               & $\checkmark$         & $\checkmark$     & $\checkmark$  & $\checkmark$\\"
        + "\n"
    )
    out.append(r"   \bottomrule" + "\n")
    out.append(r"\end{tabular}%" + "\n")
    out.append(r"}%" + "\n")
    out.append(r"\sbox0{\scalebox{0.8}{\usebox1}}%" + "\n")
    out.append(r"\ifdim\wd0>\textwidth" + "\n")
    out.append(r"  \sbox0{\resizebox{\textwidth}{!}{\usebox1}}%" + "\n")
    out.append(r"\fi" + "\n")
    out.append(r"\noindent\hspace*{\fill}\begin{minipage}{\wd0}" + "\n")
    out.append(r"%\centering" + "\n")
    out.append(r"\usebox0\par\vspace{3pt}" + "\n")
    out.append(r"%\raggedright" + "\n")

    fam_note = FAM_NOTE[family]
    fe_lbl   = FE_ROW[family][2]
    resolution = 1.0 / (B + 1)
    notes = (
        r"\footnotesize\textit{Notes:} "
        r"Wild cluster bootstrap robustness check on the coefficients of the "
        r"main benchmark specification. Columns~(1)--(4) report results for "
        r"the U.S.\ sub-sample; columns~(5)--(8) report results for the EU "
        r"sub-sample. Dependent variables: columns (1)/(5) loan-amount growth, "
        r"(2)/(6) log loan amount, (3)/(7) probability of a new loan with a "
        r"given lender (logit), (4)/(8) probability of a first loan with a "
        r"given lender (logit). Coefficients and cluster-robust standard "
        r"errors (in parentheses) are from the analytic \texttt{fixest} fit "
        r"and match the main benchmark table---only the significance stars "
        r"differ. On the OLS outcomes (cols 1--2, 5--6) stars are derived "
        r"from the Cameron--Gelbach--Miller (2008) restricted-null wild "
        rf"cluster bootstrap (WCR) with $B={B}$ replicates and cluster $\sim$ "
        r"SIC 2-digit. On the logit outcomes (cols 3--4, 7--8) stars are from "
        r"a pairs cluster bootstrap on the same SIC 2-digit clusters with "
        rf"$B={B}$. Every reported coefficient (four firm-level controls plus "
        r"eight Paris-interaction terms) is individually bootstrapped: the "
        r"WCR restricted refit drops the single term being tested from the "
        r"RHS. Fixed effects: borrower, lender-year, and "
        rf"{fe_lbl} (as in the main benchmark). {fam_note} "
        rf"Bootstrap $p$-value resolution at $B={B}$ is $1/({B}+1)"
        rf"\approx{resolution:.4f}$. "
        r"Significance levels: $^{***}p<0.01$, $^{**}p<0.05$, "
        r"$^{*}p<0.10$.%"
    )
    out.append(notes + "\n")
    out.append(r"\end{minipage}\hspace*{\fill}\par" + "\n")
    out.append(r"\endgroup" + "\n")
    out.append(r"\end{table}" + "\n")
    return "".join(out)

# ----- main -----
def main():
    rows = load_csv(CSV_IN)
    written = []
    # Tag the output filename with the B we're building for so B=100 vs B=500
    # vs B=999 land in different tex fragments. _WILDBS.tex (no B) remains
    # the default B=100 smoke output; _WILDBS_B500.tex, _WILDBS_B999.tex etc.
    # are the production variants.
    tag = "" if B == 100 else f"_B{B}"
    for family in ["reg1", "reg2", "reg3brown", "reg4nonbrown", "reg5"]:
        frag = build_fragment(family, rows)
        if family == "reg5":
            out_name = f"reg5_between_us4b_eu_country2b_WILDBS{tag}.tex"
        else:
            out_name = f"{family}_us4b_eu_country2b_WILDBS{tag}.tex"
        out_path = os.path.join(FRAG_DIR, out_name)
        with open(out_path, "w") as fh:
            fh.write(frag)
        written.append(out_path)
    print("Wrote:")
    for p in written:
        print("  ", p)

if __name__ == "__main__":
    main()
