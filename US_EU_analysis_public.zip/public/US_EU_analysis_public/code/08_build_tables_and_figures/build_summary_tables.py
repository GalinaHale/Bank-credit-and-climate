#!/usr/bin/env python3
"""
Parser + cell/row/table helpers for the stage-08 summary tables (Tables 1-4).

This module exports the pure-function helpers consumed by
`build_summary_tables_vJun2026.py`:

    parse_etable_fragment, build_single_source_table, build_within_table,
    row_label_general, row_label_industry

Earlier revisions carried a `main()` entry point that produced manuscript-
narrative paragraphs comparing benchmark vs variant estimates. That path was
author-side dev scaffolding and is not part of the public pipeline; it has
been removed from this tier.
"""
from __future__ import annotations
import os, re, sys
from pathlib import Path

_this      = Path(__file__).resolve()
_REPL      = Path(os.environ.get("REPL_ROOT", str(_this.parents[2])))
TABLES_DIR = Path(os.environ.get("OUT_TABLES", str(_REPL / "output" / "tables")))
OUT_DIR    = _REPL / "output"
ROOT       = _REPL  # kept for backward compatibility with legacy imports

OUTCOMES_ABBR = ["LG", "Log", "NL", "FL"]                       # column-stub labels
OUTCOMES_LBL  = ["Loan Growth", "Log(Loan Amount)", "New Loan", "First Loan"]
OUTCOME_SYMBOL = {0: r"\blacktriangle", 1: r"\blacksquare", 2: r"\blacklozenge", 3: r"\bullet"}

# variant-name -> (filename suffix, set of source 'kinds' available)
VARIANTS = {
    "benchmark":      ("",                       {"firm", "industry", "relative", "brown", "nonbrown"}),
    "withage":        ("_withage",               {"firm", "industry", "relative", "brown", "nonbrown"}),
    "firmagelag":     ("_firmagelag",            {"firm", "industry", "relative", "brown", "nonbrown"}),
    "no2020":         ("_no2020",                {"firm", "industry", "relative", "brown", "nonbrown"}),
    "ilst":           ("_ilst",                  {"firm", "industry", "relative", "brown", "nonbrown"}),
    "ilst_nuts2":     ("_ilst_nuts2_2010",       {"firm", "industry", "relative", "brown", "nonbrown"}),
    "ilst_nuts3":     ("_ilst_nuts3_2010",       {"firm", "industry", "relative", "brown", "nonbrown"}),
    "ilst_loansample":             ("_ilst_loansample",                 {"firm", "industry", "relative", "brown", "nonbrown"}),
    "ilst_loansample_age":         ("_ilst_loansample_age",             {"firm", "industry", "relative", "brown", "nonbrown"}),
    "ilst_loansample_country":     ("_ilst_loansample_country",         {"firm", "industry", "relative", "brown", "nonbrown"}),
    "ilst_loansample_country_age": ("_ilst_loansample_country_age",     {"firm", "industry", "relative", "brown", "nonbrown"}),
    "ilst_loansample_country_2b":     ("_ilst_loansample_country_2b",      {"firm", "industry", "relative", "brown", "nonbrown"}),
    "ilst_loansample_country_2b_age": ("_ilst_loansample_country_2b_age",  {"firm", "industry", "relative", "brown", "nonbrown"}),
    "tv":             ("_tv",                    {"brown", "nonbrown"}),
    "p90":            ("_p90",                   {"brown", "nonbrown"}),
    "ftp90":          ("_ft_p90",                {"brown", "nonbrown"}),
}

FILE_PATTERNS = {
    "firm":     "us_eu_loan_loggr_regs_emissionintensityscope1scope2_paris{suffix}.tex",
    "industry": "us_eu_loan_loggr_regs_industry_emissionintensityscope1scope2_paris{suffix}.tex",
    "relative": "us_eu_loan_loggr_regs_relativeemissionintensityscope1scope2_paris{suffix}.tex",
    "brown":    "us_eu_loan_loggr_regs_relativeemissionintensity_brownindscope1scope2_paris{suffix}.tex",
    "nonbrown": "us_eu_loan_loggr_regs_relativeemissionintensity_nonbrownindscope1scope2_paris{suffix}.tex",
}

# -----------------------------------------------------------------------------
# Parser
# -----------------------------------------------------------------------------

CELL_RX = re.compile(r"""
    ^\s*
    (?P<sign>-)?(?P<num>\d+\.\d+)              # numeric coefficient
    (?:\$\^\{(?P<stars>\*+)\}\$)?              # optional significance stars
    \s*$
""", re.VERBOSE)

def parse_etable_fragment(path: Path):
    """Parse an etable tex fragment.

    Returns:
        n_outcomes  -- outcomes per sample (2 for OLS-only withage tables, 4 normally).
        rows        -- dict keyed by (scope, level_or_diff, pre_or_post) ->
                       list of 2*n_outcomes (coef, stars) tuples. First n_outcomes
                       entries are the US-only sample, next n_outcomes are EU.
    """
    text = path.read_text()
    body = re.search(r"\\begin\{tabular\}.*?\\end\{tabular\}", text, re.DOTALL).group(0)
    rows = {}
    n_cols_total = None
    for chunk in body.split("\\\\"):
        if "Paris" not in chunk:
            continue
        if "Intensity" not in chunk:
            continue
        pre  = "Pre-Paris"  in chunk
        post = "Post-Paris" in chunk
        if not (pre ^ post):
            continue
        timing = "pre" if pre else "post"
        scope = 1 if ("Scope 1" in chunk or "Scope1" in chunk) else (
                2 if ("Scope 2" in chunk or "Scope2" in chunk) else None)
        if scope is None:
            continue
        kind = "diff" if r"\Delta" in chunk else "level"
        cells = [c.strip() for c in chunk.split("&")]
        if len(cells) < 3:
            continue
        coef_cells = cells[1:]
        parsed = []
        for c in coef_cells:
            m = CELL_RX.match(c)
            if not m:
                parsed.append((None, 0))
                continue
            val = float((m.group("sign") or "") + m.group("num"))
            stars = len(m.group("stars") or "")
            parsed.append((val, stars))
        if n_cols_total is None:
            n_cols_total = len(parsed)
        rows[(scope, kind, timing)] = parsed
    if n_cols_total is None:
        return 0, rows
    # withage tables have 4 total cols (2 outcomes x 2 samples); normal tables 8 (4 x 2)
    n_outcomes = n_cols_total // 2
    return n_outcomes, rows

# -----------------------------------------------------------------------------
# Formatting helpers
# -----------------------------------------------------------------------------

def fmt_coef(c, stars, decimals=3):
    if c is None:
        return ""
    s = f"{c:.{decimals}f}"
    if stars > 0:
        s = s + r"$^{" + ("*" * stars) + r"}$"
    return s

NO_DATA = "---"

def cell_packed(coefs4, decimals=3):
    """Pack outcome cells separated by ' / '. Returns '---' when no data."""
    if coefs4 is None:
        return NO_DATA
    return " / ".join(fmt_coef(c, s, decimals) for (c, s) in coefs4)

def row_label_general(scope, kind, timing):
    if kind == "level":
        base = rf"Log (EI{scope})$_{{t-1}}$"
    else:
        base = rf"$\Delta$log(EI{scope})$_{{t-1}}$"
    return base + rf" $\times$ {'Pre' if timing == 'pre' else 'Post'}-Paris"

def row_label_relative(scope, kind, timing):
    if kind == "level":
        base = rf"REI{scope}$_{{t-1}}$"
    else:
        base = rf"$\Delta$REI{scope}$_{{t-1}}$"
    return base + rf" $\times$ {'Pre' if timing == 'pre' else 'Post'}-Paris"

def row_label_industry(scope, kind, timing):
    if kind == "level":
        base = rf"Log (Ind.\ Intensity)$_{{t-1}}$(Scope{scope})"
    else:
        base = rf"$\Delta$(Ind.\ Intensity)$_{{t-1}}$(Scope{scope})"
    return base + rf" $\times$ {'Pre' if timing == 'pre' else 'Post'}-Paris"

# canonical row order matches original Table 1: levels then diffs, scopes interleaved, pre then post
ROW_ORDER = [
    (1, "level", "pre"),
    (2, "level", "pre"),
    (1, "diff",  "pre"),
    (2, "diff",  "pre"),
    (1, "level", "post"),
    (2, "level", "post"),
    (1, "diff",  "post"),
    (2, "diff",  "post"),
]

# -----------------------------------------------------------------------------
# Table 1 / Table 3 (single-source, 8 columns split into 2 panels)
# -----------------------------------------------------------------------------

OUTCOME_HEAD = [
    ("Loan Growth",      "OLS"),
    ("Log(Loan Amount)", "OLS"),
    ("New Loan",         "Logit"),
    ("First Loan",       "Logit"),
]

NOTES_DEFAULT = (
    r"\textit{Notes:} All US-sample regressions include borrower, lender-year, and "
    r"industry-year fixed effects. The EU sample adds borrower country "
    r"fixed effects. All regressions include controls for log total assets, leverage, "
    r"CAPEX/assets and EBITDA/assets (lagged). Significance: ***1\%, **5\%, *10\%."
)
NOTES_WITHIN = (
    r"\textit{Notes:} Within-industry regressions on relative emission intensity "
    r"(REI). Column blocks correspond to the full sample, dirty industries, and "
    r"non-dirty industries respectively, with dirty industries defined as those "
    r"with industry-level Scope 1 emission intensity above the 75th percentile "
    r"(fixed-threshold baseline). Each cell packs the four outcome coefficients "
    r"in order: Loan Growth, Log(Loan Amount), New Loan, First Loan. "
    r"All regressions include borrower, lender-year, and industry-year fixed "
    r"effects; the EU sample adds country fixed effects. "
    r"Significance: ***1\%, **5\%, *10\%."
)
NOTES_BETWEEN = (
    r"\textit{Notes:} Loan-level regressions with the regressor measured at the "
    r"industry level. Industry intensity is the industry's aggregated emissions "
    r"divided by real revenue (lagged). All regressions include borrower, "
    r"lender-year, industry, and year fixed effects; the EU sample adds "
    r"country fixed effects. Significance: ***1\%, **5\%, *10\%."
)
NOTES_SUMMARY = (
    r"\textit{Notes:} Each cell summarises the sign and significance of the "
    r"corresponding regression coefficient across the four loan outcomes, reading "
    r"sign in reverse: a negative coefficient on emission intensity means cleaner "
    r"or greening firms benefit, hence $\uparrow$; a positive coefficient means "
    r"the opposite, hence $\downarrow$. Outcome symbols: $\blacktriangle$ loan "
    r"growth, $\blacksquare$ log loan amount, $\blacklozenge$ new-loan issuance, "
    r"$\bullet$ first lending relationship. ``No effect'' indicates no coefficient "
    r"significant at the 10\% level. ``---'' indicates the underlying regression "
    r"is not run for this variant. Within-industry rows use REI; the All-industries "
    r"column uses the full sample, Dirty/Non-dirty columns split on the brown "
    r"classification. Significance: ***1\%, **5\%, *10\%."
)

def _wrap_table(body_lines, caption, label, scale, notes, parbox_width="15cm"):
    """Wrap a tabular body with the scalebox + parbox-notes pattern from the draft."""
    out = [
        r"\begin{table}[H]",
        rf"\caption{{{caption}}}\label{{tab:{label}}}",
        r"\setlength\extrarowheight{0.5pt}",
        r"\centering",
        rf"\scalebox{{{scale:.2f}}}{{%",
    ]
    out.extend(body_lines)
    out.append("}")
    out.append(rf"\parbox{{{parbox_width}}}{{\footnotesize {notes}}}")
    out.append(r"\end{table}")
    return "\n".join(out)

def build_single_source_table(parsed_pair, row_label_fn, caption, label,
                              panel_names=("US Sample", "EU Sample"),
                              scale=0.85, notes=None):
    """Build LaTeX for a Table-1-style summary: K outcomes x 2 sample panels."""
    n_out, parsed = parsed_pair
    if n_out == 0:
        return ""
    head_labels = OUTCOME_HEAD[:n_out]
    col_spec = "l" + "c" * n_out
    body = [
        rf"\begin{{tabular}}{{{col_spec}}}",
        r"\toprule",
        " & " + " & ".join(h[0] for h in head_labels) + r"\\",
        " & " + " & ".join(f"({i+1})" for i in range(n_out)) + r"\\",
        " & " + " & ".join(h[1] for h in head_labels) + r"\\",
        r"\midrule",
    ]
    for panel_idx, panel_name in enumerate(panel_names):
        col_offset = panel_idx * n_out
        body.append(rf"\multicolumn{{{n_out+1}}}{{l}}{{\textit{{{panel_name}}}}}\\")
        for key in ROW_ORDER:
            coefs = parsed.get(key, [(None, 0)] * (2 * n_out))
            block = coefs[col_offset:col_offset + n_out]
            cells = " & ".join(fmt_coef(c, s) for (c, s) in block)
            body.append(f"{row_label_fn(*key)} & {cells}\\\\")
        if panel_idx == 0:
            body.append(r"\midrule")
    body.append(r"\bottomrule")
    body.append(r"\end{tabular}")
    return _wrap_table(body, caption, label, scale, notes or NOTES_DEFAULT)

# -----------------------------------------------------------------------------
# Table 2 (within-industry, three industry-type columns, packed outcomes)
# -----------------------------------------------------------------------------

def build_within_table(rel_pair, brown_pair, nonbrown_pair, caption, label,
                       panel_names=("US Sample", "EU Sample")):
    """Within-industry summary: All / Dirty / Non-dirty packed cells."""
    # determine outcome count from any non-empty source
    n_out = 0
    for pair in (rel_pair, brown_pair, nonbrown_pair):
        if pair and pair[0] > n_out:
            n_out = pair[0]
    if n_out == 0:
        return ""
    head = " / ".join(f"{lbl} ({op})" for (lbl, op) in OUTCOME_HEAD[:n_out])

    def block(pair, key, col_offset):
        if not pair:
            return None
        n_p, parsed = pair
        if n_p == 0:
            return None
        coefs = parsed.get(key, [(None, 0)] * (2 * n_p))
        # If panel offset is beyond this source's data (e.g. only 2 outcomes), return slice
        return coefs[col_offset:col_offset + n_p] if n_p == n_out else \
               coefs[(col_offset // n_out) * n_p : (col_offset // n_out + 1) * n_p]

    body = [
        r"\begin{tabular}{lccc}",
        r"\toprule",
        r" & All Industries & Dirty Industries & Non-dirty Industries\\",
        r" & (1) & (2) & (3)\\",
        rf"\multicolumn{{4}}{{l}}{{\textit{{Each cell: {head}}}}}\\",
        r"\midrule",
    ]
    for panel_idx, panel_name in enumerate(panel_names):
        col_offset = panel_idx * n_out
        body.append(rf"\multicolumn{{4}}{{l}}{{\textit{{{panel_name}}}}}\\")
        for key in ROW_ORDER:
            r_all   = block(rel_pair,      key, col_offset)
            r_dirty = block(brown_pair,    key, col_offset)
            r_clean = block(nonbrown_pair, key, col_offset)
            label_str = row_label_relative(*key)
            body.append(f"{label_str} & {cell_packed(r_all)} & {cell_packed(r_dirty)} & {cell_packed(r_clean)}\\\\")
        if panel_idx == 0:
            body.append(r"\midrule")
    body.append(r"\bottomrule")
    body.append(r"\end{tabular}")
    scale = 0.6
    return _wrap_table(body, caption, label, scale, NOTES_WITHIN)
