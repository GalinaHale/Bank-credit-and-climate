#!/usr/bin/env python3
"""finalize_table_formatting.py — single source of truth for the three
table-formatting conventions the authors have standardised on.

Run order: LAST step of stage 08, after match_overleaf_wrapper.py. Operates
in place on every .tex in OUT_TABLES (default: replication_package/output/
tables). Idempotent.

Rules enforced (anything that violates them is rewritten; anything that
already conforms is left alone):

  R1. **Notes block active, not commented.** Every fragment that uses the
      Style B minipage/`\\emph{Notes:}` footer must have those lines
      uncommented. Historically `polish_etable_output` or an Overleaf
      author would sometimes land a fragment with `%\\footnotesize ...`
      / `%\\begin{minipage}` / `%\\end{minipage}` / `%\\vspace{0.5em}`;
      this step re-activates every such line. Hand-written fragments
      (A.9 Table, scope2-on-scope1) store their Notes in the Style A
      format (`\\textit{Notes:}` inside `\\begin{minipage}{\\wd0}`) and
      need no special handling here — the lines just stay active.

  R2. **Notes justified (no `\\raggedright`).** Style A and Style B both
      render notes inside a minipage; the author wants justified text,
      not ragged-left. Strip any bare `\\raggedright` adjacent to the
      `Notes:` opener.

  R3. **No trailing `\\\\` after `\\bottomrule`.** `polish_etable_output`
      already does this on the pipeline output. We repeat it here so a
      fragment pulled in from Overleaf (which might still carry the old
      padding) gets normalised too.

Hand-written tables under protection:
  - bank_industryyear_nonbrown_nzba_paris.tex  (Table A.9, Style A, NZBA
    construction notes)
  - scope2_on_scope1_intensity.tex             (diagnostic, Style B wrapper
    with hand-written diagnostic notes)

Their canonical content lives in tables_reference/, so match_overleaf_wrapper
pulls the correct wrapper. This finalizer just enforces the three rules on
top.
"""
from __future__ import annotations
import os
import re
import sys
from pathlib import Path

_REPL_ROOT = os.environ.get("REPL_ROOT")
if not _REPL_ROOT:
    _REPL_ROOT = str(Path(__file__).resolve().parent.parent.parent)
_TABLES_DIR = os.environ.get("OUT_TABLES",
                             str(Path(_REPL_ROOT) / "output" / "tables"))


# R1: lines that should be active, not commented.
UNCOMMENT_PATTERNS = [
    re.compile(r"^(\s*)%(\\footnotesize\s+\\emph\{Notes:\})", re.MULTILINE),
    re.compile(r"^(\s*)%(\\footnotesize\s*\\textit\{Notes:\})", re.MULTILINE),
    re.compile(r"^(\s*)%(\\begin\{minipage\}\{\\textwidth\})", re.MULTILINE),
    re.compile(r"^(\s*)%(\\begin\{minipage\}\{0\.95\\textwidth\})", re.MULTILINE),
    re.compile(r"^(\s*)%(\\end\{minipage\})", re.MULTILINE),
    re.compile(r"^(\s*)%(\\vspace\{0\.5em\})", re.MULTILINE),
]


# R2a: strip a bare `\raggedright` attached to a Notes line.
# Covers both `\raggedright\footnotesize\textit{Notes:}` (Style A reference)
# and `\raggedright \footnotesize \emph{Notes:}` (Style B variants).
RAGGEDRIGHT_RE = re.compile(
    r"\\raggedright(?=\s*\\footnotesize\s*\\(?:textit|emph)\{Notes:\})"
)

# R2b: strip `\centering` that precedes `\usebox0` INSIDE a minipage.
# The pipeline emits `\centering\usebox0\par\vspace{6pt}` inside the Style A
# minipage; `\centering` then propagates into the Notes paragraph below and
# centers the text. Since the minipage is exactly `\wd0` wide (same width as
# the saved box), the `\usebox0` fills it regardless of `\centering`, so the
# centering directive is redundant for the box and harmful to the notes.
# The vSep2026 reference wrote it as `%\centering\n\usebox0...` (on its own
# commented line); we strip it instead, which is equivalent visually.
CENTERING_IN_MINIPAGE_RE = re.compile(
    r"\\centering(?=\\usebox0)"
)


# R3: strip `\bottomrule \\` + empty-row padding before `\end{tabular}`.
BOT_STRIP_RE = re.compile(
    r"(?P<indent>\s*)\\bottomrule\s*\\\\\s*\n(?:\s*\\\\\s*\n)*(?P<end>\s*\\end\{tabular\})",
    re.MULTILINE,
)


def apply_rules(text: str) -> str:
    # R1
    for pat in UNCOMMENT_PATTERNS:
        text = pat.sub(r"\1\2", text)
    # R2a + R2b
    text = RAGGEDRIGHT_RE.sub("", text)
    text = CENTERING_IN_MINIPAGE_RE.sub("", text)
    # R3
    text = BOT_STRIP_RE.sub(
        lambda m: f"{m.group('indent')}\\bottomrule{m.group('end')}",
        text,
    )
    return text


def process_dir(d: Path) -> tuple[int, int]:
    changed = 0
    total = 0
    for p in sorted(d.glob("*.tex")):
        src = p.read_text()
        new = apply_rules(src)
        total += 1
        if new != src:
            p.write_text(new)
            changed += 1
            print(f"  [finalized] {p.name}")
    return changed, total


def main():
    dirs = sys.argv[1:] or [_TABLES_DIR]
    for d in dirs:
        dp = Path(d)
        if not dp.is_dir():
            print(f"[skip missing] {d}")
            continue
        print(f"== finalize {dp} ==")
        c, t = process_dir(dp)
        print(f"  changed={c}  total={t}")


if __name__ == "__main__":
    main()
