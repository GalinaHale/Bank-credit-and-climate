
#!/usr/bin/env python3
"""Build the main-text summary tables for the new (Jun 2026) ILST benchmark.

Two summary tables, modeled on the main-text tables in EEREV-S-25-01821:

  (1) "General Analysis: Syndicated Loans - US and EU"
        — built from reg1 (firm-level log emission intensity, full sample)
        — outcomes packed across columns, US/EU panels stacked

  (2) "Within Analysis: Syndicated Loans - US and EU - By industry type"
        — built from reg2 (all firms), reg3 (dirty), reg4 (non-dirty)
        — outcomes packed across columns, three industry-type columns,
          US/EU panels stacked

Headline specification: U.S. ILST with 4 size quartiles paired with EU
ILST with country and 2 size buckets — i.e. the *_us4b_eu_country2b.tex
fragments produced by run_new_benchmark_ilst.R. The U.S.\ 2-bucket
variant is documented in the appendix tables and is not summarised here.

Inputs (in TABLES_DIR):
  reg1_us4b_eu_country2b.tex
  reg2_us4b_eu_country2b.tex
  reg3brown_us4b_eu_country2b.tex
  reg4nonbrown_us4b_eu_country2b.tex
  reg5_between_us4b_eu_country2b.tex

Outputs (in TABLES_DIR):
  summary_general_us_eu.tex          (Table 1 of EER draft, new benchmark)
  summary_within_us_eu.tex           (Table 2 of EER draft, new benchmark)
  summary_between_us_eu.tex          (Table 3 of EER draft, new benchmark)
"""
from __future__ import annotations

# --- portability shim ---
import os
from pathlib import Path
_REPL_ROOT = os.environ.get("REPL_ROOT")
if not _REPL_ROOT:
    _REPL_ROOT = str(Path(__file__).resolve().parent.parent.parent)
    os.environ["REPL_ROOT"] = _REPL_ROOT
REPL_ROOT_P = Path(_REPL_ROOT)
# --- end shim ---
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from build_summary_tables import (
    parse_etable_fragment,
    build_single_source_table,
    build_within_table,
    row_label_general,
    row_label_industry,
)

# Fixed 2026-11-04: ROOT previously pointed to the PARENT project directory
# (../RR_bhavyaa) and read/wrote tables from ../output/tables — out of the
# replication package. That path was unavailable to a fresh deploy and caused
# the package summary-table hashes to diverge from the parent. Switch to
# $REPL_ROOT (set by run.sh) or the package root inferred from __file__.
_this  = Path(__file__).resolve()
_REPL  = Path(os.environ.get("REPL_ROOT", str(_this.parents[2])))  # code/08.../build_...py → package root is parents[2]
TABLES_DIR = Path(os.environ.get("OUT_TABLES", str(_REPL / "output" / "tables")))
ROOT = _REPL  # kept for any downstream references

NOTES_GENERAL = (
    r"\textit{Notes:} New benchmark specification. All regressions include "
    r"borrower, lender-year, and ILST (Industry $\times$ "
    r"Location $\times$ Size $\times$ Time) fixed effects. "
    r"\emph{U.S.\ ILST cells:} SIC 2-digit $\times$ Compustat HQ state "
    r"$\times$ asset-size quartiles (within deal-year, ranked on the "
    r"unique firm-years in the U.S.\ loan panel) $\times$ deal-year. "
    r"\emph{EU ILST cells:} SIC 2-digit $\times$ country (ISO3) $\times$ "
    r"asset-size median split (within deal-year, ranked on the EU loan "
    r"panel) $\times$ deal-year. "
    r"All regressions include firm-level controls (log total assets, "
    r"leverage, CAPEX/assets, EBITDA/assets), all lagged one fiscal year. "
    r"For full regression results, see "
    r"Table~\ref{tab:firm_us4b_eu2b} in the appendix. "
    r"Robust standard errors are clustered at the 2-digit SIC industry "
    r"level. Significance levels: ***1\%, **5\%, *10\%."
)

NOTES_BETWEEN = (
    r"\textit{Notes:} New benchmark specification --- between-industry "
    r"analysis. The regressor is industry-level (SIC 2-digit) log "
    r"emission intensity, scope 1 and scope 2, each interacted with "
    r"pre- and post-Paris indicators. Because the regressor varies "
    r"only at the (industry $\times$ year) level, the ILST cell of the "
    r"main benchmark would absorb it entirely; we therefore drop the "
    r"industry dimension and use an LST (Location $\times$ Size "
    r"$\times$ Time) cell with the same location, size-bucket, and "
    r"deal-year definitions as the new ILST benchmark. All regressions "
    r"include borrower, lender-year, and LST fixed "
    r"effects. \emph{U.S.\ LST cells:} HQ state $\times$ asset-size "
    r"quartiles $\times$ deal-year. \emph{EU LST cells:} country "
    r"(ISO3) $\times$ asset-size median split $\times$ deal-year. "
    r"Firm-level controls (log total assets, leverage, CAPEX/assets, "
    r"EBITDA/assets) are lagged. For full regression results see "
    r"Table~\ref{tab:reg5_us4b_eu2b} in the appendix. Robust standard "
    r"errors are clustered at the 2-digit SIC industry level. "
    r"Significance levels: ***1\%, **5\%, *10\%."
)

NOTES_WITHIN = (
    r"\textit{Notes:} New benchmark specification. Reported are "
    r"coefficients from within-industry regressions on log relative "
    r"emission intensity ($\Delta$REI) for the full sample, the dirty "
    r"(brown) industries subsample, and the non-dirty industries "
    r"subsample. Dirty industries are SIC 2-digit industries with "
    r"average Scope 1 emission intensity above the 75th percentile "
    r"(fixed-threshold rule). All regressions include borrower "
    r"(borrower), lender-year, and ILST fixed effects. "
    r"\emph{U.S.\ ILST cells:} SIC 2-digit $\times$ HQ state $\times$ "
    r"asset-size quartiles $\times$ deal-year. "
    r"\emph{EU ILST cells:} SIC 2-digit $\times$ country $\times$ "
    r"asset-size median split $\times$ deal-year. Firm-level controls "
    r"(log total assets, leverage, CAPEX/assets, EBITDA/assets) are "
    r"lagged. For full regression results see Tables "
    r"\ref{tab:within_us4b_eu2b}, \ref{tab:withinbrown_us4b_eu2b}, and "
    r"\ref{tab:withinnonbrown_us4b_eu2b} in the appendix. Robust standard "
    r"errors are clustered at the 2-digit SIC industry level. "
    r"Significance levels: ***1\%, **5\%, *10\%."
)


def main():
    # --- Load the five headline fragments ----------------------------------
    files = {
        "firm":     TABLES_DIR / "reg1_us4b_eu_country2b.tex",
        "relative": TABLES_DIR / "reg2_us4b_eu_country2b.tex",
        "brown":    TABLES_DIR / "reg3brown_us4b_eu_country2b.tex",
        "nonbrown": TABLES_DIR / "reg4nonbrown_us4b_eu_country2b.tex",
        "between":  TABLES_DIR / "reg5_between_us4b_eu_country2b.tex",
    }
    for k, f in files.items():
        if not f.exists():
            sys.exit(f"missing input: {f}")
    parsed = {k: parse_etable_fragment(f) for k, f in files.items()}
    for k, (n, _) in parsed.items():
        print(f"  {k:10s} n_outcomes={n}, parsed={files[k].name}")

    # --- (1) General analysis summary --------------------------------------
    tex_general = build_single_source_table(
        parsed_pair=parsed["firm"],
        row_label_fn=row_label_general,
        caption="General Analysis: Syndicated Loans -- U.S.\\ and EU "
                "(new ILST benchmark)",
        label="us_eu_general_ilst",
        notes=NOTES_GENERAL,
    )
    out1 = TABLES_DIR / "summary_general_us_eu.tex"
    out1.write_text(tex_general + "\n")
    print(f"\n  wrote {out1.relative_to(ROOT)}")

    # --- (2) Within-industry summary ---------------------------------------
    tex_within = build_within_table(
        rel_pair      = parsed["relative"],
        brown_pair    = parsed["brown"],
        nonbrown_pair = parsed["nonbrown"],
        caption="Within Analysis: Syndicated Loans -- U.S.\\ and EU "
                "-- By industry type (new ILST benchmark)",
        label="us_eu_within_ilst",
    )
    # Replace the helper's default NOTES_WITHIN with the new-benchmark notes.
    # Use a function-style replacement so backslashes in NOTES_WITHIN don't
    # get interpreted as backreferences by re.sub.
    import re
    tex_within = re.sub(
        r"\\parbox\{15cm\}\{\\footnotesize .+?\}\n\\end\{table\}",
        lambda m: (rf"\parbox{{15cm}}{{\footnotesize {NOTES_WITHIN}}}"
                   + "\n" + r"\end{table}"),
        tex_within, count=1, flags=re.DOTALL,
    )
    out2 = TABLES_DIR / "summary_within_us_eu.tex"
    out2.write_text(tex_within + "\n")
    print(f"  wrote {out2.relative_to(ROOT)}")

    # --- (3) Between-industry summary --------------------------------------
    tex_between = build_single_source_table(
        parsed_pair=parsed["between"],
        row_label_fn=row_label_industry,
        caption="Between-Industry Analysis: Syndicated Loans -- U.S.\\ "
                "and EU (new LST benchmark)",
        label="us_eu_between_lst",
        notes=NOTES_BETWEEN,
    )
    out3 = TABLES_DIR / "summary_between_us_eu.tex"
    out3.write_text(tex_between + "\n")
    print(f"  wrote {out3.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
