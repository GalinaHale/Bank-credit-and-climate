#!/usr/bin/env python3
"""Polish the raw etable output to match the Overleaf reference format:

  1. Rename "Loan Amount (Growth)" → "Loan Growth" in column headers
  2. Truncate R² fitstat values to 2 decimal places (0.18835 → 0.19)

Applied to every .tex fragment in OUT_TABLES (or output/tables).
Idempotent: safe to run repeatedly.
"""
import os, re
from pathlib import Path

_REPL_ROOT = os.environ.get("REPL_ROOT")
if not _REPL_ROOT:
    _REPL_ROOT = str(Path(__file__).resolve().parent.parent.parent)
_TABLES_DIR = os.environ.get("OUT_TABLES",
                             str(Path(_REPL_ROOT) / "output" / "tables"))
ROOT = Path(_TABLES_DIR)

RENAME = {
    "Loan Amount (Growth)": "Loan Growth",
    # Note on FE labels: some fragments in the Overleaf reference use the raw
    # dict stem (`us4b\\_ilst fixed effects`), others the prettified form
    # (`US ILST fixed effects`). Because the choice varies per fragment,
    # the label match is applied by match_overleaf_wrapper.py (which reads
    # the ref file) rather than by a blanket RENAME here.
}

# R² lines look like:
#   R$^2$   & 0.18835 & 0.83732 & & & 0.23273 & 0.84723 & & \\
# We want them rounded to 2 decimals.
R2_LINE_RE = re.compile(
    r'^(?P<label>\s*R\$\^\{?2\}?\$\s*&)(?P<body>[^\\]*)(?P<end>\\\\.*)$'
)
NUM_RE = re.compile(r'(-?\d+\.\d+)')


def round_r2_line(m):
    label, body, end = m.group("label"), m.group("body"), m.group("end")
    def repl(mn):
        v = float(mn.group(1))
        return f"{v:.2f}"
    return label + NUM_RE.sub(repl, body) + end



# 2026-11-11: remove any `\bottomrule \\` + empty-row padding before
# `\end{tabular}`. The author's convention is a bare `\bottomrule` right
# before `\end{tabular}`; the trailing `\\` adds an illegal empty row.
BOT_STRIP_RE = re.compile(
    r'(?P<indent>\s*)\\bottomrule\s*\\\\\s*\n(?:\s*\\\\\s*\n)*(?P<end>\s*\\end\{tabular\})',
    re.MULTILINE,
)


def strip_bottomrule_padding(text: str) -> str:
    def repl(m):
        indent = m.group("indent")
        end    = m.group("end")
        return f"{indent}\\bottomrule{end}"
    return BOT_STRIP_RE.sub(repl, text)


def polish(text):
    orig = text
    for old, new in RENAME.items():
        text = text.replace(old, new)
    lines = []
    for line in text.splitlines(keepends=True):
        m = R2_LINE_RE.match(line.rstrip("\n"))
        if m:
            trimmed = round_r2_line(m)
            lines.append(trimmed + ("\n" if line.endswith("\n") else ""))
        else:
            lines.append(line)
    polished_text = "".join(lines)
    polished_text = strip_bottomrule_padding(polished_text)
    return polished_text, polished_text != orig


def main():
    changed = 0
    skipped = 0
    for p in sorted(ROOT.glob("*.tex")):
        text = p.read_text()
        new_text, dirty = polish(text)
        if dirty:
            p.write_text(new_text)
            print(f"[polished] {p.name}")
            changed += 1
        else:
            skipped += 1
    print(f"# polished: {changed}   unchanged: {skipped}")


if __name__ == "__main__":
    main()
