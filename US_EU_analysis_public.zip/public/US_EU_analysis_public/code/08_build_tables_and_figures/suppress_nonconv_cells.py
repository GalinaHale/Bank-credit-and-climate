#!/usr/bin/env python3
"""suppress_nonconv_cells.py

For reg*.tex files whose feglm_safe tracker flagged non-convergence, inject
a footnote into the `\\end{minipage}` block naming which columns did not
converge. Coefficients and standard errors are KEPT in place; the note
tells the reader to interpret those specific columns with caution.

Rationale (user instruction, Nov 2026): replacing cells with "---" hides
information from the reader. We now report the point estimates and SEs
that the IRLS actually produced at the iteration cap, and flag them.

Target files (hard-coded for current audit):

  reg3brown_us2b_eu_country2b.tex               col 3 (US New Loan)
  reg3brown_us2b_eu_country2b_age.tex           col 3 (US New Loan)
  reg3brown_us4b_eu_country2b_age_gt10.tex      col 4 (US First Loan)
  reg3brown_us4b_eu_country2b_stan.tex          col 7 (EU New Loan)
  reg3brown_us4b_eu_country2b_ft_p90.tex        cols 3, 4, 7, 8 (all 4 brown logits)
  reg3brown_us4b_eu_country2b_p90.tex           cols 4, 7, 8 (US First + EU New/First)

Operates on two directories so the pipeline output and the Overleaf copy
stay in sync.

Usage:
  python3 script/suppress_nonconv_cells.py
"""
import re
import sys
from pathlib import Path
from typing import List

import os
# Public-tier contract: suppress runs ONLY on OUT_TABLES. The author's
# private Overleaf mirror is intentionally not inferred (the previous
# behavior silently wrote into a hardcoded Dropbox path when it happened
# to exist on the machine — a surprise side-effect for anyone running
# this package as a reviewer). A caller that genuinely wants the
# suppressor to touch an external mirror must set OVERLEAF_TABLES_DIR.
PIPE = Path(os.environ.get("OUT_TABLES", "output/tables"))
_overleaf_env = os.environ.get("OVERLEAF_TABLES_DIR")
VOCT = Path(_overleaf_env) if _overleaf_env else None

# (filename, 1-indexed column numbers that are non-converged)
# Updated after Nov 2 full-stage-06 rerun (glm.iter=300, fixef.iter=100000,
# chol()-based non-PD VCOV check in feglm_safe). 12 affected cells total,
# ALL in brown-industry (reg3brown) logit robustness tables. Headline
# benchmark tables (reg1-5 us4b_eu_country2b, NUTS, no2020, scope12sum,
# scope2_on_scope1, bank_industryyear) are all clean.
TARGETS = [
    # Reconciled 2026-11-04 against stage06_v24_final_ff.log — 11 expected
    # non-converged cells total (NOT 12). An earlier whitelist had col 8 on
    # the age table but the Nov 2 rerun only failed col 3 there; removing
    # col 8 prevents a false "did not converge" footnote on a converged logit.
    ("reg3brown_us2b_eu_country2b.tex",           [3]),         # US New Loan
    ("reg3brown_us2b_eu_country2b_age.tex",       [3]),         # US New Loan (was [3, 8] — col 8 reconverged)
    ("reg3brown_us4b_eu_country2b_age_gt10.tex",  [4]),         # US First Loan
    ("reg3brown_us4b_eu_country2b_stan.tex",      [7]),         # EU New Loan
    ("reg3brown_us4b_eu_country2b_ft_p90.tex",    [3, 4, 7, 8]),# 2 US + 2 EU
    ("reg3brown_us4b_eu_country2b_p90.tex",       [4, 7, 8]),   # 1 US + 2 EU
]

NOTE = (r" \textbf{Non-convergence:} the logit in column(s) %s did not "
        r"converge within the estimator's iteration limit. The reported "
        r"coefficients and standard errors are those returned at the "
        r"iteration cap and should be interpreted with caution.")

# `\sloppy` prefix forces LaTeX to fully justify the Notes paragraph (including
# the final line) by allowing larger inter-word stretch. Without it, long
# Notes paragraphs in Style B minipages render with a ragged right edge on
# the last line, which the user has flagged as "left-aligned instead of
# justified". Any newly-generated or newly-inserted Notes block must open
# with \sloppy before \footnotesize.
SLOPPY_PREFIX = r"\sloppy "


def patch_file(path: Path, cols: List[int]) -> bool:
    """Inject the non-convergence footnote into `path`. Coefficients and SEs
    are left untouched; only the `\\end{minipage}` block gets a new note.
    Also removes any legacy "---" suppression this script applied in prior
    runs, so the current coefficient/SE values from the latest regression
    build come through unchanged.
    """
    text = path.read_text(errors="ignore")
    if not text:
        return False
    original = text

    cols_label = ", ".join(f"({c})" for c in cols)
    note_literal = NOTE % cols_label

    # Strip ONLY footnote variants that this script previously injected.
    # Match any (\textbf|<TAB>extbf)}... up to the next ``caution.''
    # terminator (both historic phrasings; a prior buggy pass wrote the
    # TAB-corrupted form, so match both).
    text = re.sub(
        r"\s*(?:\\textbf|\textbf|\\\\textbf)\{Non-convergence:\}[^\n]*?caution\.",
        "",
        text,
    )

    # Insert the new note. Two wrapper flavours in play:
    #   (a) Style A: \end{minipage}\hspace*{\fill}\par\endgroup
    #   (b) Style B: \end{tabular}\par\endgroup
    if note_literal.strip() not in text:
        text, n = re.subn(
            r"(\\end\{minipage\})",
            lambda m: note_literal + "\n" + m.group(1),
            text,
            count=1,
        )
        if n == 0:
            # Fallback: inject the note as a standalone \begin{minipage}
            # block right after \end{tabular}, before the trailing
            # \par\endgroup / \end{table}.
            # Use a lambda so Python's re.sub replacement-string handling
            # does NOT interpret `\t` inside note_literal as a tab (which
            # was the historical "<TAB>extbf" corruption bug).
            # Match on \end{tabular} directly (works for the scalebox-only
            # wrapper style too, where \bottomrule and \end{tabular} are
            # separated by LaTeX line-break rows like `\\\n   \\\n`
            # which \s*\n could not span).
            insertion = (
                "\n"
                r"\begin{minipage}{\textwidth}" "\n"
                r"\footnotesize \textit{Notes:}"
                + note_literal + "\n"
                r"\end{minipage}"
            )
            text, n = re.subn(
                r"(\\end\{tabular\})",
                lambda m: m.group(1) + insertion,
                text,
                count=1,
            )

    if text == original:
        return False
    path.write_text(text)
    return True


def main():
    targets_dirs = [PIPE] + ([VOCT] if VOCT is not None else [])
    for d in targets_dirs:
        if not d.exists():
            print(f"skip: {d} does not exist", file=sys.stderr)
            continue
        for fname, cols in TARGETS:
            p = d / fname
            if not p.exists():
                print(f"  skip (no file): {p}")
                continue
            changed = patch_file(p, cols)
            print(f"  {'patched' if changed else 'no-op '}: "
                  f"{p.relative_to(p.parent.parent.parent)}  cols={cols}")


if __name__ == "__main__":
    main()
