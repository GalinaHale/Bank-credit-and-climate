# --- portability shim ---
import os
from pathlib import Path
_REPL_ROOT = os.environ.get("REPL_ROOT")
if not _REPL_ROOT:
    _REPL_ROOT = str(Path(__file__).resolve().parent.parent.parent)
_TABLES_DIR = os.environ.get("OUT_TABLES", str(Path(_REPL_ROOT) / "output" / "tables"))
# --- end shim ---

#!/usr/bin/env python3
# Rewrites every fragment in output/tables/tables_vJun2026_ILSTbenchmark/
# that is referenced from output/regression_tables_vJun2026_ILSTbenchmark.tex
# so that:
#   1. the tabular is wrapped in \scalebox{0.8}{...}
#   2. the whole (scaled tabular + notes) block is centered
#   3. Notes are inline in the fragment, aligned to the scaled-tabular width
# This makes each fragment self-contained and portrait-friendly.

import os, re, sys
from pathlib import Path

ROOT = Path(_REPL_ROOT) / "output"
FRAGD = Path(_TABLES_DIR)

# ---- Location/size-bucket descriptions (fully expanded macros) -------------
USSIL4 = (r"SIC 2-digit $\times$ Compustat HQ state $\times$ asset-size "
          r"\emph{quartiles} (within deal-year, ranked over the unique "
          r"firm-years in the U.S.\ loan panel) $\times$ deal-year")
USSIL2 = (r"SIC 2-digit $\times$ Compustat HQ state $\times$ asset-size "
          r"\emph{median split} (within deal-year, ranked over the unique "
          r"firm-years in the U.S.\ loan panel) $\times$ deal-year")
EUCT2  = (r"SIC 2-digit $\times$ country (ISO3 \texttt{loc}) $\times$ "
          r"asset-size \emph{median split} (within deal-year, ranked over "
          r"the unique firm-years in the EU loan panel) $\times$ deal-year")
EUNT4  = (r"SIC 2-digit $\times$ NUTS-2 region (2010 vintage) $\times$ "
          r"asset-size \emph{quartiles} (within deal-year, ranked over the "
          r"unique firm-years in the EU loan panel) $\times$ deal-year")
USSL4  = (r"Compustat HQ state $\times$ asset-size \emph{quartiles} "
          r"(within deal-year, ranked over the unique firm-years in the "
          r"U.S.\ loan panel) $\times$ deal-year")
USSL2  = (r"Compustat HQ state $\times$ asset-size \emph{median split} "
          r"(within deal-year, ranked over the unique firm-years in the "
          r"U.S.\ loan panel) $\times$ deal-year")
EUCT2L = (r"country (ISO3 \texttt{loc}) $\times$ asset-size "
          r"\emph{median split} (within deal-year, ranked over the unique "
          r"firm-years in the EU loan panel) $\times$ deal-year")
EUNT4L = (r"NUTS-2 region (2010 vintage) $\times$ asset-size "
          r"\emph{quartiles} (within deal-year, ranked over the unique "
          r"firm-years in the EU loan panel) $\times$ deal-year")

SIG = r"Significance levels: $^{***}p<0.001$, $^{**}p<0.01$, $^{*}p<0.05$."

def stdnotes(us, eu, sample):
    return (
        r"Columns~(1)--(4) report results for the U.S.\ sub-sample; "
        r"columns~(5)--(8) report results for the EU sub-sample. "
        r"In each block, the dependent variable in columns (1)/(5) is "
        r"loan-amount growth; (2)/(6) is log loan amount; (3)/(7) is the "
        r"probability of a new loan with a given lender (logit); (4)/(8) is the "
        r"probability of a first loan with a given lender (logit). "
        f"{sample} "
        r"All specifications include borrower, lender-year, and "
        r"ILST (Industry $\times$ Location $\times$ Size $\times$ Time) fixed "
        r"effects. "
        r"\emph{U.S.\ ILST cells:} " + us + r".\ \ "
        r"\emph{EU ILST cells:} " + eu + r". "
        r"Firm-level controls (log total assets, leverage, CAPEX/assets, "
        r"EBITDA/assets, all lagged one fiscal year) are included. "
        r"Robust standard errors clustered at the 2-digit SIC industry level "
        r"are in parentheses. " + SIG
    )

def lstnotes(us, eu, sample):
    return (
        r"Columns~(1)--(4) report results for the U.S.\ sub-sample; "
        r"columns~(5)--(8) report results for the EU sub-sample. "
        r"In each block, the dependent variable in columns (1)/(5) is "
        r"loan-amount growth; (2)/(6) is log loan amount; (3)/(7) is the "
        r"probability of a new loan with a given lender (logit); (4)/(8) is "
        r"the probability of a first loan with a given lender (logit). "
        f"{sample} "
        r"All specifications include borrower, lender-year, "
        r"and LST (\emph{Location} $\times$ \emph{Size} $\times$ \emph{Time}) "
        r"fixed effects --- the industry dimension is dropped from the cell "
        r"because the right-hand-side regressor is itself an industry-level "
        r"quantity. \emph{U.S.\ LST cells:} " + us + r".\ \ "
        r"\emph{EU LST cells:} " + eu + r". "
        r"Firm-level controls (log total assets, leverage, CAPEX/assets, "
        r"EBITDA/assets), all lagged one fiscal year, are included. "
        r"Robust standard errors clustered at the 2-digit SIC industry level "
        r"are in parentheses. " + SIG
    )

FULL   = "Full sample."
DIRTY  = "Dirty industries only."
NDIRTY = "Non-dirty industries only."
DIRTYFT = (r"Sample restricted to firms in dirty (brown) industries, "
           r"classified by the fixed-threshold (FT) scope-1 emission-intensity "
           r"rule (\texttt{industry\_brown\_class\_ft = "
           r"\"brown\_s1\_ft\"}).")
NDIRTYFT = (r"Sample restricted to firms in non-dirty industries (FT scope-1 "
            r"rule; \texttt{industry\_brown\_class\_ft = "
            r"\"non\_brown\_s1\_ft\"}).")
DIRTYFT_SHORT = (r"Sample restricted to firms in dirty (brown) industries, "
                 r"classified by the fixed-threshold (FT) scope-1 "
                 r"emission-intensity rule.")
NDIRTYFT_SHORT = (r"Sample restricted to firms in non-dirty industries (FT "
                  r"scope-1 rule).")
DIRTY_TV = (r"Sample restricted to firms classified as dirty under the "
            r"time-varying top-25\% rule "
            r"(\texttt{industry\_brown\_class\_tv == \"brown\_s1\"}).")
NDIRTY_TV = (r"Sample restricted to firms classified as non-dirty under the "
             r"time-varying top-25\% rule "
             r"(\texttt{industry\_brown\_class\_tv == "
             r"\"non\_brown\_s1\"}).")
DIRTY_FTP90 = (r"Sample restricted to firms classified as dirty under the "
               r"fixed top-10\% rule "
               r"(\texttt{industry\_brown\_class\_ft\_p90 == "
               r"\"brown\_s1\_ft\_p90\"}).")
NDIRTY_FTP90 = (r"Sample restricted to firms classified as non-dirty under "
                r"the fixed top-10\% rule "
                r"(\texttt{industry\_brown\_class\_ft\_p90 == "
                r"\"non\_brown\_s1\_ft\_p90\"}).")
DIRTY_P90 = (r"Sample restricted to firms classified as dirty under the "
             r"time-varying top-10\% rule "
             r"(\texttt{industry\_brown\_class\_p90 == "
             r"\"brown\_s1\_p90\"}).")
NDIRTY_P90 = (r"Sample restricted to firms classified as non-dirty under the "
              r"time-varying top-10\% rule "
              r"(\texttt{industry\_brown\_class\_p90 == "
              r"\"non\_brown\_s1\_p90\"}).")
NDIRTY_ROB = "Sample restricted to firms in non-dirty industries."

AGE_TAIL = (
    r" The specifications additionally include $\text{Firm Age}_{t-1}$ = "
    r"deal-year $-1-$ \texttt{yearfounded} (Trucost) as a firm-level "
    r"control; because ILST cells absorb (industry $\times$ location "
    r"$\times$ size bucket $\times$ deal-year) and the borrower fixed "
    r"effect absorbs \texttt{yearfounded}, within-cell variation in firm "
    r"age is nearly zero and the coefficient is either dropped as collinear "
    r"or returns inflated standard errors."
)

def N(us, eu, sample, kind="std", age=False):
    body = stdnotes(us, eu, sample) if kind == "std" else lstnotes(us, eu, sample)
    if age:
        # Splice the age caveat in before the significance-levels sentence.
        body = body.replace(" " + SIG, AGE_TAIL + " " + SIG)
    return body

# ---- fragment -> notes -----------------------------------------------------
NOTES = {
    # main-us4b
    "reg1_us4b_eu_country2b":            N(USSIL4, EUCT2, FULL),
    "reg2_us4b_eu_country2b":            N(USSIL4, EUCT2, FULL),
    "reg3brown_us4b_eu_country2b":       N(USSIL4, EUCT2, DIRTYFT),
    "reg4nonbrown_us4b_eu_country2b":    N(USSIL4, EUCT2, NDIRTYFT),
    # main-us2b
    "reg1_us2b_eu_country2b":            N(USSIL2, EUCT2, FULL),
    "reg2_us2b_eu_country2b":            N(USSIL2, EUCT2, FULL),
    "reg3brown_us2b_eu_country2b":       N(USSIL2, EUCT2, DIRTYFT_SHORT),
    "reg4nonbrown_us2b_eu_country2b":    N(USSIL2, EUCT2, NDIRTYFT_SHORT),
    # rob-nuts (reg4 only)
    "reg4nonbrown_us4b_eu_nuts2_4b_ROBUST": N(USSIL4, EUNT4, NDIRTY_ROB),
    "reg4nonbrown_us2b_eu_nuts2_4b_ROBUST": N(USSIL2, EUNT4, NDIRTY_ROB),
    # threshold robustness
    "reg3brown_us4b_eu_country2b_tv":     N(USSIL4, EUCT2, DIRTY_TV),
    "reg4nonbrown_us4b_eu_country2b_tv":  N(USSIL4, EUCT2, NDIRTY_TV),
    "reg3brown_us4b_eu_country2b_ft_p90": N(USSIL4, EUCT2, DIRTY_FTP90),
    "reg4nonbrown_us4b_eu_country2b_ft_p90": N(USSIL4, EUCT2, NDIRTY_FTP90),
    "reg3brown_us4b_eu_country2b_p90":    N(USSIL4, EUCT2, DIRTY_P90),
    "reg4nonbrown_us4b_eu_country2b_p90": N(USSIL4, EUCT2, NDIRTY_P90),
    # reg5 (LST)
    "reg5_between_us4b_eu_country2b":     N(USSL4, EUCT2L, FULL, kind="lst"),
    "reg5_between_us2b_eu_country2b":     N(USSL2, EUCT2L, FULL, kind="lst"),
    "reg5_between_us4b_eu_nuts2_4b_ROBUST": N(USSL4, EUNT4L, FULL, kind="lst"),
    "reg5_between_us2b_eu_nuts2_4b_ROBUST": N(USSL2, EUNT4L, FULL, kind="lst"),
    # age robustness — us4b
    "reg1_us4b_eu_country2b_age":            N(USSIL4, EUCT2, FULL, age=True),
    "reg2_us4b_eu_country2b_age":            N(USSIL4, EUCT2, FULL, age=True),
    "reg3brown_us4b_eu_country2b_age":       N(USSIL4, EUCT2, DIRTY, age=True),
    "reg4nonbrown_us4b_eu_country2b_age":    N(USSIL4, EUCT2, NDIRTY, age=True),
    # age robustness — us2b
    "reg1_us2b_eu_country2b_age":            N(USSIL2, EUCT2, FULL, age=True),
    "reg2_us2b_eu_country2b_age":            N(USSIL2, EUCT2, FULL, age=True),
    "reg3brown_us2b_eu_country2b_age":       N(USSIL2, EUCT2, DIRTY, age=True),
    "reg4nonbrown_us2b_eu_country2b_age":    N(USSIL2, EUCT2, NDIRTY, age=True),
    # age robustness for NUTS
    "reg4nonbrown_us4b_eu_nuts2_4b_ROBUST_age": N(USSIL4, EUNT4, NDIRTY, age=True),
    "reg4nonbrown_us2b_eu_nuts2_4b_ROBUST_age": N(USSIL2, EUNT4, NDIRTY, age=True),
}

# scope2 diagnostic — small 2-col; notes are custom
SCOPE2_NOTES = (
    r"Scope 2 emission intensity regressed on Scope 1 emission intensity. "
    r"Column (1) reports the U.S.\ sub-sample and includes borrower "
    r"(borrower) and industry-year fixed effects "
    r"($n=58{,}700$). Column (2) reports the EU sub-sample and adds "
    r"country (\texttt{loc}) fixed effects ($n=38{,}894$). Robust standard "
    r"errors clustered at the 2-digit SIC industry level are in parentheses. "
    + SIG +
    r" The point estimate on \emph{Scope 1 Emission Intensity} is "
    r"statistically and economically indistinguishable from zero on the "
    r"U.S.\ side (coef.\ $-0.000$, within-$R^2 \approx 3\times 10^{-5}$) "
    r"and small and marginally significant on the EU side "
    r"(coef.\ $0.054$, $p\approx 0.07$, within-$R^2 \approx 0.066$), "
    r"confirming that the two scopes are sufficiently independent to enter "
    r"the loan regressions separately."
)

# ---- fragment rewriter -----------------------------------------------------
TAB_RE = re.compile(
    r"(\\begin\{tabular\}.*?\\end\{tabular\})",
    re.DOTALL,
)

TEMPLATE = r"""\begingroup
\centering
\sbox1{\footnotesize
__TABULAR__
}%
\sbox0{\scalebox{0.8}{\usebox1}}%
\ifdim\wd0>\textwidth
  \sbox0{\resizebox{\textwidth}{!}{\usebox1}}%
\fi
\noindent\hspace*{\fill}\begin{minipage}{\wd0}
%\centering
\usebox0\par\vspace{3pt}
%\raggedright
\footnotesize\textit{Notes:} __NOTES__%
\end{minipage}\hspace*{\fill}\par
\endgroup
"""

def rewrite(path: Path, notes: str) -> bool:
    text = path.read_text()
    m = TAB_RE.search(text)
    if not m:
        print(f"[skip] no tabular found in {path.name}", file=sys.stderr)
        return False
    tab = m.group(1)
    new = TEMPLATE.replace("__TABULAR__", tab).replace("__NOTES__", notes)
    if text.strip() == new.strip():
        return False
    path.write_text(new)
    return True

def main():
    n_changed = 0
    for stem, notes in NOTES.items():
        p = FRAGD / f"{stem}.tex"
        if not p.exists():
            print(f"[missing] {p.name}", file=sys.stderr)
            continue
        if rewrite(p, notes):
            print(f"[rewrote] {p.name}")
            n_changed += 1
    # scope2
    p = FRAGD / "scope2_on_scope1_intensity.tex"
    if p.exists() and rewrite(p, SCOPE2_NOTES):
        print(f"[rewrote] {p.name}")
        n_changed += 1
    print(f"# fragments rewritten: {n_changed}")

if __name__ == "__main__":
    main()
