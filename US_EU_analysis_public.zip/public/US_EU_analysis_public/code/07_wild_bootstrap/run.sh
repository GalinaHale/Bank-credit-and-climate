#!/usr/bin/env bash
# Stage 07 — wild cluster bootstrap.
#
# Two modes:
#   1. --use-shipped-results  (default) — skip the server R script and use the
#      pre-computed CSVs in code/07_wild_bootstrap/results_csv/ to build the
#      _WILDBS.tex and _WILDBS_B500.tex fragments in stage 08.
#   2. --run-server           — runs the bootstrap here (NOT laptop-runnable
#      for B=500; needs ~16 cores and ~8 hours).
#
# The Python builder in stage 08 reads whichever CSVs are in results_csv/.
set -euo pipefail
cd "$(dirname "$0")/../.."
export REPL_ROOT="$(pwd)"

MODE="${1:---use-shipped-results}"

case "$MODE" in
    --use-shipped-results)
        shopt -s nullglob
        shipped=(code/07_wild_bootstrap/results_csv/wildbs_pvalues_B*.csv)
        if (( ${#shipped[@]} == 0 )); then
            echo "[07] No shipped result CSVs in code/07_wild_bootstrap/results_csv/."
            echo "     Either drop them in from a prior server run, or use --run-server."
            exit 1
        fi
        mkdir -p output/tables
        # Fixed 2026-11-04: validate the shipped CSV before copying. Previously
        # stage 07 blindly copied whatever was in results_csv/, so a stale CSV
        # (e.g. one computed on the pre-corrected sample) would silently flow
        # into stage 08 and ship as final. Minimum validation: sanity check the
        # expected header and a non-empty data row count.
        for src in "${shipped[@]}"; do
            if [ ! -s "$src" ]; then
                echo "[07] ERROR: $src is empty."
                exit 1
            fi
            hdr=$(head -1 "$src")
            case "$hdr" in
                *family*panel*parameter*)
                    rowcount=$(($(wc -l < "$src") - 1))
                    if [ "$rowcount" -lt 40 ]; then
                        echo "[07] ERROR: $src has only $rowcount data rows (expected ≥40 unique (family,panel,parameter,side) keys)."
                        echo "            Likely an interrupted or partial server run. Re-run with --run-server before shipping."
                        exit 1
                    fi
                    dst="output/tables/$(basename "$src")"
                    cp -p "$src" "$dst"
                    echo "[07] copied $(basename "$src") ($rowcount rows) -> output/tables/"
                    ;;
                *)
                    echo "[07] ERROR: $src header doesn't look like a wildbs output: '$hdr'"
                    exit 1
                    ;;
            esac
        done
        echo "[07] Using shipped WILDBS result CSVs (Stage 08 reads output/tables/)."
        ;;
    --run-server)
        echo "[07] Running wild cluster bootstrap on this machine."
        echo "     Requires parallel + ample RAM/cores (B=500 ≈ 6 days on a modest server; see REQUIREMENTS.md)."
        # Point the server script at the public tier's neutral panel and
        # output directory via config_public.R's ANALYSIS_INPUT_RDS.
        export WILDBS_OUT_DIR="$REPL_ROOT/output/tables"
        export ANALYSIS_INPUT_RDS="${ANALYSIS_INPUT_RDS:-$REPL_ROOT/data/analysis_input.rds}"
        WILDBS_B="${WILDBS_B:-500}" WILDBS_NCORES="${WILDBS_NCORES:-6}" \
            Rscript code/07_wild_bootstrap/server/run_new_benchmark_wildbs.R
        ;;
    *)
        echo "Unknown mode: $MODE  (use --use-shipped-results or --run-server)"
        exit 1
        ;;
esac
