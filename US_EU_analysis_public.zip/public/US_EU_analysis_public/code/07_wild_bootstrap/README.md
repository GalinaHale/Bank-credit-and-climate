# Stage 07 — wild cluster bootstrap

## What this stage does

Produces the wild cluster bootstrap p-values for reg1–reg5 that Stage 08 pivots into the `_WILDBS_B500.tex` fragments. The linear (feols) outcomes Loan Growth and Log(Loan Amount) use a **self-contained CGM wild-cluster bootstrap** (Cameron, Gelbach, Miller 2008) implemented directly in `server/run_new_benchmark_wildbs.R` with a Rademacher weight vector; both Wild Cluster Restricted (WCR) and Wild Cluster Unrestricted (WCU) variants are computed. The two binary outcomes (New Loan, First Loan) use feglm logit and are bootstrapped with a **pairs cluster bootstrap** instead, because the fixest feglm interface does not admit the WCR/WCU score decomposition. Non-converged original fits halt the family; non-converged replicates are counted as failures and reported in the output CSV.

The paper reports the **B = 500** production run. A B = 500 CSV ships under `results_csv/wildbs_pvalues_B500.csv`.

Two paths for the replicator:

### Path A — use the shipped B=500 CSV (default)

The shipped `results_csv/wildbs_pvalues_B500.csv` is a frozen output from a prior server run. Stage 08's `build_wildbs_tables.py` reads it directly and produces the `reg{1..5}_us4b_eu_country2b_WILDBS_B500.tex` fragments. No R needed on the replicator's machine.

```bash
bash code/07_wild_bootstrap/run.sh --use-shipped-results
```

(the default when `run.sh` is invoked with no args).

### Path B — rebuild the bootstrap on a server

`server/run_new_benchmark_wildbs.R` is the exact script that produced the shipped CSV. It refits reg1–reg5, then loops over 12 coefficients × 5 regressions × B iterations. Env vars:

- `WILDBS_B` — bootstrap size (default 500).
- `WILDBS_NCORES` — parallel cores (default 6).
- `WILDBS_SKIP_WCU` — skip the WCU refit; keep only WCR.

```bash
WILDBS_B=500 WILDBS_NCORES=16 bash code/07_wild_bootstrap/run.sh --run-server
```

## Inputs

- `data/analysis_input.rds` (the neutral panel produced by the Tier-2 exporter and read by every stage-06 runner too).
  Override with `WILDBS_PANEL=<path>`.

## Outputs

Server mode (`--run-server`) writes to `output/tables/wildbs_pvalues_B{B}.csv` — the exact path `code/08_build_tables_and_figures/build_wildbs_tables.py` reads from. Shipped-results mode (`--use-shipped-results`) consumes the CSV at `code/07_wild_bootstrap/results_csv/wildbs_pvalues_B{B}.csv`.

CSV schema (post 2026-07 patch): one row per (family × panel × parameter × side), columns `family, panel, parameter, side` + per-outcome blocks `(b, se, t, p_wcr, p_wcu, err)` for the two feols outcomes (loan growth, log loan amount) and `(b, se, p_pairs, err)` for the two feglm logit outcomes (new loan, first loan). 12 rows per family per panel = 120 rows total across 5 families × 2 panels. `build_wildbs_tables.py` pivots this into the paper's `_WILDBS_B500.tex` fragments.

## Wall clock

- Path A: ~5 seconds.
- Path B: ~6 days at B = 500 on 16 cores.
