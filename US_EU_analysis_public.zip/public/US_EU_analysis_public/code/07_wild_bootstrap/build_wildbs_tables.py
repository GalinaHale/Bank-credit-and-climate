#!/usr/bin/env python3
# Stub — the canonical builder lives in Stage 08.
#
# This file previously held a Sep-16 copy of the builder that did not know
# about the B500 output filename and would silently build the wrong tex
# fragments. Keeping it as a stub so an accidental invocation points at
# the correct script rather than running stale code.
import os, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
REPL_ROOT = os.environ.get("REPL_ROOT") or HERE.parents[1]
canonical = Path(REPL_ROOT) / "code" / "08_build_tables_and_figures" / "build_wildbs_tables.py"
sys.stderr.write(
    f"[07/build_wildbs_tables.py] This builder has moved to Stage 08. Run:\n"
    f"  python3 {canonical}\n"
    f"or `bash code/08_build_tables_and_figures/run.sh`.\n"
)
sys.exit(2)
