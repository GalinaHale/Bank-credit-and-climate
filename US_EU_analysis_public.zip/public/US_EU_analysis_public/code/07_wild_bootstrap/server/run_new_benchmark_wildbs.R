#!/usr/bin/env Rscript
#
# run_new_benchmark_wildbs.R
# ---------------------------------------------------------------------------
# Wild cluster bootstrap p-values for the NEW benchmark reg1-5 (no age,
# non-STAN family).
#
# Method: self-contained Cameron-Gelbach-Miller (2008) wild cluster
# bootstrap (correctness reviewed 2026-07). We DO NOT use fwildclusterboot
# (archived on CRAN; not installable in this R).
#
# For each Paris-interaction parameter of interest we compute:
#   WCR  -- restricted-null wild cluster bootstrap (recommended default)
#           * fit restricted model dropping only that interaction (H0: b=0)
#           * y* = fit_r + w * res_r,   w in {-1,+1} sampled per cluster
#           * refit unrestricted on y*, t*_wcr = t-stat on the param
#           * p = (1 + sum |t*_wcr| >= |t_o|) / (B + 1)
#   WCU  -- unrestricted wild cluster bootstrap (cross-check)
#           * y* = fit_u + w * res_u
#           * refit unrestricted; t*_wcu = (b* - b_o) / se*
#           * p = (1 + sum |t*_wcu| >= |t_o|) / (B + 1)
# Cluster ~industry_id  (matches the analytic-SE cluster).
#
# feols outcomes covered by wild cluster bootstrap:
#   g = outcome_loan_growth
#   h = outcome_log_loan
#
# feglm binomial-logit outcomes (i, l) do NOT admit the WCR/WCU
# constructions above (residuals are pseudo-residuals on the link scale
# with a fitted-value-dependent variance). For these we fall back to a
# pairs cluster bootstrap: resample SIC-2 clusters with replacement,
# refit feglm, two-sided p from bootstrap coef distribution vs zero.
# This mirrors the fallback in credit_realloc_EERrev_regs.R.
#
# Headline spec: US ILST = state x 4 buckets x industry_id x deal_year,
#                EU ILST = country x 2 buckets x industry_id x deal_year,
#                reg5 uses LST (drops industry dim).
# FE: firm_id + bank_year_fe + (ILST for reg1-4 / LST for reg5)
#
# Config:
#   env var WILDBS_B controls B. Default 10 (smoke test). Move to 500 next.
#
# Output:
#   output/tables/tables_vJun2026_ILSTbenchmark/wildbs_pvalues_B{B}.csv
# ---------------------------------------------------------------------------

suppressPackageStartupMessages({
    library(data.table)
    library(fixest)
    library(parallel)
})
# Serial config (main thread). Inside each parallel worker we drop fixest to
# 1 thread so N workers x M threads don't fight the OS scheduler.
setDTthreads(4)
setFixest_nthreads(4)
setFixest_notes(FALSE)
set.seed(20260706)

NCORES <- if (nzchar(Sys.getenv("WILDBS_NCORES")))
    as.integer(Sys.getenv("WILDBS_NCORES")) else 6L
cat(sprintf("Parallel workers per bootstrap loop: %d\n", NCORES))

# Skip the WCU (unrestricted) variant when set — halves the wild-loop feols
# refits. Default FALSE (keep both WCR and WCU). Env: WILDBS_SKIP_WCU=1
SKIP_WCU <- nzchar(Sys.getenv("WILDBS_SKIP_WCU")) &&
    Sys.getenv("WILDBS_SKIP_WCU") %in% c("1", "TRUE", "true", "yes")
cat(sprintf("Skip WCU variant: %s\n", SKIP_WCU))

# ---- CONFIG ---------------------------------------------------------------
B <- if (nzchar(Sys.getenv("WILDBS_B"))) as.integer(Sys.getenv("WILDBS_B")) else 10L
stopifnot(B >= 5L)
cat(sprintf("Bootstrap replicates: B = %d\n", B))

# Paths — overridable via env vars for portability. Defaults assume the
# server bundle lives at <bundle>/code/07_wild_bootstrap/server/ and the
# panel/output sit at <bundle>/data/intermediate and <bundle>/output.
data_dir   <- Sys.getenv("WILDBS_DATA_DIR",
                         file.path("..", "..", "..", "data", "intermediate"))
output_dir <- Sys.getenv("WILDBS_OUT_DIR",
                         file.path("..", "..", "..", "output", "tables"))
if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)
out_csv     <- file.path(output_dir, sprintf("wildbs_pvalues_B%d.csv", B))
partial_csv <- file.path(output_dir, sprintf("wildbs_pvalues_B%d.partial.csv", B))

# ---- 1. Load panel + ratios + bank_year_fe ---------------------------------
# Use the finalized Aldasoro-filtered panel. Override by setting WILDBS_PANEL
# to any .rda file that contains data_us and data_eu.
panel_path <- Sys.getenv("ANALYSIS_INPUT_RDS",
    file.path(data_dir, "analysis_input.rds"))
cat(sprintf("Loading panel: %s\n", panel_path))
if (requireNamespace("digest", quietly = TRUE)) {
    cat(sprintf("Panel SHA-256: %s\n",
                digest::digest(file = panel_path, algo = "sha256")))
} else {
    cat("(digest not installed — skipping panel SHA-256 report)\n")
}
.ai <- readRDS(panel_path)
data_us <- data.table::as.data.table(.ai$panel_loan)[sample_region == "US"]
data_eu <- data.table::as.data.table(.ai$panel_loan)[sample_region == "EU"]

# ---- PREFLIGHT: assert panel matches the current estimation sample ---------
# Set WILDBS_PREFLIGHT_ONLY=1 to run the preflight and exit without any
# bootstrap work. Set WILDBS_PREFLIGHT_SKIP=1 to skip (not recommended).
PREFLIGHT_ONLY <- nzchar(Sys.getenv("WILDBS_PREFLIGHT_ONLY"))
if (!nzchar(Sys.getenv("WILDBS_PREFLIGHT_SKIP"))) {
    cat("---- PREFLIGHT ----\n")
    cat(sprintf("  data_us rows: %d  (expect 101,351)\n", nrow(data_us)))
    cat(sprintf("  data_eu rows: %d  (expect 62,026)\n",  nrow(data_eu)))
    needed <- c("firm_age_lag", "scope1_log_intensity_lag",
                "scope1_log_rel_intensity_lag",
                "scope1_log_intensity_industry_lag")
    miss_us <- setdiff(needed, names(data_us))
    miss_eu <- setdiff(needed, names(data_eu))
    if (length(miss_us) || length(miss_eu)) {
        stop("[preflight] missing columns on panel: US=",
             paste(miss_us, collapse=","), " EU=", paste(miss_eu, collapse=","))
    }
    cat("  all required intensity + firm-age columns present.\n")
    # Deferred: the reg1 N assertion needs us4b_ilst/eu2b_ilst, which are
    # built later by build_loansample_ilst. Run after that; see
    # "---- PREFLIGHT (reg1 N) ----" block below.
    if (PREFLIGHT_ONLY) {
        cat("  (reg1 N assertion runs after ILST build; PREFLIGHT_ONLY will exit there)\n")
    }
    cat("---- PREFLIGHT (row count + columns) OK ----\n\n")
}
data_us <- add_ratios(data_us)
data_eu <- add_ratios(data_eu)
data_us[, bank_year_fe := as.factor(bank_id):as.factor(deal_year)]
data_eu[, bank_year_fe := as.factor(bank_id):as.factor(deal_year)]

# paris is a factor in the vJun2026 panel; convert to two numeric indicators
# so x:paris_pre + x:paris_post produces one coef per interaction (instead
# of the factor form's paris0/paris1 dummies, which R names inconsistently
# and which caused the original EERrev_regs.R wild-bootstrap block to
# silently return NAs). The two encodings give identical design matrices
# and identical fitted values.
data_us[, `:=`(paris_pre  = as.integer(as.character(paris) == "0"),
               paris_post = as.integer(as.character(paris) == "1"))]
data_eu[, `:=`(paris_pre  = as.integer(as.character(paris) == "0"),
               paris_post = as.integer(as.character(paris) == "1"))]

# ---- 2. Cell builders (verbatim from existing runners) --------------------
build_loansample_lst <- function(panel, loc_col, n_buckets, label,
                                 colname_prefix) {
    p <- copy(panel); setDT(p)
    p[, fyear_match := deal_year - 1L]
    fy <- unique(
        p[!is.na(at_rank_within_year) &
          !is.na(get(loc_col)) & get(loc_col) != "",
          .(firm_id, fyear_match,
            loc_eff = as.character(get(loc_col)), at_rank_within_year)],
        by = c("firm_id", "fyear_match")
    )
    fy[, size_bucket := as.integer(ceiling(
            at_rank_within_year * n_buckets
        )), by = fyear_match]
    fy[size_bucket > n_buckets, size_bucket := n_buckets]
    fy[size_bucket < 1L,        size_bucket := 1L]
    fy[, lst := paste(loc_eff, size_bucket, fyear_match, sep = "_")]
    keep <- fy[, .(firm_id, fyear_match, sb = size_bucket, lst_new = lst)]
    setnames(keep, c("sb","lst_new"),
             c(paste0(colname_prefix, "_size_bucket"),
               paste0(colname_prefix, "_lst")))
    p <- merge(p, keep, by = c("firm_id", "fyear_match"), all.x = TRUE)
    p[, fyear_match := NULL]
    cat(sprintf("  %-30s rows w/ LST: %d/%d (%.1f%%)\n",
                label, sum(!is.na(p[[paste0(colname_prefix, "_lst")]])),
                nrow(p),
                100*mean(!is.na(p[[paste0(colname_prefix, "_lst")]]))))
    p
}

cat("\nBuilding US cells...\n")
data_us <- build_loansample_ilst(data_us, "state", 4L, "US state x 4b (ilst)", "us4b")
data_us <- build_loansample_lst (data_us, "state", 4L, "US state x 4b (lst)",  "us4b")
cat("\nBuilding EU cells...\n")
data_eu <- build_loansample_ilst(data_eu, "loc",   2L, "EU country x 2b (ilst)", "eu2b")
data_eu <- build_loansample_lst (data_eu, "loc",   2L, "EU country x 2b (lst)",  "eu2b")

# ---- 3. Bootstrap helpers -------------------------------------------------
# WCR + WCU wild cluster bootstrap for a single feols model / single base var.
# `base_var` is either a Paris-interacted intensity variable (with side="pre"
# or side="post" -> tests base_var:paris_side) or a standalone control (with
# side=NULL -> tests the coefficient on base_var itself).
# Returns list(p_wcr, p_wcu, t_obs, b_obs, se_obs, n_obs, n_clust).
wcb_feols_1param <- function(rhs, fe_str, y_var, panel, base_var,
                             cluster_var = "industry_id", B = 10L,
                             side = "post") {
    fml_u <- as.formula(sprintf("%s ~ %s | %s", y_var, rhs, fe_str))
    m_o <- feols(fml_u, data = panel, cluster = as.formula(paste0("~", cluster_var)),
                 warn = FALSE, notes = FALSE)

    keep <- obs(m_o)
    sub  <- panel[keep]
    m_o  <- feols(fml_u, data = sub,   cluster = as.formula(paste0("~", cluster_var)),
                  warn = FALSE, notes = FALSE)

    ct <- m_o$coeftable
    param <- resolve_param(rownames(ct), base_var, side)
    if (is.na(param))
        return(list(p_wcr = NA_real_, p_wcu = NA_real_,
                    t_obs = NA_real_, b_obs = NA_real_, se_obs = NA_real_,
                    n_obs = nobs(m_o), n_clust = NA_integer_,
                    err = paste0("param not found for base ", base_var,
                                 if (is.null(side)) "" else paste0(" side=", side))))
    b_o  <- ct[param, 1]; se_o <- ct[param, 2]; t_o <- ct[param, 3]

    # Restricted RHS: drop the tested term (Paris interaction or standalone control)
    drop_term <- if (is.null(side)) base_var else paste0(base_var, ":paris_", side)
    rhs_r <- gsub(paste0(gsub("([\\W])", "\\\\\\1", drop_term, perl = TRUE),
                         "\\s*\\+\\s*"), "", rhs)
    if (identical(rhs_r, rhs)) {
        rhs_r <- gsub(paste0("\\+\\s*",
                             gsub("([\\W])", "\\\\\\1", drop_term, perl = TRUE)),
                      "", rhs)
    }
    if (identical(rhs_r, rhs)) {
        return(list(p_wcr = NA_real_, p_wcu = NA_real_,
                    t_obs = t_o, b_obs = b_o, se_obs = se_o,
                    n_obs = nobs(m_o), n_clust = NA_integer_,
                    err = paste0("could not drop ", drop_term, " from RHS")))
    }
    fml_r <- as.formula(sprintf("%s ~ %s | %s", y_var, rhs_r, fe_str))
    m_r <- tryCatch(feols(fml_r, data = sub,
                          cluster = as.formula(paste0("~", cluster_var)),
                          warn = FALSE, notes = FALSE),
                    error = function(e) NULL)
    if (is.null(m_r)) {
        return(list(p_wcr = NA_real_, p_wcu = NA_real_,
                    t_obs = t_o, b_obs = b_o, se_obs = se_o,
                    n_obs = nobs(m_o), n_clust = NA_integer_,
                    err = "restricted refit failed"))
    }
    keep_r <- obs(m_r)
    if (length(keep_r) < nrow(sub)) {
        sub    <- sub[keep_r]
        m_o    <- feols(fml_u, data = sub,
                        cluster = as.formula(paste0("~", cluster_var)),
                        warn = FALSE, notes = FALSE)
        m_r    <- feols(fml_r, data = sub,
                        cluster = as.formula(paste0("~", cluster_var)),
                        warn = FALSE, notes = FALSE)
        ct     <- m_o$coeftable
        param  <- resolve_param(rownames(ct), base_var, side)
        b_o    <- ct[param, 1]; se_o <- ct[param, 2]; t_o <- ct[param, 3]
    }

    fit_r <- predict(m_r); res_r <- resid(m_r)
    fit_u <- predict(m_o); res_u <- resid(m_o)
    stopifnot(length(res_r) == nrow(sub), length(res_u) == nrow(sub))

    gid <- as.character(sub[[cluster_var]])
    ug  <- unique(gid)

    fml_u_star <- as.formula(sprintf("ystar ~ %s | %s", rhs, fe_str))
    cluster_fmla <- as.formula(paste0("~", cluster_var))

    # Parallel bootstrap loop. Each worker copies sub (data.table copy-on-write),
    # constructs its own y* under WCR and WCU, refits unrestricted feols twice,
    # and returns (t_wcr, t_wcu). Fixest is dropped to 1 thread inside the
    # worker so N workers * M threads don't oversubscribe cores.
    one_rep <- function(bidx) {
        setFixest_nthreads(1); setFixest_notes(FALSE); setDTthreads(1)
        sub_l <- copy(sub)
        w_g <- sample(c(-1, 1), length(ug), replace = TRUE); names(w_g) <- ug
        w_i <- w_g[gid]
        # WCR
        sub_l[, ystar := fit_r + w_i * res_r]
        m_b <- tryCatch(feols(fml_u_star, data = sub_l, cluster = cluster_fmla,
                              warn = FALSE, notes = FALSE),
                        error = function(e) NULL)
        if (is.null(m_b)) t_wcr_b <- NA_real_ else {
            p_b <- resolve_param(rownames(m_b$coeftable), base_var, side)
            t_wcr_b <- if (is.na(p_b)) NA_real_ else m_b$coeftable[p_b, 3]
        }
        # WCU (skip if SKIP_WCU=TRUE — halves the wild-loop refits)
        if (SKIP_WCU) {
            t_wcu_b <- NA_real_
        } else {
            sub_l[, ystar := fit_u + w_i * res_u]
            m_b <- tryCatch(feols(fml_u_star, data = sub_l, cluster = cluster_fmla,
                                  warn = FALSE, notes = FALSE),
                            error = function(e) NULL)
            if (is.null(m_b)) t_wcu_b <- NA_real_ else {
                p_b <- resolve_param(rownames(m_b$coeftable), base_var, side)
                t_wcu_b <- if (is.na(p_b)) NA_real_ else
                    (m_b$coeftable[p_b, 1] - b_o) / m_b$coeftable[p_b, 2]
            }
        }
        c(t_wcr_b, t_wcu_b)
    }

    reps <- suppressWarnings(
        mclapply(seq_len(B), one_rep, mc.cores = NCORES,
                 mc.preschedule = TRUE, mc.set.seed = TRUE))
    tmat <- do.call(rbind, reps)
    t_wcr <- tmat[, 1]; t_wcu <- tmat[, 2]

    fail_wcr <- sum(is.na(t_wcr)); fail_wcu <- sum(is.na(t_wcu))
    valid_wcr <- sum(!is.na(t_wcr))
    valid_wcu <- sum(!is.na(t_wcu))
    # Minimum fraction of valid replicates required for a valid p-value.
    # Below the threshold we return NA rather than the degenerate (1+0)/(0+1)=1.
    MIN_VALID_FRAC <- 0.5
    p_wcr <- if (valid_wcr / B < MIN_VALID_FRAC) NA_real_ else
             (1 + sum(abs(t_wcr) >= abs(t_o), na.rm = TRUE)) / (valid_wcr + 1)
    p_wcu <- if (valid_wcu / B < MIN_VALID_FRAC) NA_real_ else
             (1 + sum(abs(t_wcu) >= abs(t_o), na.rm = TRUE)) / (valid_wcu + 1)
    list(p_wcr = p_wcr, p_wcu = p_wcu,
         t_obs = t_o, b_obs = b_o, se_obs = se_o,
         n_obs = nobs(m_o), n_clust = length(ug),
         err = if (fail_wcr + fail_wcu == 0) "" else
             sprintf("%d/%d WCR NAs, %d/%d WCU NAs", fail_wcr, B, fail_wcu, B))
}

# Pairs cluster bootstrap for feglm (verbatim from credit_realloc_EERrev_regs.R)
pairs_cluster_bs_feglm_1param <- function(rhs, fe_str, y_var, panel, base_var,
                                          cluster_var = "industry_id", B = 10L,
                                          side = "post") {
    fml <- as.formula(sprintf("%s ~ %s | %s", y_var, rhs, fe_str))
    m_o <- tryCatch(feglm(fml, data = panel,
                          family = binomial(link = "logit"),
                          cluster = as.formula(paste0("~", cluster_var)),
                          glm.iter = 300, fixef.iter = 100000),
                    error = function(e) NULL)
    if (is.null(m_o))
        return(list(p_pairs = NA_real_, b_obs = NA_real_, se_obs = NA_real_,
                    n_obs = NA_integer_, n_clust = NA_integer_,
                    err = "obs feglm failed"))
    # Refuse to bootstrap if the original logit did not converge: the
    # observed t is meaningless and the resulting p is unreliable.
    if (!isTRUE(m_o$convStatus)) {
        return(list(p_pairs = NA_real_, b_obs = NA_real_, se_obs = NA_real_,
                    n_obs = nobs(m_o), n_clust = NA_integer_,
                    err = "obs feglm did not converge"))
    }
    param <- resolve_param(rownames(m_o$coeftable), base_var, side)
    if (is.na(param))
        return(list(p_pairs = NA_real_, b_obs = NA_real_, se_obs = NA_real_,
                    n_obs = nobs(m_o), n_clust = NA_integer_,
                    err = paste0("param not found for base ", base_var,
                                 if (is.null(side)) "" else paste0(" side=", side))))
    keep <- obs(m_o)
    sub  <- panel[keep]
    b_o  <- m_o$coeftable[param, 1]
    se_o <- m_o$coeftable[param, 2]

    cl_vals <- unique(sub[[cluster_var]])
    # Pre-split by cluster once so each rep is just rbindlist(cluster_split[cs])
    # instead of an O(#clusters * N) filter-rebuild per rep.
    cluster_split <- split(sub, factor(sub[[cluster_var]], levels = cl_vals))
    cluster_fmla  <- as.formula(paste0("~", cluster_var))

    one_pairs_rep <- function(bidx) {
        setFixest_nthreads(1); setFixest_notes(FALSE); setDTthreads(1)
        cs <- sample(cl_vals, length(cl_vals), replace = TRUE)
        bs_data <- rbindlist(cluster_split[cs])
        # Each bootstrap replicate: only the point estimate is used (no SE),
        # so skip cluster-robust SE computation. Also use the fixest default
        # glm.iter (25) rather than the original fit's 300: quasi-separated
        # replicates fail fast and are counted as NA, rather than grinding
        # for 10x the time. This is the main driver of the 5-day runtime.
        fit <- tryCatch(feglm(fml, data = bs_data,
                              family = binomial(link = "logit"),
                              fixef.iter = 100000),
                        error = function(e) NULL)
        if (is.null(fit)) return(NA_real_)
        if (!isTRUE(fit$convStatus)) return(NA_real_)
        p_b <- resolve_param(rownames(fit$coeftable), base_var, side)
        if (is.na(p_b)) return(NA_real_)
        fit$coeftable[p_b, 1]
    }
    coefs_raw <- suppressWarnings(
        unlist(mclapply(seq_len(B), one_pairs_rep, mc.cores = NCORES,
                        mc.preschedule = TRUE, mc.set.seed = TRUE)))
    fails <- sum(is.na(coefs_raw))
    coefs <- coefs_raw[!is.na(coefs_raw)]
    valid_frac <- length(coefs) / B
    # Mirror the WCR/WCU 50% valid-draw threshold on the pairs bootstrap.
    # Returning NA (rather than a p-value estimated from <50% of draws)
    # keeps downstream p < 0.05 / p < 0.01 star claims from leaning on
    # noisy small-N bootstrap distributions.
    MIN_VALID_FRAC_PAIRS <- 0.5
    if (valid_frac < MIN_VALID_FRAC_PAIRS) {
        return(list(p_pairs = NA_real_, b_obs = b_o, se_obs = se_o,
                    n_obs = nobs(m_o), n_clust = length(cl_vals),
                    err = sprintf("%d/%d pairs NAs (valid=%.1f%%)",
                                  fails, B, 100 * valid_frac)))
    }
    # Finite-sample (1 + k) / (B + 1) correction consistent with the WCR/WCU
    # p-value above. Keeps p strictly bounded away from zero.
    k <- min(sum(coefs <= 0), sum(coefs >= 0))
    p_pairs <- min(1, 2 * (1 + k) / (length(coefs) + 1))
    list(p_pairs = p_pairs, b_obs = b_o, se_obs = se_o,
         n_obs = nobs(m_o), n_clust = length(cl_vals),
         err = if (fails == 0) "" else
             sprintf("%d/%d pairs NAs (valid=%.1f%%)", fails, B, 100 * valid_frac))
}

# ---- 4. RHS specs -----------------------------------------------------------
mk_rhs <- function(bases, controls) {
    intx <- unlist(lapply(bases, function(b)
        c(paste0(b, ":paris_pre"), paste0(b, ":paris_post"))))
    paste(paste(intx, collapse = " + "), "+", controls)
}
CTRL <- "ln_totalassets_lag + leverage_ratio_lag + capex_totalassets_ratio_lag + ebitda_assets_ratio_lag"

BASES <- list(
    reg1 = c("scope1_log_intensity_lag",
             "scope2_log_intensity_lag",
             "scope1_log_intensity_diff_lag",
             "scope2_log_intensity_diff_lag"),
    reg2 = c("scope1_log_rel_intensity_lag",
             "scope2_log_rel_intensity_lag",
             "scope1_log_rel_intensity_diff_lag",
             "scope2_log_rel_intensity_diff_lag"),
    reg5 = c("scope1_log_intensity_industry_lag",
             "scope2_log_intensity_industry_lag",
             "ln_scope1_intensity_industry_diff_lag",
             "ln_scope2_intensity_industry_diff_lag")
)
BASES$reg3 <- BASES$reg2
BASES$reg4 <- BASES$reg2

RHS <- lapply(BASES, mk_rhs, controls = CTRL)

# ---- PREFLIGHT (reg1 N) ---------------------------------------------------
# Now that us4b_ilst / eu2b_ilst are built AND RHS is defined, fit the actual
# reg1 LPM (feols — cheap, deterministic) and assert post-FE N matches the
# deposited headline table exactly. If the ILST build is deterministic and
# the panel is correct, drift should be 0.
if (!nzchar(Sys.getenv("WILDBS_PREFLIGHT_SKIP"))) {
    cat("---- PREFLIGHT (reg1 N) ----\n")
    r1_us_fml <- as.formula(sprintf("outcome_loan_growth ~ %s | firm_id + bank_year_fe + us4b_ilst",
                                     RHS$reg1))
    r1_us_fit <- tryCatch(feols(r1_us_fml, data = data_us,
                                cluster = ~industry_id, warn = FALSE, notes = FALSE),
                          error = function(e) NULL)
    us_r1n <- if (is.null(r1_us_fit)) NA_integer_ else as.integer(nobs(r1_us_fit))
    r1_eu_fml <- as.formula(sprintf("outcome_loan_growth ~ %s | firm_id + bank_year_fe + eu2b_ilst",
                                     RHS$reg1))
    r1_eu_fit <- tryCatch(feols(r1_eu_fml, data = data_eu,
                                cluster = ~industry_id, warn = FALSE, notes = FALSE),
                          error = function(e) NULL)
    eu_r1n <- if (is.null(r1_eu_fit)) NA_integer_ else as.integer(nobs(r1_eu_fit))
    us_r1b <- if (is.null(r1_us_fit)) NA_real_ else
              signif(coef(r1_us_fit)["scope1_log_intensity_lag:paris_pre"], 4)
    eu_r1b <- if (is.null(r1_eu_fit)) NA_real_ else
              signif(coef(r1_eu_fit)["scope1_log_intensity_lag:paris_pre"], 4)
    cat(sprintf("  reg1 US loan-growth N (post-FE): %s  (expect 38,337)\n", us_r1n))
    cat(sprintf("  reg1 EU loan-growth N (post-FE): %s  (expect 25,750)\n", eu_r1n))
    cat(sprintf("  reg1 US Pre-Paris x S1 coef:     %s  (sanity, no fixed expectation)\n", us_r1b))
    cat(sprintf("  reg1 EU Pre-Paris x S1 coef:     %s  (sanity, no fixed expectation)\n", eu_r1b))
    if (is.na(us_r1n) || us_r1n != 38337L ||
        is.na(eu_r1n) || eu_r1n != 25750L) {
        stop(sprintf(
            "[preflight] reg1 N drift: US=%s (expect 38,337), EU=%s (expect 25,750). Confirm panel + ILST build.",
            us_r1n, eu_r1n))
    }
    rm(r1_us_fit, r1_eu_fit); invisible(gc(verbose = FALSE))
    if (nzchar(Sys.getenv("WILDBS_PREFLIGHT_ONLY"))) {
        cat("---- PREFLIGHT_ONLY=1 — exiting without bootstrap ----\n")
        quit(save = "no", status = 0)
    }
    cat("---- PREFLIGHT (reg1 N) OK ----\n\n")
}
PARAMS <- BASES  # base var strings; wcb/pairs helpers resolve to actual coef row names

# Resolver: given fitted-model coef rownames + base var + side, return the
# actual row name for the coefficient of interest. When side is "pre" or
# "post" this is base:paris_side (whichever order fixest assigns). When side
# is NULL this is the standalone control coefficient (row name == base).
resolve_param <- function(coef_rows, base, side = NULL) {
    if (is.null(side)) {
        if (base %in% coef_rows) return(base)
        return(NA_character_)
    }
    r1 <- paste0(base, ":paris_", side)
    r2 <- paste0("paris_", side, ":", base)
    if (r1 %in% coef_rows) return(r1)
    if (r2 %in% coef_rows) return(r2)
    NA_character_
}

# Reg spec table
specs <- list(
    list(name="reg1",         rhs_key="reg1",     fe_col_us="us4b_ilst", fe_col_eu="eu2b_ilst",
         us_filter=NULL, eu_filter=NULL, params=PARAMS$reg1),
    list(name="reg2",         rhs_key="reg2", fe_col_us="us4b_ilst", fe_col_eu="eu2b_ilst",
         us_filter=NULL, eu_filter=NULL, params=PARAMS$reg2),
    list(name="reg3brown",    rhs_key="reg3", fe_col_us="us4b_ilst", fe_col_eu="eu2b_ilst",
         us_filter=quote(industry_brown_class_ft == "brown"),
         eu_filter=quote(industry_brown_class_ft == "brown"),
         params=PARAMS$reg3),
    list(name="reg4nonbrown", rhs_key="reg4", fe_col_us="us4b_ilst", fe_col_eu="eu2b_ilst",
         us_filter=quote(industry_brown_class_ft == "non_brown"),
         eu_filter=quote(industry_brown_class_ft == "non_brown"),
         params=PARAMS$reg4),
    list(name="reg5",         rhs_key="reg5",     fe_col_us="us4b_lst",  fe_col_eu="eu2b_lst",
         us_filter=NULL, eu_filter=NULL, params=PARAMS$reg5)
)

# ---- 5. Main sweep --------------------------------------------------------
rows <- list()
t_start <- proc.time()[3]

# Terms per family = 4 firm controls (side=NULL) + Paris interactions for each
# base var (side="pre" and "post"). Total 4 + 2*length(bases) terms per family.
CONTROL_VARS <- c("ln_totalassets_lag", "leverage_ratio_lag",
                  "capex_totalassets_ratio_lag", "ebitda_assets_ratio_lag")

build_terms <- function(bases) {
    # Order: controls first, then bases interleaved (pre, post) — matches the
    # benchmark table row order (assets, leverage, capex, ebitda, then S1 pre,
    # S1 post, S2 pre, S2 post, dS1 pre, dS1 post, dS2 pre, dS2 post).
    terms <- lapply(CONTROL_VARS, function(v) list(base = v, side = NULL))
    for (b in bases) {
        terms[[length(terms) + 1]] <- list(base = b, side = "pre")
        terms[[length(terms) + 1]] <- list(base = b, side = "post")
    }
    terms
}

for (s in specs) {
    rhs <- RHS[[s$rhs_key]]
    terms <- build_terms(s$params)
    for (pan_label in c("us","eu")) {
        d_full <- if (pan_label == "us") data_us else data_eu
        fe_col <- if (pan_label == "us") s$fe_col_us else s$fe_col_eu
        fe_str <- sprintf("firm_id + bank_year_fe + %s", fe_col)
        filt   <- if (pan_label == "us") s$us_filter else s$eu_filter
        d      <- if (is.null(filt)) d_full else d_full[eval(filt)]

        cat(sprintf("\n=== %-14s %s | rows=%d | fe=%s ===\n",
                    s$name, toupper(pan_label), nrow(d), fe_col))

        for (tm in terms) {
            p <- tm$base
            sd <- tm$side
            t0 <- proc.time()[3]
            # feols: g (loan growth), h (ln loan amount)
            res_g <- wcb_feols_1param(rhs, fe_str, "outcome_loan_growth",
                                      d, p, "industry_id", B, side = sd)
            res_h <- wcb_feols_1param(rhs, fe_str, "outcome_log_loan",
                                      d, p, "industry_id", B, side = sd)
            # feglm: i (new tranche), l (first loan)
            res_i <- pairs_cluster_bs_feglm_1param(rhs, fe_str,
                                                   "outcome_new_loan",
                                                   d, p, "industry_id", B,
                                                   side = sd)
            res_l <- pairs_cluster_bs_feglm_1param(rhs, fe_str,
                                                   "outcome_first_loan",
                                                   d, p, "industry_id", B,
                                                   side = sd)
            dt_p <- proc.time()[3] - t0
            side_lbl <- if (is.null(sd)) "ctrl" else sd
            cat(sprintf("  %-55s [%-4s] g:WCR=%.3f/WCU=%.3f  h:WCR=%.3f/WCU=%.3f  i:P=%.3f  l:P=%.3f  [%.0fs]\n",
                        p, side_lbl,
                        res_g$p_wcr, res_g$p_wcu,
                        res_h$p_wcr, res_h$p_wcu,
                        res_i$p_pairs, res_l$p_pairs, dt_p))
            rows[[length(rows) + 1]] <- data.frame(
                family    = s$name,
                panel     = pan_label,
                parameter = p,
                side      = if (is.null(sd)) "" else sd,
                n_obs_g   = res_g$n_obs,     n_clust_g = res_g$n_clust,
                b_g = res_g$b_obs, se_g = res_g$se_obs, t_g = res_g$t_obs,
                p_wcr_g = res_g$p_wcr, p_wcu_g = res_g$p_wcu, err_g = res_g$err,
                b_h = res_h$b_obs, se_h = res_h$se_obs, t_h = res_h$t_obs,
                p_wcr_h = res_h$p_wcr, p_wcu_h = res_h$p_wcu, err_h = res_h$err,
                b_i = res_i$b_obs, se_i = res_i$se_obs,
                p_pairs_i = res_i$p_pairs, err_i = res_i$err,
                b_l = res_l$b_obs, se_l = res_l$se_obs,
                p_pairs_l = res_l$p_pairs, err_l = res_l$err,
                stringsAsFactors = FALSE)
            # Incremental save so a mid-run crash preserves progress. Write
            # to a .partial sidecar so an interrupted run cannot masquerade
            # as the complete deliverable — Stage 08 reads out_csv only,
            # which this script publishes atomically at the very end.
            write.csv(do.call(rbind, rows), partial_csv, row.names = FALSE)
        }
    }
}

out <- do.call(rbind, rows)
cat(sprintf("\nTotal elapsed: %.0f s\n", proc.time()[3] - t_start))
cat(sprintf("Writing: %s\n", out_csv))
# Final publish is atomic: write to a tmp, fsync by rename, then clear the
# .partial sidecar so output/tables carries only the completed deliverable.
tmp_csv <- paste0(out_csv, ".tmp")
write.csv(out, tmp_csv, row.names = FALSE)
file.rename(tmp_csv, out_csv)
if (file.exists(partial_csv)) file.remove(partial_csv)
cat("\n=== run_new_benchmark_wildbs.R done ===\n")
