#!/usr/bin/env Rscript
# run_new_benchmark_no2020.R
# ---------------------------------------------------------------------------
# Drop-2020 (COVID) robustness for the ILST benchmark.
# Filters panels to deal_year != 2020 and reruns reg1-5 with the headline
# US-4b + EU country-2b spec. reg5 uses LST (drops industry dim).
#
# Reads:  data/analysis_input.rds
# Writes: output/tables/tables_vJun2026_ILSTbenchmark/
#           reg{1,2,3brown,4nonbrown,5_between}_us4b_eu_country2b_no2020.tex
# ---------------------------------------------------------------------------

suppressPackageStartupMessages({
    library(data.table)
    library(fixest)
})

# --- portability shim: source config + dict from replication_package root ---
suppressWarnings({
    .REPL_ROOT <- Sys.getenv("REPL_ROOT")
    if (!nzchar(.REPL_ROOT)) {
        .this <- tryCatch(normalizePath(sys.frame(1)$ofile, mustWork = FALSE),
                          error = function(e) "")
        if (nzchar(.this)) .REPL_ROOT <- normalizePath(file.path(dirname(.this), "..", ".."),
                                                       mustWork = FALSE)
    }
    if (!nzchar(.REPL_ROOT)) .REPL_ROOT <- normalizePath("../..", mustWork = FALSE)
    Sys.setenv(REPL_ROOT = .REPL_ROOT)
})
options(repl.verbose = FALSE)
source(file.path(Sys.getenv("REPL_ROOT"), "config_public.R"))
source(file.path(CODE_DIR, "06_run_regressions", "_public_loader.R"))
source(file.path(Sys.getenv("REPL_ROOT"), "code/06_run_regressions/_feglm_helpers.R"))
source(file.path(CODE_DIR, "06_run_regressions", "dict.R"))
# --- end shim ---

setDTthreads(4); setFixest_nthreads(4); setFixest_notes(FALSE)

data_dir <- DATA_INTER
output_dir <- OUT_TABLES
if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)
cat("Writing tables to: ", output_dir, "\n", sep = "")

# ---- 1. dict from source-of-truth ------------------------------------------

# ---- 2. Load panel + ratios + bank_year_fe + DROP 2020 --------------------
.ai <- load_analysis_input()
data_us <- .ai$data_us
data_eu <- .ai$data_eu
data_us <- add_ratios(data_us); data_eu <- add_ratios(data_eu)
data_us[, bank_year_fe := as.factor(bank_id):as.factor(deal_year)]
data_eu[, bank_year_fe := as.factor(bank_id):as.factor(deal_year)]

n_us_before <- nrow(data_us); n_eu_before <- nrow(data_eu)
data_us <- data_us[deal_year != 2020L]
data_eu <- data_eu[deal_year != 2020L]
cat(sprintf("US panel: %d -> %d rows (dropped 2020: %d)\n",
            n_us_before, nrow(data_us), n_us_before - nrow(data_us)))
cat(sprintf("EU panel: %d -> %d rows (dropped 2020: %d)\n",
            n_eu_before, nrow(data_eu), n_eu_before - nrow(data_eu)))

# ---- 3. Cell builders (verbatim from headline runners) --------------------
build_loansample_lst <- function(panel, loc_col, n_buckets, label, colname_prefix) {
    p <- copy(panel); setDT(p)
    p[, fyear_match := deal_year - 1L]
    fy <- unique(
        p[!is.na(at_rank_within_year) & !is.na(get(loc_col)) & get(loc_col) != "",
          .(firm_id, fyear_match, loc_eff = as.character(get(loc_col)), at_rank_within_year)],
        by = c("firm_id", "fyear_match"))
    fy[, size_bucket := as.integer(ceiling(
            at_rank_within_year * n_buckets)),
       by = fyear_match]
    fy[size_bucket > n_buckets, size_bucket := n_buckets]
    fy[size_bucket < 1L,        size_bucket := 1L]
    fy[, lst := paste(loc_eff, size_bucket, fyear_match, sep = "_")]
    keep <- fy[, .(firm_id, fyear_match, sb = size_bucket, lst_new = lst)]
    setnames(keep, c("sb","lst_new"),
             c(paste0(colname_prefix,"_size_bucket"),
               paste0(colname_prefix,"_lst")))
    p <- merge(p, keep, by = c("firm_id","fyear_match"), all.x = TRUE)
    p[, fyear_match := NULL]
    p
}
data_us <- build_loansample_ilst(data_us, "state_id", 4L, "US 4b (ilst)", "us4b")
data_us <- build_loansample_lst (data_us, "state", 4L, "US 4b (lst)",  "us4b")
data_eu <- build_loansample_ilst(data_eu, "country_id",   2L, "EU 2b (ilst)", "eu2b")
data_eu <- build_loansample_lst (data_eu, "loc",   2L, "EU 2b (lst)",  "eu2b")

# ---- 4. RHS specs (verbatim from headline) --------------------------------
RHS <- list(
    reg1 = paste(
        "scope1_log_intensity_lag:paris + scope2_log_intensity_lag:paris +",
        "scope1_log_intensity_diff_lag:paris + scope2_log_intensity_diff_lag:paris +",
        "ln_totalassets_lag + leverage_ratio_lag +",
        "capex_totalassets_ratio_lag + ebitda_assets_ratio_lag"),
    relative = paste(
        "scope1_log_rel_intensity_lag:paris + scope2_log_rel_intensity_lag:paris +",
        "scope1_log_rel_intensity_diff_lag:paris + scope2_log_rel_intensity_diff_lag:paris +",
        "ln_totalassets_lag + leverage_ratio_lag +",
        "capex_totalassets_ratio_lag + ebitda_assets_ratio_lag"),
    reg5 = paste(
        "scope1_log_intensity_industry_lag:paris +",
        "scope2_log_intensity_industry_lag:paris +",
        "ln_scope1_intensity_industry_diff_lag:paris +",
        "ln_scope2_intensity_industry_diff_lag:paris +",
        "ln_totalassets_lag + leverage_ratio_lag +",
        "capex_totalassets_ratio_lag + ebitda_assets_ratio_lag")
)

safe_etable <- function(models, file_name) {
    tryCatch({
        etable(models, dict = dict, style.tex = style.tex("aer"),
               signif.code = c("***"=0.01, "**"=0.05, "*"=0.10),
               fitstat = ~ r2 + n, digits = "r3", tex = TRUE,
               file = file.path(output_dir, file_name), replace = TRUE)
        cat(sprintf("  wrote %s\n", file_name))
    }, error = function(e) {
        # Log, then propagate so FAIL_FAST/run.sh halts (fixed 2026-11-04;
        # was previously swallowing write failures and leaving stale tables).
        cat(sprintf("  !!! etable failed for %s: %s
",
                    file_name, conditionMessage(e)))
        stop(sprintf("etable failed for %s: %s", file_name, conditionMessage(e)))
    })
}

fit_block <- function(d, fe_col, rhs, subset_filter = NULL) {
    if (!is.null(subset_filter)) d <- d[eval(subset_filter)]
    fe <- sprintf("firm_id + bank_year_fe + %s", fe_col)
    list(
        g = feols(as.formula(paste0("outcome_loan_growth ~ ", rhs, " | ", fe)),
                  data = d, cluster = ~industry_id),
        h = feols(as.formula(paste0("outcome_log_loan   ~ ", rhs, " | ", fe)),
                  data = d, cluster = ~industry_id),
        i = feglm_safe(as.formula(paste0("outcome_new_loan     ~ ", rhs, " | ", fe)),
                  data = d, family = binomial(link = "logit"),
                  cluster = ~industry_id),
        l = feglm_safe(as.formula(paste0("outcome_first_loan ~ ", rhs, " | ", fe)),
                  data = d, family = binomial(link = "logit"),
                  cluster = ~industry_id)
    )
}

run_pair <- function(us_fe, eu_fe, rhs_key, out_file,
                     us_filter = NULL, eu_filter = NULL) {
    cat(sprintf("\n--- %s ---\n", out_file))
    us <- fit_block(data_us, us_fe, RHS[[rhs_key]], us_filter)
    eu <- fit_block(data_eu, eu_fe, RHS[[rhs_key]], eu_filter)
    safe_etable(list(us$g, us$h, us$i, us$l,
                     eu$g, eu$h, eu$i, eu$l), out_file)
}

# ---- 5. Reg1-5 with 2020 dropped ------------------------------------------
run_pair("us4b_ilst", "eu2b_ilst", "reg1",
         "reg1_us4b_eu_country2b_no2020.tex")
run_pair("us4b_ilst", "eu2b_ilst", "relative",
         "reg2_us4b_eu_country2b_no2020.tex")
run_pair("us4b_ilst", "eu2b_ilst", "relative",
         "reg3brown_us4b_eu_country2b_no2020.tex",
         us_filter = quote(industry_brown_class_ft == "brown"),
         eu_filter = quote(industry_brown_class_ft == "brown"))
run_pair("us4b_ilst", "eu2b_ilst", "relative",
         "reg4nonbrown_us4b_eu_country2b_no2020.tex",
         us_filter = quote(industry_brown_class_ft == "non_brown"),
         eu_filter = quote(industry_brown_class_ft == "non_brown"))
run_pair("us4b_lst",  "eu2b_lst",  "reg5",
         "reg5_between_us4b_eu_country2b_no2020.tex")

cat("\n=== run_new_benchmark_no2020.R done ===\n")

check_all_converged(script = "run_new_benchmark_no2020.R")
