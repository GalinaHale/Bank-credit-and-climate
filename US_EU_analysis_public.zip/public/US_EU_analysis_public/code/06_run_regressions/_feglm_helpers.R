# _feglm_helpers.R
# -----------------------------------------------------------------------------
# Convergence-safe wrapper around fixest::feglm, plus a per-script
# convergence tracker.
#
# What it does:
#   - feglm_safe(...) : calls fixest::feglm with raised iteration caps
#     (glm.iter = 300 outer, fixef.iter = 100000 inner demeaning). 1000
#     outer iters is tempting but let quasi-separated logits stall for
#     hours; 300 is the empirical sweet spot. Captures three classes of
#     condition during the fit:
#       (a) OUTER IRLS non-convergence   — read from fit$convStatus
#           after return (fixest 0.11+ flag).
#       (b) INNER demeaning non-convergence — surfaced only through the
#           warning channel ("Demeaning algorithm: Absence of convergence"
#           / "did not converge"). NOT reflected in fit$convStatus, so
#           checking that flag alone silently accepts fits whose fixed-
#           effect demeaning never converged.
#       (c) NON-POSITIVE-DEFINITE VCOV  — surfaced through the warning
#           channel ("not positive definite" / "VCOV ... singular");
#           indicates the cluster-robust variance matrix was patched
#           to psd, so reported SEs/stars should not be trusted.
#     Classes (b) and (c) are intercepted via withCallingHandlers and
#     muffled so the fit returns cleanly; EVERY OTHER WARNING is left
#     untouched so unexpected fixest conditions still surface. The
#     tracker records any fit that fails ANY of these three checks and
#     check_all_converged() halts on any entry that is not whitelisted
#     via `expected_failures`.
#   - check_all_converged(script = "...") : called at the end of each stage-06
#     runner. If any non-converged / non-PD-VCOV fits were recorded during
#     the run, prints a per-table summary of which fits failed and stop()s.
#     Otherwise prints a clean confirmation.
#
# How runners use it:
#   source(file.path(Sys.getenv("REPL_ROOT"),
#                    "code/06_run_regressions/_feglm_helpers.R"))
#   feglm_safe(formula, data = d, family = binomial("logit"), cluster = ~industry_id,
#              .label = "reg3brown_us4b_eu_country2b_age_gt10 col 4")
#   ...
#   check_all_converged("run_new_benchmark_age_dummies.R")
#
# The optional .label argument tags the fit with a human-readable identifier
# so the final summary points at exactly the offending column.
# -----------------------------------------------------------------------------

if (!exists(".FEGLM_CONV_TRACKER", envir = globalenv())) {
    assign(".FEGLM_CONV_TRACKER", list(), envir = globalenv())
}
# Table-level VCOV tracker: records which output tables emitted any
# "VCOV matrix is not positive definite" warning during etable()
# assembly. Populated by etable_safe().
if (!exists(".ETABLE_VCOV_TRACKER", envir = globalenv())) {
    assign(".ETABLE_VCOV_TRACKER", list(), envir = globalenv())
}

feglm_safe <- function(..., .label = NA_character_,
                       glm.iter = 300,
                       fixef.iter = 100000) {
    call_args <- list(...)
    # Pass higher iteration caps unless the caller overrode them
    if (is.null(call_args$glm.iter))   call_args$glm.iter   <- glm.iter
    if (is.null(call_args$fixef.iter)) call_args$fixef.iter <- fixef.iter

    # Classify warnings we care about and let every other warning
    # propagate normally.
    #
    # NB: the previous version called invokeRestart("muffleWarning")
    # unconditionally, which silently suppressed non-PD VCOV warnings
    # (and anything else fixest emits). Keep the restart INSIDE the
    # if-branch for recognized classes only.
    is_demean_warn <- function(msg) {
        grepl("[Dd]emeaning|[Aa]bsence of convergence|did not converge", msg)
    }
    is_vcov_warn <- function(msg) {
        grepl("not positive[- ]definite|positive[- ]semidefinite|VCOV.*singular|VCOV.*not PSD|VCOV.*fixed to psd",
              msg, ignore.case = TRUE)
    }

    inner_warns <- character(0)
    vcov_warns  <- character(0)
    warning_handler <- function(w) {
        msg <- conditionMessage(w)
        if (is_demean_warn(msg)) {
            inner_warns <<- c(inner_warns, msg)
            invokeRestart("muffleWarning")
        } else if (is_vcov_warn(msg)) {
            vcov_warns <<- c(vcov_warns, msg)
            invokeRestart("muffleWarning")
        }
        # Any other warning: do NOT muffle. Let it reach the console
        # so unexpected fixest conditions remain visible.
    }
    fit <- withCallingHandlers(
        do.call(fixest::feglm, call_args),
        warning = warning_handler
    )
    # fixest emits the "VCOV matrix is not positive definite and was
    # 'fixed'" warning via its own internal queue, which bypasses R's
    # withCallingHandlers (warning fires outside our handler scope).
    # Deterministic replacement: fixest uses chol() to test positive-
    # definiteness. Replicate that exact test here so every fit whose
    # cluster-robust VCOV needed fixing is attributed to its label.
    V <- tryCatch(suppressWarnings(stats::vcov(fit)),
                  error = function(e) NULL)
    if (!is.null(V) && is.matrix(V) && nrow(V) > 0L) {
        is_nonpd <- tryCatch({
            suppressWarnings(chol(V))
            FALSE
        }, error = function(e) TRUE)
        if (is_nonpd && length(vcov_warns) == 0L) {
            vcov_warns <- c(vcov_warns,
                            "non-PD VCOV detected via chol() (SEs were patched to psd by fixest)")
        }
    }

    # fixest 0.11+ : fit$convStatus is TRUE when the outer IRLS converged.
    outer_ok <- isTRUE(fit$convStatus)
    inner_ok <- length(inner_warns) == 0L
    vcov_ok  <- length(vcov_warns)  == 0L
    all_ok   <- outer_ok && inner_ok && vcov_ok
    attr(fit, "feglm_safe") <- list(label = .label,
                                    converged = all_ok,
                                    outer_ok = outer_ok,
                                    inner_ok = inner_ok,
                                    vcov_ok = vcov_ok,
                                    inner_warnings = inner_warns,
                                    vcov_warnings = vcov_warns)

    if (!all_ok) {
        trk <- get(".FEGLM_CONV_TRACKER", envir = globalenv())
        trk[[length(trk) + 1L]] <- list(
            label = if (is.na(.label)) "(unlabelled)" else .label,
            convStatus = fit$convStatus,
            outer_ok = outer_ok,
            inner_ok = inner_ok,
            vcov_ok = vcov_ok,
            inner_warnings = inner_warns,
            vcov_warnings = vcov_warns,
            iterations = fit$iterations,
            deviance = fit$deviance
        )
        assign(".FEGLM_CONV_TRACKER", trk, envir = globalenv())
    }
    fit
}

check_all_converged <- function(script = NA_character_, halt = TRUE,
                                expected_failures = character(0),
                                expected_vcov_tables = character(0)) {
    # Report table-level non-PD VCOV warnings (captured by etable_safe)
    # BEFORE the per-fit tracker, so the user sees the full picture.
    etab <- get(".ETABLE_VCOV_TRACKER", envir = globalenv())
    if (length(etab) > 0L) {
        files_seen <- vapply(etab, function(e) e$file, character(1))
        unexpected_tabs <- files_seen[!(files_seen %in% expected_vcov_tables)]
        if (length(expected_vcov_tables) > 0L) {
            n_expected <- sum(files_seen %in% expected_vcov_tables)
            if (n_expected > 0L) {
                cat(sprintf("[conv_check] %s: %d expected non-PD VCOV table(s) suppressed downstream:\n",
                            if (is.na(script)) "" else script, n_expected))
                for (f in intersect(files_seen, expected_vcov_tables)) {
                    cat(sprintf("  (expected) %s\n", f))
                }
            }
        }
        if (length(unexpected_tabs) > 0L) {
            cat(sprintf("[conv_check] %s: %d unexpected non-PD VCOV table(s):\n",
                        if (is.na(script)) "" else script,
                        length(unexpected_tabs)))
            for (e in etab) {
                if (e$file %in% unexpected_tabs) {
                    cat(sprintf("  * %s  (%d non-PD VCOV warning(s))\n",
                                e$file, e$n_warn))
                }
            }
            if (halt) {
                stop(sprintf(
                    "[conv_check] %s: pipeline halted on non-PD VCOV in %d table(s). Add filename(s) to expected_vcov_tables= in the runner, and to script/suppress_nonconv_cells.py TARGETS.",
                    if (is.na(script)) "" else script,
                    length(unexpected_tabs)
                ))
            }
        }
    }
    trk <- get(".FEGLM_CONV_TRACKER", envir = globalenv())
    # expected_failures: labels that are known-non-converged and get suppressed
    # downstream by script/suppress_nonconv_cells.py. These are expected
    # conditions, not pipeline halts.
    if (length(expected_failures) > 0L && length(trk) > 0L) {
        observed <- vapply(trk, function(e) e$label, character(1))
        n_expected <- sum(observed %in% expected_failures)
        trk <- trk[!(observed %in% expected_failures)]
        if (n_expected > 0L) {
            cat(sprintf("[conv_check] %s: %d expected non-convergence(s) suppressed downstream:\n",
                        if (is.na(script)) "" else script, n_expected))
            for (lbl in intersect(observed, expected_failures)) {
                cat(sprintf("  (expected) %s\n", lbl))
            }
        }
    }
    if (length(trk) == 0L) {
        cat(sprintf("[conv_check] %s: all feglm fits converged (modulo expected).\n",
                    if (is.na(script)) "" else script))
        return(invisible(TRUE))
    }
    cat(sprintf("[conv_check] %s: %d unexpected non-converged fit(s):\n",
                if (is.na(script)) "" else script, length(trk)))
    for (e in trk) {
        cat(sprintf("  * %s  (outer_ok=%s, inner_ok=%s, vcov_ok=%s, iters=%s, dev=%.3g)\n",
                    e$label,
                    if (is.null(e$outer_ok)) e$convStatus else e$outer_ok,
                    if (is.null(e$inner_ok)) "NA" else e$inner_ok,
                    if (is.null(e$vcov_ok))  "NA" else e$vcov_ok,
                    paste(e$iterations, collapse = ","),
                    e$deviance))
        if (!is.null(e$inner_warnings) && length(e$inner_warnings) > 0L) {
            for (w in e$inner_warnings) {
                cat(sprintf("      inner-demeaning: %s\n", w))
            }
        }
        if (!is.null(e$vcov_warnings) && length(e$vcov_warnings) > 0L) {
            for (w in e$vcov_warnings) {
                cat(sprintf("      vcov-non-PD:   %s\n", w))
            }
        }
    }
    if (halt) {
        stop(sprintf(
            "[conv_check] %s: pipeline halted on non-convergence (%d fit(s)). %s",
            if (is.na(script)) "" else script, length(trk),
            paste0("Rerun with higher glm.iter / fixef.iter in feglm_safe() ",
                   "or suppress the affected column(s).")
        ))
    }
    invisible(FALSE)
}

# etable_safe: thin wrapper around fixest::etable that captures the
# "VCOV matrix is not positive definite and was 'fixed'" warnings
# fixest emits lazily during table assembly. Each warning seen while
# `file_name` is being written is recorded in .ETABLE_VCOV_TRACKER
# under the output filename. The warning is MUFFLED so it does not
# leak to the console (we report via check_all_converged() instead).
#
# `is_vcov_warn` must already be defined above (via feglm_safe).
#
# Signature matches the per-runner safe_etable() helpers so they can
# forward to this (or runners can call it directly).
etable_safe <- function(models, file_name, output_dir, dict = NULL,
                        extra_args = list()) {
    is_vcov <- function(msg) {
        grepl("not positive[- ]definite|positive[- ]semidefinite|VCOV.*singular|VCOV.*not PSD|VCOV.*fixed to psd",
              msg, ignore.case = TRUE)
    }
    captured_warns <- character(0)
    base_args <- list(models,
                      style.tex    = fixest::style.tex("aer"),
                      signif.code = c("***"=0.01, "**"=0.05, "*"=0.10),
                      fitstat      = ~ r2 + n,
                      digits       = "r3",
                      tex          = TRUE,
                      file         = file.path(output_dir, file_name),
                      replace      = TRUE)
    if (!is.null(dict)) base_args$dict <- dict
    all_args <- modifyList(base_args, extra_args)
    # Force warnings to fire immediately (warn=1) so withCallingHandlers
    # catches them inside etable() rather than when R flushes its deferred
    # warning queue at end of top-level expression. Restore the user's
    # previous warn option afterwards.
    old_warn <- getOption("warn")
    on.exit(options(warn = old_warn), add = TRUE)
    options(warn = 1)
    tryCatch(withCallingHandlers(
        do.call(fixest::etable, all_args),
        warning = function(w) {
            msg <- conditionMessage(w)
            if (is_vcov(msg)) {
                captured_warns <<- c(captured_warns, msg)
                invokeRestart("muffleWarning")
            }
        }
    ), error = function(e) {
        # Log, then propagate so FAIL_FAST halts the pipeline (fixed
        # 2026-11-04; was previously returning NULL and leaving stale tables).
        cat(sprintf("  !!! etable failed for %s: %s\n",
                    file_name, conditionMessage(e)))
        stop(sprintf("etable_safe failed for %s: %s", file_name, conditionMessage(e)))
    })
    if (length(captured_warns) > 0L) {
        trk <- get(".ETABLE_VCOV_TRACKER", envir = globalenv())
        trk[[length(trk) + 1L]] <- list(
            file   = file_name,
            n_warn = length(captured_warns),
            warnings = captured_warns
        )
        assign(".ETABLE_VCOV_TRACKER", trk, envir = globalenv())
    }
    cat(sprintf("  wrote %s%s\n", file_name,
                if (length(captured_warns) > 0L)
                    sprintf("  [%d non-PD VCOV]", length(captured_warns))
                else ""))
    invisible(NULL)
}

# Reset trackers on each source() so re-running a runner doesn't
# accumulate cross-run state.
assign(".FEGLM_CONV_TRACKER", list(), envir = globalenv())
assign(".ETABLE_VCOV_TRACKER", list(), envir = globalenv())
