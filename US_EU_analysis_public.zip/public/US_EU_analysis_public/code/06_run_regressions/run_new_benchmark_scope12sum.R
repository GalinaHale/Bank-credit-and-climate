#!/usr/bin/env Rscript
# run_new_benchmark_scope12sum.R
# ---------------------------------------------------------------------------
# Sum scope-1 + scope-2 intensity robustness for the ILST benchmark.
# Replaces the separate scope-1 and scope-2 emission regressors with a single
# combined scope-12 regressor. All other elements (headline US-4b + EU
# country-2b ILST for reg1-4, LST for reg5, controls, FE, cluster) unchanged.
#
# RHS changes vs. headline:
#   reg1     : ln_ghg_scope1_intensity_{lag,diff_lag}  +
#              ln_ghg_scope2_intensity_{lag,diff_lag}
#           -> ln_ghg_scope12_intensity_{lag,diff_lag}
#   reg2-4   : scope1_log_rel_intensity_{lag,diff_lag} +
#              scope2_log_rel_intensity_{lag,diff_lag}
#           -> scope12_log_rel_intensity_{lag,diff_lag}
#   reg5     : ln_scope1_intensity_industry_{lag,diff_lag} +
#              ln_scope2_intensity_industry_{lag,diff_lag}
#           -> ln_scope12_intensity_industry_{lag,diff_lag}
#
# Reads:  data/analysis_input.rds
# Writes: output/tables/tables_vJun2026_ILSTbenchmark/
#           reg{1,2,3brown,4nonbrown,5_between}_us4b_eu_country2b_scope12.tex
# ---------------------------------------------------------------------------

suppressPackageStartupMessages({
    library(data.table)
    library(fixest)
})

# --- portability shim: source config + dict from replication_package root ---
suppressWarnings({
    .REPL_ROOT <- Sys.getenv("REPL_ROOT")
    if (!nzchar(.REPL_ROOT)) {
        .this <- tryCatch(normalizePath(sys.frame(1)$ofile, mustWork = FALSE),
                          error = function(e) "")
        if (nzchar(.this)) .REPL_ROOT <- normalizePath(file.path(dirname(.this), "..", ".."),
                                                       mustWork = FALSE)
    }
    if (!nzchar(.REPL_ROOT)) .REPL_ROOT <- normalizePath("../..", mustWork = FALSE)
    Sys.setenv(REPL_ROOT = .REPL_ROOT)
})
options(repl.verbose = FALSE)
source(file.path(Sys.getenv("REPL_ROOT"), "config_public.R"))
source(file.path(CODE_DIR, "06_run_regressions", "_public_loader.R"))
source(file.path(Sys.getenv("REPL_ROOT"), "code/06_run_regressions/_feglm_helpers.R"))
source(file.path(CODE_DIR, "06_run_regressions", "dict.R"))
# --- end shim ---

setDTthreads(4); setFixest_nthreads(4); setFixest_notes(FALSE)

data_dir <- DATA_INTER
output_dir <- OUT_TABLES
if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)
cat("Writing tables to: ", output_dir, "\n", sep = "")

# ---- 1. dict from source-of-truth ------------------------------------------

# Extra label entries for the scope-12 versions of the four RHS terms
dict_extra <- c(
    "scope12_log_intensity_lag:paris1"      = "Log~(Intensity)$_{t-1}$~(Scope~1$+$2) $\\times$ Post-Paris",
    "scope12_log_intensity_lag:paris0"      = "Log~(Intensity)$_{t-1}$~(Scope~1$+$2) $\\times$ Pre-Paris",
    "scope12_log_intensity_diff_lag:paris1" = "$\\Delta$~(Intensity)~(Scope~1$+$2)$_{t-1}$ $\\times$ Post-Paris",
    "scope12_log_intensity_diff_lag:paris0" = "$\\Delta$~(Intensity)~(Scope~1$+$2)$_{t-1}$ $\\times$ Pre-Paris",
    "scope12_log_rel_intensity_lag:paris1"      = "Rel.~Intensity$_{t-1}$~(Scope~1$+$2) $\\times$ Post-Paris",
    "scope12_log_rel_intensity_lag:paris0"      = "Rel.~Intensity$_{t-1}$~(Scope~1$+$2) $\\times$ Pre-Paris",
    "scope12_log_rel_intensity_diff_lag:paris1" = "$\\Delta$~Rel.~Intensity~(Scope~1$+$2)$_{t-1}$ $\\times$ Post-Paris",
    "scope12_log_rel_intensity_diff_lag:paris0" = "$\\Delta$~Rel.~Intensity~(Scope~1$+$2)$_{t-1}$ $\\times$ Pre-Paris",
    "ln_scope12_intensity_industry_lag:paris1"      = "Log~(Industry~Intensity)$_{t-1}$~(Scope~1$+$2) $\\times$ Post-Paris",
    "ln_scope12_intensity_industry_lag:paris0"      = "Log~(Industry~Intensity)$_{t-1}$~(Scope~1$+$2) $\\times$ Pre-Paris",
    "ln_scope12_intensity_industry_diff_lag:paris1" = "$\\Delta$Log~(Industry~Intensity)~(Scope~1$+$2)$_{t-1}$ $\\times$ Post-Paris",
    "ln_scope12_intensity_industry_diff_lag:paris0" = "$\\Delta$Log~(Industry~Intensity)~(Scope~1$+$2)$_{t-1}$ $\\times$ Pre-Paris"
)
dict <- c(dict, dict_extra)

# ---- 2. Load panel + ratios + bank_year_fe ---------------------------------
.ai <- load_analysis_input()
data_us <- .ai$data_us
data_eu <- .ai$data_eu
data_us <- add_ratios(data_us); data_eu <- add_ratios(data_eu)
data_us[, bank_year_fe := as.factor(bank_id):as.factor(deal_year)]
data_eu[, bank_year_fe := as.factor(bank_id):as.factor(deal_year)]

# The panel has ghg_scope12_intensity_{lag,diff_lag} as levels, plus the
# scope-12 log-relative-intensity and industry-level ln-intensity variables.
# But it does NOT have the firm-level LOG version needed for reg1. Build
# it on the fly from the level lags:
#     ln_intensity_lag       = log(intensity_lag)
#     ln_intensity_diff_lag  = log(intensity_lag) - log(intensity_lag - diff_lag)
# The second identity uses:   level_{t-2} = level_{t-1} - (level_{t-1} - level_{t-2})
add_scope12_log <- function(d) {
    d[, level_t2 := scope12_log_intensity_lag - scope12_log_intensity_diff_lag]
    d[, scope12_log_intensity_lag := suppressWarnings(
            log(scope12_log_intensity_lag))]
    d[is.infinite(scope12_log_intensity_lag) |
      is.nan(scope12_log_intensity_lag),
      scope12_log_intensity_lag := NA_real_]
    d[, scope12_log_intensity_diff_lag := suppressWarnings(
            log(scope12_log_intensity_lag) - log(level_t2))]
    d[is.infinite(scope12_log_intensity_diff_lag) |
      is.nan(scope12_log_intensity_diff_lag),
      scope12_log_intensity_diff_lag := NA_real_]
    d[, level_t2 := NULL]
    d
}
data_us <- add_scope12_log(data_us); data_eu <- add_scope12_log(data_eu)
cat(sprintf("US scope12_log_intensity_lag: %d/%d non-missing\n",
            sum(!is.na(data_us$scope12_log_intensity_lag)), nrow(data_us)))
cat(sprintf("EU scope12_log_intensity_lag: %d/%d non-missing\n",
            sum(!is.na(data_eu$scope12_log_intensity_lag)), nrow(data_eu)))

# Confirm scope-12 columns present
required <- c("scope12_log_intensity_lag", "scope12_log_intensity_diff_lag",
              "scope12_log_rel_intensity_lag",
              "scope12_log_rel_intensity_diff_lag",
              "ln_scope12_intensity_industry_lag",
              "ln_scope12_intensity_industry_diff_lag")
missing_us <- setdiff(required, names(data_us))
missing_eu <- setdiff(required, names(data_eu))
if (length(missing_us)) stop("MISSING data_us cols: ", paste(missing_us, collapse=", "))
if (length(missing_eu)) stop("MISSING data_eu cols: ", paste(missing_eu, collapse=", "))
cat("All 6 scope-12 columns present in both panels.\n")

# ---- 3. Cell builders -----------------------------------------------------
build_loansample_lst <- function(panel, loc_col, n_buckets, label, colname_prefix) {
    p <- copy(panel); setDT(p)
    p[, fyear_match := deal_year - 1L]
    fy <- unique(
        p[!is.na(at_rank_within_year) & !is.na(get(loc_col)) & get(loc_col) != "",
          .(firm_id, fyear_match, loc_eff = as.character(get(loc_col)), at_rank_within_year)],
        by = c("firm_id", "fyear_match"))
    fy[, size_bucket := as.integer(ceiling(
            at_rank_within_year * n_buckets)),
       by = fyear_match]
    fy[size_bucket > n_buckets, size_bucket := n_buckets]
    fy[size_bucket < 1L,        size_bucket := 1L]
    fy[, lst := paste(loc_eff, size_bucket, fyear_match, sep = "_")]
    keep <- fy[, .(firm_id, fyear_match, sb = size_bucket, lst_new = lst)]
    setnames(keep, c("sb","lst_new"),
             c(paste0(colname_prefix,"_size_bucket"),
               paste0(colname_prefix,"_lst")))
    p <- merge(p, keep, by = c("firm_id","fyear_match"), all.x = TRUE)
    p[, fyear_match := NULL]
    p
}
data_us <- build_loansample_ilst(data_us, "state_id", 4L, "US 4b (ilst)", "us4b")
data_us <- build_loansample_lst (data_us, "state", 4L, "US 4b (lst)",  "us4b")
data_eu <- build_loansample_ilst(data_eu, "country_id",   2L, "EU 2b (ilst)", "eu2b")
data_eu <- build_loansample_lst (data_eu, "loc",   2L, "EU 2b (lst)",  "eu2b")

# ---- 4. Scope-12 RHS specs ------------------------------------------------
# Two emission terms (lag + diff_lag), each interacted with paris.
RHS <- list(
    reg1 = paste(
        "scope12_log_intensity_lag:paris +",
        "scope12_log_intensity_diff_lag:paris +",
        "ln_totalassets_lag + leverage_ratio_lag +",
        "capex_totalassets_ratio_lag + ebitda_assets_ratio_lag"),
    relative = paste(
        "scope12_log_rel_intensity_lag:paris +",
        "scope12_log_rel_intensity_diff_lag:paris +",
        "ln_totalassets_lag + leverage_ratio_lag +",
        "capex_totalassets_ratio_lag + ebitda_assets_ratio_lag"),
    reg5 = paste(
        "ln_scope12_intensity_industry_lag:paris +",
        "ln_scope12_intensity_industry_diff_lag:paris +",
        "ln_totalassets_lag + leverage_ratio_lag +",
        "capex_totalassets_ratio_lag + ebitda_assets_ratio_lag")
)

safe_etable <- function(models, file_name) {
    tryCatch({
        etable(models, dict = dict, style.tex = style.tex("aer"),
               signif.code = c("***"=0.01, "**"=0.05, "*"=0.10),
               fitstat = ~ r2 + n, digits = "r3", tex = TRUE,
               file = file.path(output_dir, file_name), replace = TRUE)
        cat(sprintf("  wrote %s\n", file_name))
    }, error = function(e) {
        # Log, then propagate so FAIL_FAST/run.sh halts (fixed 2026-11-04;
        # was previously swallowing write failures and leaving stale tables).
        cat(sprintf("  !!! etable failed for %s: %s
",
                    file_name, conditionMessage(e)))
        stop(sprintf("etable failed for %s: %s", file_name, conditionMessage(e)))
    })
}

fit_block <- function(d, fe_col, rhs, subset_filter = NULL) {
    if (!is.null(subset_filter)) d <- d[eval(subset_filter)]
    fe <- sprintf("firm_id + bank_year_fe + %s", fe_col)
    list(
        g = feols(as.formula(paste0("outcome_loan_growth ~ ", rhs, " | ", fe)),
                  data = d, cluster = ~industry_id),
        h = feols(as.formula(paste0("outcome_log_loan   ~ ", rhs, " | ", fe)),
                  data = d, cluster = ~industry_id),
        i = feglm_safe(as.formula(paste0("outcome_new_loan     ~ ", rhs, " | ", fe)),
                  data = d, family = binomial(link = "logit"),
                  cluster = ~industry_id),
        l = feglm_safe(as.formula(paste0("outcome_first_loan ~ ", rhs, " | ", fe)),
                  data = d, family = binomial(link = "logit"),
                  cluster = ~industry_id)
    )
}

run_pair <- function(us_fe, eu_fe, rhs_key, out_file,
                     us_filter = NULL, eu_filter = NULL) {
    cat(sprintf("\n--- %s ---\n", out_file))
    us <- fit_block(data_us, us_fe, RHS[[rhs_key]], us_filter)
    eu <- fit_block(data_eu, eu_fe, RHS[[rhs_key]], eu_filter)
    safe_etable(list(us$g, us$h, us$i, us$l,
                     eu$g, eu$h, eu$i, eu$l), out_file)
}

# ---- 5. Reg1-5 with scope-12 combined regressor --------------------------
run_pair("us4b_ilst", "eu2b_ilst", "reg1",
         "reg1_us4b_eu_country2b_scope12.tex")
run_pair("us4b_ilst", "eu2b_ilst", "relative",
         "reg2_us4b_eu_country2b_scope12.tex")
run_pair("us4b_ilst", "eu2b_ilst", "relative",
         "reg3brown_us4b_eu_country2b_scope12.tex",
         us_filter = quote(industry_brown_class_ft == "brown"),
         eu_filter = quote(industry_brown_class_ft == "brown"))
run_pair("us4b_ilst", "eu2b_ilst", "relative",
         "reg4nonbrown_us4b_eu_country2b_scope12.tex",
         us_filter = quote(industry_brown_class_ft == "non_brown"),
         eu_filter = quote(industry_brown_class_ft == "non_brown"))
run_pair("us4b_lst",  "eu2b_lst",  "reg5",
         "reg5_between_us4b_eu_country2b_scope12.tex")

cat("\n=== run_new_benchmark_scope12sum.R done ===\n")

check_all_converged(script = "run_new_benchmark_scope12sum.R")
