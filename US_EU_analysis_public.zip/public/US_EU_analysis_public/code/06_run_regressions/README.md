# Stage 06 — run regressions

## What this stage does

Runs every regression family that produces a `.tex` fragment in the paper. All scripts read `data/analysis_input.rds` (the neutral estimation panel) and write `.tex` fragments into `output/tables/`.

Every script uses `fixest::feols` with cluster-robust standard errors. The cluster level, RHS specification, and fixed-effects block for each are documented at the top of the individual `.R` files.

## Runner scripts

| Script | Family | Produces |
|---|---|---|
| `run_new_benchmark_ilst.R` | reg1–reg4 main | `reg{1,2,3brown,4nonbrown}_us{4b,2b}_eu_country2b.tex` |
| `run_new_benchmark_reg5_lst.R` | reg5 between-industry | `reg5_between_us{4b,2b}_eu_country2b.tex` |
| `run_new_benchmark_ilst_age.R` | Section D.1.4 continuous firm-age | `reg{1..5}_us4b_eu_country2b_age.tex` |
| `run_new_benchmark_age_dummies.R` | Appendix E age-dummy robustness | `reg{1..5}_us4b_eu_country2b_age_{gt10,median}.tex` |
| `run_new_benchmark_thresholds.R` | FT p90 + time-varying brown | `reg{3brown,4nonbrown}_us4b_eu_country2b_{ft_p90,tv}.tex` |
| `run_new_benchmark_stan.R` | OECD-STAN deflator | `reg{1..5}_us4b_eu_country2b_stan.tex` |
| `run_new_benchmark_no2020.R` | drop 2020 deals | `reg{1..5}_us4b_eu_country2b_no2020.tex` |
| `run_new_benchmark_scope12sum.R` | Scope 1+2 sum | `reg{1..5}_us4b_eu_country2b_scope12.tex` |
| `run_scope2_on_scope1.R` | Scope-2 on Scope-1 diagnostic | `scope2_on_scope1_intensity.tex` |
| `run_bank_industryyear_regs.R` | Table A.9 bank × industry × year | `bank_industryyear_nonbrown_nzba_paris.tex` |

Four related runners live in the licensed construction-code package because they read proprietary intermediates or reference provider-named columns the neutral schema does not export:

- `build_sample_funnel.R`
- `plot_emission_intensity_distributions.R`
- `run_ilst_nuts_regs.R`
- `summary_stats_A1_A2_replication.R`

Their outputs ship under this tier's `output/tables/` as verified static exhibits; see `../../README.md` ("What this tier does NOT rebuild") and `../../DATA_AVAILABILITY.md` for how to obtain the licensed package.

## Wall clock

~5 minutes per family × 10 families = ~45 min end-to-end on 8 GB WSL2.

## Regenerating a single family

```bash
Rscript code/06_run_regressions/run_bank_industryyear_regs.R
```
Each script re-reads the panel, so families can be regenerated in isolation.
