#!/usr/bin/env bash
# Stage 06 — run all regression families → .tex fragments in output/tables/.
#   IN:   data/analysis_input.rds   (neutral panel; built by the licensed
#                                     construction-code package — see
#                                     DATA_AVAILABILITY.md)
#   OUT:  output/tables/*.tex
#
# Fail-fast mode. Set FAIL_FAST=0 to revert to lenient behaviour for debugging.
set -uo pipefail
cd "$(dirname "$0")/../.."
export REPL_ROOT="$(pwd)"
mkdir -p output/tables

# Public-tier runners read ANALYSIS_INPUT_RDS via config_public.R; the default
# location is $REPL_ROOT/data/analysis_input.rds and is honoured automatically.
export OUT_DIR="${OUT_TABLES:-$REPL_ROOT/output/tables}"

FAIL_FAST="${FAIL_FAST:-1}"

# Runners that produce .tex fragments the paper uses but are NOT in this
# list live in the licensed construction-code package, either because they
# read licensed intermediates directly or because they reference provider-
# named columns the neutral schema does not export:
#   build_sample_funnel.R
#   plot_emission_intensity_distributions.R
#   run_ilst_nuts_regs.R
#   summary_stats_A1_A2_replication.R
# Their outputs ship under this tier's output/tables/ as verified static
# exhibits; see ../../README.md ("What this tier does NOT rebuild") and
# DATA_AVAILABILITY.md for how to obtain the licensed package.
SCRIPTS=(
    run_new_benchmark_ilst.R                  # reg1-4 main × 4b/2b US
    run_new_benchmark_reg5_lst.R              # reg5 between + NUTS-2 variants
    run_new_benchmark_ilst_age.R              # continuous firm-age robustness
    run_new_benchmark_age_dummies.R           # age>10 + pooled-median (Appendix E)
    run_new_benchmark_thresholds.R            # FT p90 + time-varying
    run_new_benchmark_stan.R                  # STAN-deflated intensity
    run_new_benchmark_no2020.R                # drop 2020
    run_new_benchmark_scope12sum.R            # Scope 1+2 sum
    run_scope2_on_scope1.R                    # Scope-2 on Scope-1 diagnostic
    run_bank_industryyear_regs.R              # Table A.9
)
for s in "${SCRIPTS[@]}"; do
    if [ ! -f "code/06_run_regressions/$s" ]; then
        echo "[06] SKIP missing: $s"
        continue
    fi
    echo "[06] $s"
    if ! Rscript "code/06_run_regressions/$s"; then
        if [ "$FAIL_FAST" = "1" ]; then
            echo "[06]   -> $s FAILED (fail-fast mode; stopping)"
            exit 1
        else
            echo "[06]   -> $s FAILED (continuing; FAIL_FAST=0)"
        fi
    fi
done
