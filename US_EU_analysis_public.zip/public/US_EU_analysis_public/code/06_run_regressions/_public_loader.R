# _public_loader.R
# Shared loader for the public analysis tier. Every runner in
# code/06_run_regressions/ and code/07_wild_bootstrap/server/ sources this
# in place of the old `load(NEUTRAL_PANEL)` + `setDT(data_us); setDT(data_eu)`
# idiom.
#
# Contract: returns a named list with
#   panel_loan                — the full combined loan panel (data.table)
#   panel_bank_industry_year  — Table A.9 aggregate (data.table)
#   data_us, data_eu          — convenience splits of panel_loan on sample_region
#
# Reads NEUTRAL_INPUT_PATH from config_public.R (defaults to
# `<public root>/data/analysis_input.rds`). Fails with an actionable error
# if the file is not present — the public tier ships without a data file,
# so a licensed researcher must first run the Tier-2 exporter to produce it.

suppressPackageStartupMessages(library(data.table))

load_analysis_input <- function() {
    stopifnot(exists("NEUTRAL_INPUT_PATH"))
    if (!file.exists(NEUTRAL_INPUT_PATH)) {
        stop(
            "analysis_input.rds not found at:\n  ", NEUTRAL_INPUT_PATH, "\n\n",
            "The public replication tier does not ship with a data file. ",
            "Request the neutral analysis input from the authors, or request ",
            "the licensed construction-code package to rebuild it locally. ",
            "Procedure: see DATA_AVAILABILITY.md in the repository root."
        )
    }
    ai <- readRDS(NEUTRAL_INPUT_PATH)
    panel_loan <- as.data.table(ai$panel_loan)
    panel_biy  <- as.data.table(ai$panel_bank_industry_year)
    list(
        panel_loan               = panel_loan,
        panel_bank_industry_year = panel_biy,
        data_us                  = panel_loan[sample_region == "US"],
        data_eu                  = panel_loan[sample_region == "EU"]
    )
}

# `add_ratios` is a no-op on the neutral schema (ratios are pre-baked by the
# exporter). Retained as an empty function so existing runners that call
# `add_ratios(d)` compile unchanged.
add_ratios <- function(d) d

# Public `build_loansample_ilst` — identical to the licensed-tier version,
# but reads `at_rank_within_year` (pre-computed, anonymized rank within
# year) in place of the raw size column for bucket construction. Signature and output
# columns unchanged, so downstream runner code is identical.
build_loansample_ilst <- function(panel, loc_col, n_buckets, label,
                                  colname_prefix) {
    p <- copy(panel); setDT(p)
    p[, fyear_match := deal_year - 1L]
    fy <- unique(
        p[!is.na(at_rank_within_year) & !is.na(industry_id) &
          !is.na(get(loc_col)),
          .(firm_id, fyear_match, industry_id,
            loc_eff = as.character(get(loc_col)),
            at_rank_within_year)],
        by = c("firm_id", "fyear_match")
    )
    fy[, size_bucket := pmin(pmax(as.integer(
            ceiling(at_rank_within_year * n_buckets)
        ), 1L), n_buckets)]
    fy[, ilst := paste(industry_id, loc_eff, size_bucket, fyear_match,
                       sep = "_")]
    keep <- fy[, .(firm_id, fyear_match, sb = size_bucket, ilst_new = ilst)]
    setnames(keep, c("sb","ilst_new"),
             c(paste0(colname_prefix, "_size_bucket"),
               paste0(colname_prefix, "_ilst")))
    p <- merge(p, keep, by = c("firm_id", "fyear_match"), all.x = TRUE)
    p[, fyear_match := NULL]
    n_with  <- sum(!is.na(p[[paste0(colname_prefix, "_ilst")]]))
    n_cells <- p[!is.na(get(paste0(colname_prefix, "_ilst"))),
                 uniqueN(get(paste0(colname_prefix, "_ilst")))]
    cat(sprintf("  %-30s rows w/ ILST: %d/%d (%.1f%%); cells: %d\n",
                label, n_with, nrow(p), 100*n_with/nrow(p), n_cells))
    p
}
