#!/usr/bin/env Rscript
#
# run_new_benchmark_age_dummies.R
# ---------------------------------------------------------------------------
# Age-dummy robustness for the new ILST benchmark. Because raw
# `firm_age_lag` is collinear with `firm_id + bank_year_fe + ilst` (see
# project memory `project_firm_age_collinear_under_new_ilst.md`), we
# discretise age into a binary indicator and pair it with a
# missing-indicator. Two specs are run side by side.
#
# Spec 1 — Age > 10 years:
#   age_gt10_dum  = 1 if firm_age_lag > 10, 0 if firm_age_lag <= 10 or NA
#   age_nonmissing= 1 if firm_age_lag observed, 0 if NA
# Suffix: _age_gt10
#
# Spec 2 — Above the pooled-sample median:
#   Pool unique (firm_id, fyear_match) firm-years from US and EU, compute
#   the single median of firm_age_lag across the combined sample, then
#   apply the SAME cutoff to both panels:
#   age_above_pooledmed_dum = 1 if firm_age_lag > pooled_median, 0 otherwise (or NA->0)
#   age_nonmissing same as above.
# Suffix: _age_median
#
# Both specs are run on reg1 / reg2 / reg3 brown / reg4 non-brown with
# ILST FE (`firm_id + bank_year_fe + ilst`) and on reg5 between-industry
# with LST FE (`firm_id + bank_year_fe + lst`, drops industry dim). US side
# uses state x 4 size quartiles. EU side uses country x 2 size buckets.
# All other RHS, cluster, and subset choices are identical to the
# new-benchmark runners.
#
# Outputs (10 tables) under output/tables/tables_vJun2026_ILSTbenchmark/:
#   reg{1,2,3brown,4nonbrown}_us4b_eu_country2b_{age_gt10,age_median}.tex
#   reg5_between_us4b_eu_country2b_{age_gt10,age_median}.tex
# ---------------------------------------------------------------------------

suppressPackageStartupMessages({
    library(data.table)
    library(fixest)
})

# --- portability shim: source config + dict from replication_package root ---
suppressWarnings({
    .REPL_ROOT <- Sys.getenv("REPL_ROOT")
    if (!nzchar(.REPL_ROOT)) {
        .this <- tryCatch(normalizePath(sys.frame(1)$ofile, mustWork = FALSE),
                          error = function(e) "")
        if (nzchar(.this)) .REPL_ROOT <- normalizePath(file.path(dirname(.this), "..", ".."),
                                                       mustWork = FALSE)
    }
    if (!nzchar(.REPL_ROOT)) .REPL_ROOT <- normalizePath("../..", mustWork = FALSE)
    Sys.setenv(REPL_ROOT = .REPL_ROOT)
})
options(repl.verbose = FALSE)
source(file.path(Sys.getenv("REPL_ROOT"), "config_public.R"))
source(file.path(CODE_DIR, "06_run_regressions", "_public_loader.R"))
source(file.path(Sys.getenv("REPL_ROOT"), "code/06_run_regressions/_feglm_helpers.R"))
source(file.path(CODE_DIR, "06_run_regressions", "dict.R"))
# --- end shim ---


data_dir <- DATA_INTER
output_dir <- OUT_TABLES
if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)

# ---- dict ------------------------------------------------------------------
dict <- c(dict,
          age_gt10_dum            = "Age $>$ 10 yrs (lag)",
          age_above_pooledmed_dum = "Age $>$ pooled median (lag)",
          age_nonmissing          = "Age observed indicator (lag)")
cat(sprintf("Loaded dict with %d label entries\n", length(dict)))

# ---- load panel + ratios + bank_year_fe + NUTS attach (not used here) -------
.ai <- load_analysis_input()
data_us <- .ai$data_us
data_eu <- .ai$data_eu
data_us <- add_ratios(data_us)
data_eu <- add_ratios(data_eu)
data_us[, bank_year_fe := as.factor(bank_id):as.factor(deal_year)]
data_eu[, bank_year_fe := as.factor(bank_id):as.factor(deal_year)]

# ---- compute age dummies on each panel -------------------------------------
add_age_dummies <- function(d) {
    d <- copy(d)
    d[, age_nonmissing := as.integer(!is.na(firm_age_lag))]
    # Standard missing-indicator method: set the dummy to 0 for NA rows so
    # they stay in the regression; age_nonmissing flags the missingness.
    d[, age_gt10_dum := as.integer(!is.na(firm_age_lag) & firm_age_lag > 10L)]
    d
}
data_us <- add_age_dummies(data_us)
data_eu <- add_age_dummies(data_eu)

# Pooled-sample median: collapse to unique (firm_id, fyear_match) firm-years
# per panel, concatenate, take median of firm_age_lag.
fy_us <- unique(data_us[!is.na(firm_age_lag),
                        .(firm_id, fyear_match = deal_year - 1L, firm_age_lag)],
                by = c("firm_id","fyear_match"))
fy_eu <- unique(data_eu[!is.na(firm_age_lag),
                        .(firm_id, fyear_match = deal_year - 1L, firm_age_lag)],
                by = c("firm_id","fyear_match"))
pooled_age <- c(fy_us$firm_age_lag, fy_eu$firm_age_lag)
pooled_median_age <- median(pooled_age, na.rm = TRUE)
cat(sprintf("Pooled firm-year sample for median: US %d + EU %d = %d firm-years; median firm_age_lag = %.1f\n",
            nrow(fy_us), nrow(fy_eu),
            nrow(fy_us) + nrow(fy_eu), pooled_median_age))

data_us[, age_above_pooledmed_dum :=
            as.integer(!is.na(firm_age_lag) & firm_age_lag > pooled_median_age)]
data_eu[, age_above_pooledmed_dum :=
            as.integer(!is.na(firm_age_lag) & firm_age_lag > pooled_median_age)]

# Diagnostics
diag <- function(d, label) {
    cat(sprintf("  %s: rows=%d  age_nonmissing=%.1f%%  age_gt10=%.1f%%  age>median=%.1f%%\n",
                label, nrow(d),
                100*mean(d$age_nonmissing),
                100*mean(d$age_gt10_dum),
                100*mean(d$age_above_pooledmed_dum)))
}
diag(data_us, "US")
diag(data_eu, "EU")

# ---- build ILST (reg1-4) and LST (reg5) cells, US 4b / EU country 2b -------
build_loansample_lst <- function(panel, loc_col, n_buckets, out_name, label) {
    p <- copy(panel); setDT(p)
    p[, fyear_match := deal_year - 1L]
    fy <- unique(
        p[!is.na(at_rank_within_year) &
          !is.na(get(loc_col)) & get(loc_col) != "",
          .(firm_id, fyear_match,
            loc_eff = as.character(get(loc_col)), at_rank_within_year)],
        by = c("firm_id","fyear_match")
    )
    fy[, size_bucket := as.integer(ceiling(
            at_rank_within_year * n_buckets
        )), by = fyear_match]
    fy[size_bucket > n_buckets, size_bucket := n_buckets]
    fy[size_bucket < 1L,        size_bucket := 1L]
    fy[, cell := paste(loc_eff, size_bucket, fyear_match, sep = "_")]
    keep <- fy[, .(firm_id, fyear_match, cell)]
    setnames(keep, "cell", out_name)
    if (out_name %in% names(p)) p[, (out_name) := NULL]
    p <- merge(p, keep, by = c("firm_id","fyear_match"), all.x = TRUE)
    p[, fyear_match := NULL]
    cat(sprintf("  %s: rows w/ %s = %d (%.1f%%); cells = %d\n",
                label, out_name,
                sum(!is.na(p[[out_name]])),
                100*mean(!is.na(p[[out_name]])),
                length(unique(na.omit(p[[out_name]])))))
    p
}

data_us <- build_loansample_ilst(data_us, "state_id", 4L, "us4b_ilst", "US ILST (state x 4b)")
data_us <- build_loansample_lst (data_us, "state", 4L, "us4b_lst",  "US  LST (state x 4b)")
data_eu <- build_loansample_ilst(data_eu, "country_id",   2L, "eu2b_ilst", "EU ILST (country x 2b)")
data_eu <- build_loansample_lst (data_eu, "loc",   2L, "eu2b_lst",  "EU  LST (country x 2b)")

# ---- etable writer ---------------------------------------------------------
safe_etable <- function(models, file_name) {
    tryCatch({
        etable(models, dict = dict, style.tex = style.tex("aer"),
               signif.code = c("***"=0.01, "**"=0.05, "*"=0.10),
               fitstat = ~ r2 + n, digits = "r3", tex = TRUE,
               file = file.path(output_dir, file_name), replace = TRUE)
        cat(sprintf("  wrote %s\n", file_name))
    }, error = function(e) {
        # Log, then propagate so FAIL_FAST/run.sh halts (fixed 2026-11-04;
        # was previously swallowing write failures and leaving stale tables).
        cat(sprintf("  !!! etable failed for %s: %s
",
                    file_name, conditionMessage(e)))
        stop(sprintf("etable failed for %s: %s", file_name, conditionMessage(e)))
    })
}

fit_block <- function(d, cell_col, rhs, lbl_prefix = NA_character_) {
    fe <- sprintf("firm_id + bank_year_fe + %s", cell_col)
    mk_lbl <- function(outcome) {
        if (is.na(lbl_prefix)) NA_character_
        else sprintf("%s | %s | %s", lbl_prefix, cell_col, outcome)
    }
    list(
        g = feols(as.formula(paste0("outcome_loan_growth ~ ", rhs, " | ", fe)),
                  data = d, cluster = ~industry_id),
        h = feols(as.formula(paste0("outcome_log_loan   ~ ", rhs, " | ", fe)),
                  data = d, cluster = ~industry_id),
        i = feglm_safe(as.formula(paste0("outcome_new_loan     ~ ", rhs, " | ", fe)),
                  data = d, family = binomial(link = "logit"),
                  cluster = ~industry_id,
                  .label = mk_lbl("new_loan")),
        l = feglm_safe(as.formula(paste0("outcome_first_loan ~ ", rhs, " | ", fe)),
                  data = d, family = binomial(link = "logit"),
                  cluster = ~industry_id,
                  .label = mk_lbl("first_loan"))
    )
}

# RHS templates: %s placeholder for the age-related variables
RHS_REG1_TMPL     <- paste(
    "scope1_log_intensity_lag:paris + scope2_log_intensity_lag:paris +",
    "scope1_log_intensity_diff_lag:paris + scope2_log_intensity_diff_lag:paris +",
    "ln_totalassets_lag + leverage_ratio_lag +",
    "capex_totalassets_ratio_lag + ebitda_assets_ratio_lag + %s")
RHS_RELATIVE_TMPL <- paste(
    "scope1_log_rel_intensity_lag:paris + scope2_log_rel_intensity_lag:paris +",
    "scope1_log_rel_intensity_diff_lag:paris + scope2_log_rel_intensity_diff_lag:paris +",
    "ln_totalassets_lag + leverage_ratio_lag +",
    "capex_totalassets_ratio_lag + ebitda_assets_ratio_lag + %s")
RHS_REG5_TMPL     <- paste(
    "scope1_log_intensity_industry_lag:paris +",
    "scope2_log_intensity_industry_lag:paris +",
    "ln_scope1_intensity_industry_diff_lag:paris +",
    "ln_scope2_intensity_industry_diff_lag:paris +",
    "ln_totalassets_lag + leverage_ratio_lag +",
    "capex_totalassets_ratio_lag + ebitda_assets_ratio_lag + %s")

# Single age-spec pass: produces reg1-5 tables for one suffix + RHS tail
run_one_spec <- function(age_vars_str, sfx) {
    cat(sprintf("\n=== Age spec: %s   (RHS tail: %s) ===\n", sfx, age_vars_str))

    # reg1 (firm-level)
    rhs <- sprintf(RHS_REG1_TMPL, age_vars_str)
    cat("  -- reg1 --\n")
    us <- fit_block(data_us, "us4b_ilst", rhs, lbl_prefix = sprintf("reg1_%s | US", sfx))
    eu <- fit_block(data_eu, "eu2b_ilst", rhs, lbl_prefix = sprintf("reg1_%s | EU", sfx))
    safe_etable(list(us$g, us$h, us$i, us$l, eu$g, eu$h, eu$i, eu$l),
                sprintf("reg1_us4b_eu_country2b_%s.tex", sfx))

    # reg2 (within all)
    rhs <- sprintf(RHS_RELATIVE_TMPL, age_vars_str)
    cat("  -- reg2 --\n")
    us <- fit_block(data_us, "us4b_ilst", rhs, lbl_prefix = sprintf("reg2_%s | US", sfx))
    eu <- fit_block(data_eu, "eu2b_ilst", rhs, lbl_prefix = sprintf("reg2_%s | EU", sfx))
    safe_etable(list(us$g, us$h, us$i, us$l, eu$g, eu$h, eu$i, eu$l),
                sprintf("reg2_us4b_eu_country2b_%s.tex", sfx))

    # reg3 (brown)
    cat("  -- reg3 brown --\n")
    du <- data_us[industry_brown_class_ft == "brown"]
    de <- data_eu[industry_brown_class_ft == "brown"]
    us <- fit_block(du, "us4b_ilst", rhs, lbl_prefix = sprintf("reg3brown_%s | US", sfx))
    eu <- fit_block(de, "eu2b_ilst", rhs, lbl_prefix = sprintf("reg3brown_%s | EU", sfx))
    safe_etable(list(us$g, us$h, us$i, us$l, eu$g, eu$h, eu$i, eu$l),
                sprintf("reg3brown_us4b_eu_country2b_%s.tex", sfx))

    # reg4 (non-brown)
    cat("  -- reg4 non-brown --\n")
    du <- data_us[industry_brown_class_ft == "non_brown"]
    de <- data_eu[industry_brown_class_ft == "non_brown"]
    us <- fit_block(du, "us4b_ilst", rhs, lbl_prefix = sprintf("reg4nonbrown_%s | US", sfx))
    eu <- fit_block(de, "eu2b_ilst", rhs, lbl_prefix = sprintf("reg4nonbrown_%s | EU", sfx))
    safe_etable(list(us$g, us$h, us$i, us$l, eu$g, eu$h, eu$i, eu$l),
                sprintf("reg4nonbrown_us4b_eu_country2b_%s.tex", sfx))

    # reg5 between (LST FE — no industry dim)
    rhs <- sprintf(RHS_REG5_TMPL, age_vars_str)
    cat("  -- reg5 between --\n")
    us <- fit_block(data_us, "us4b_lst", rhs, lbl_prefix = sprintf("reg5_%s | US", sfx))
    eu <- fit_block(data_eu, "eu2b_lst", rhs, lbl_prefix = sprintf("reg5_%s | EU", sfx))
    safe_etable(list(us$g, us$h, us$i, us$l, eu$g, eu$h, eu$i, eu$l),
                sprintf("reg5_between_us4b_eu_country2b_%s.tex", sfx))
}

# ---- run both specs --------------------------------------------------------
run_one_spec("age_gt10_dum + age_nonmissing",           "age_gt10")
run_one_spec("age_above_pooledmed_dum + age_nonmissing","age_median")

cat("\n=== run_new_benchmark_age_dummies.R done ===\n")

# Known-non-converged cells, suppressed downstream by
# script/suppress_nonconv_cells.py. Enumerate them so the pipeline doesn't
# halt on expected conditions, while any OTHER non-convergence still fails
# fast.
check_all_converged(
    script = "run_new_benchmark_age_dummies.R",
    expected_failures = c(
        "reg3brown_age_gt10 | US | us4b_ilst | first_loan"
    )
)
