#!/usr/bin/env Rscript
#
# run_scope2_on_scope1.R
# ---------------------------------------------------------------------------
# Firm-year diagnostic regression of scope-2 emission intensity on
# scope-1 emission intensity. Verbatim from credit_realloc_EERrev_regs.R
# lines 465-488 ("Firm-level diagnostic: Scope 2 ~ Scope 1 intensity").
# Demonstrates that, conditional on borrower and industry-year fixed
# effects, scope-2 intensity is not mechanically pinned down by scope-1
# -- justifying inclusion of both scopes as separate regressors in the
# loan regressions.
#
# FE (verbatim from EERrev):
#   US:   firm_id + Industry_Year                  (firm + industry-year)
#   EU:   firm_id + Industry_Year + loc            (+ country)
# bank_year_fe is intentionally absent: this is a firm-year regression
# (not loan-year), so the bank-time dimension does not apply.
#
# Standard errors clustered at industry_id.
#
# Output: output/tables/tables_vJun2026_ILSTbenchmark/scope2_on_scope1_intensity.tex
# ---------------------------------------------------------------------------

suppressPackageStartupMessages({
    library(data.table)
    library(fixest)
})

# --- portability shim: source config + dict from replication_package root ---
suppressWarnings({
    .REPL_ROOT <- Sys.getenv("REPL_ROOT")
    if (!nzchar(.REPL_ROOT)) {
        .this <- tryCatch(normalizePath(sys.frame(1)$ofile, mustWork = FALSE),
                          error = function(e) "")
        if (nzchar(.this)) .REPL_ROOT <- normalizePath(file.path(dirname(.this), "..", ".."),
                                                       mustWork = FALSE)
    }
    if (!nzchar(.REPL_ROOT)) .REPL_ROOT <- normalizePath("../..", mustWork = FALSE)
    Sys.setenv(REPL_ROOT = .REPL_ROOT)
})
options(repl.verbose = FALSE)
source(file.path(Sys.getenv("REPL_ROOT"), "config_public.R"))
source(file.path(CODE_DIR, "06_run_regressions", "_public_loader.R"))
source(file.path(CODE_DIR, "06_run_regressions", "dict.R"))
# --- end shim ---


data_dir <- DATA_INTER
output_dir <- OUT_TABLES
if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)

# Pull dict from source-of-truth for consistent labels
cat(sprintf("Loaded dict with %d label entries\n", length(dict)))

# Load panel + add Industry_Year factor (loan panel works fine for this
# diagnostic since it has all firm-year rows for borrowers; the
# regression collapses to firm-year via the firm_id + Industry_Year FE).
.ai <- load_analysis_input()
data_us <- .ai$data_us
data_eu <- .ai$data_eu
data_us[, Industry_Year := as.factor(industry_id):as.factor(deal_year)]
data_eu[, Industry_Year := as.factor(industry_id):as.factor(deal_year)]

cat(sprintf("US rows: %d  | EU rows: %d\n", nrow(data_us), nrow(data_eu)))

scope_reg_us <- feols(firm_scope2_intensity_sales ~ firm_scope1_intensity_sales |
                          firm_id + Industry_Year,
                      data = data_us, cluster = ~industry_id)

scope_reg_eu <- feols(firm_scope2_intensity_sales ~ firm_scope1_intensity_sales |
                          firm_id + Industry_Year + loc,
                      data = data_eu, cluster = ~industry_id)

cat("\n=== US ===\n"); print(summary(scope_reg_us))
cat("\n=== EU ===\n"); print(summary(scope_reg_eu))

out_file <- "scope2_on_scope1_intensity.tex"
tryCatch({
    etable(list(scope_reg_us, scope_reg_eu),
           dict = dict, style.tex = style.tex("aer"),
           signif.code = c("***"=0.01, "**"=0.05, "*"=0.10),
           fitstat = ~ r2 + n, digits = "r3", tex = TRUE,
           file = file.path(output_dir, out_file), replace = TRUE)
    cat(sprintf("\nwrote %s\n", file.path(output_dir, out_file)))
}, error = function(e) {
    # Log, then propagate so FAIL_FAST halts (fixed 2026-11-04; was
    # previously swallowing write failures and leaving a stale table).
    cat("!! etable failed:", conditionMessage(e), "\n")
    stop(sprintf("etable failed for %s: %s", out_file, conditionMessage(e)))
})

cat("\n=== run_scope2_on_scope1.R done ===\n")
