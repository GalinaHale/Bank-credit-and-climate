#!/usr/bin/env Rscript
#
# run_new_benchmark_ilst.R
# ---------------------------------------------------------------------------
# NEW benchmark specification agreed with coauthors (post-meeting Jun 2026).
# Replaces Industry-Year FE with ILST FE in the 4 reg families:
#   reg1 (firm-level), reg2 (within all), reg3 (within brown), reg4 (within non-brown)
# Between-industry (reg5) is NOT run in this script.
#
# FE: firm_id + bank_year_fe + ilst   (cluster ~industry_id)
#
# Two US-bucket variants run side by side:
#   US ILST = industry_id × state   × size_bucket(4 OR 2, loan-sample) × deal_year
#   EU ILST = industry_id × loc     × size_bucket(2,        loan-sample) × deal_year  (country)
# i.e. each of 4 reg families gets TWO tables: one with US-4b, one with US-2b.
# EU side is always country × 2-bucket (the empirical winner for the brown subset).
#
# Robustness for reg4 (non-brown) only:
#   EU ILST = industry_id × NUTS-2 × size_bucket(4, loan-sample) × deal_year
# Produced for both US-bucket variants. US side identical to main spec.
#
# Outputs (under output/tables/tables_vJun2026_ILSTbenchmark/):
#   reg1_us{4b,2b}_eu_country2b.tex
#   reg2_us{4b,2b}_eu_country2b.tex
#   reg3brown_us{4b,2b}_eu_country2b.tex
#   reg4nonbrown_us{4b,2b}_eu_country2b.tex
#   reg4nonbrown_us{4b,2b}_eu_nuts2_4b_ROBUST.tex
# ---------------------------------------------------------------------------

suppressPackageStartupMessages({
    library(data.table)
    library(fixest)
})

# --- portability shim: source config + dict from replication_package root ---
suppressWarnings({
    .REPL_ROOT <- Sys.getenv("REPL_ROOT")
    if (!nzchar(.REPL_ROOT)) {
        .this <- tryCatch(normalizePath(sys.frame(1)$ofile, mustWork = FALSE),
                          error = function(e) "")
        if (nzchar(.this)) .REPL_ROOT <- normalizePath(file.path(dirname(.this), "..", ".."),
                                                       mustWork = FALSE)
    }
    if (!nzchar(.REPL_ROOT)) .REPL_ROOT <- normalizePath("../..", mustWork = FALSE)
    Sys.setenv(REPL_ROOT = .REPL_ROOT)
})
options(repl.verbose = FALSE)
source(file.path(Sys.getenv("REPL_ROOT"), "config_public.R"))
source(file.path(CODE_DIR, "06_run_regressions", "_public_loader.R"))
source(file.path(Sys.getenv("REPL_ROOT"), "code/06_run_regressions/_feglm_helpers.R"))
source(file.path(CODE_DIR, "06_run_regressions", "dict.R"))
# --- end shim ---


data_dir <- DATA_INTER
output_dir <- OUT_TABLES
if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)
cat("Writing tables to: ", output_dir, "\n", sep = "")

# ---- 1. dict from source-of-truth ------------------------------------------
cat(sprintf("Loaded dict with %d label entries\n", length(dict)))

# ---- 2. Load panel + ratios + FE factors -----------------------------------
.ai <- load_analysis_input()
data_us <- .ai$data_us
data_eu <- .ai$data_eu
data_us <- add_ratios(data_us)
data_eu <- add_ratios(data_eu)

data_us[, bank_year_fe := as.factor(bank_id):as.factor(deal_year)]
data_eu[, bank_year_fe := as.factor(bank_id):as.factor(deal_year)]

# US: state, 4 and 2 buckets
data_us <- build_loansample_ilst(data_us, loc_col = "state_id", n_buckets = 4L,
                                 label = "US state × 4 buckets",
                                 colname_prefix = "us4b")
data_us <- build_loansample_ilst(data_us, loc_col = "state_id", n_buckets = 2L,
                                 label = "US state × 2 buckets",
                                 colname_prefix = "us2b")

# EU main: country, 2 buckets
data_eu <- build_loansample_ilst(data_eu, loc_col = "country_id",   n_buckets = 2L,
                                 label = "EU country × 2 buckets",
                                 colname_prefix = "eu2b")
# EU robustness: NUTS-2, 4 buckets
data_eu <- build_loansample_ilst(data_eu, loc_col = "nuts2_id", n_buckets = 4L,
                                 label = "EU NUTS-2 × 4 buckets (robust)",
                                 colname_prefix = "eunuts4b")

# ---- 5. etable writer ------------------------------------------------------
safe_etable <- function(models, file_name) {
    tryCatch({
        etable(models, dict = dict, style.tex = style.tex("aer"),
               signif.code = c("***"=0.01, "**"=0.05, "*"=0.10),
               fitstat = ~ r2 + n, digits = "r3", tex = TRUE,
               file = file.path(output_dir, file_name), replace = TRUE)
        cat(sprintf("  wrote %s\n", file_name))
    }, error = function(e) {
        # Log, then propagate so FAIL_FAST/run.sh halts (fixed 2026-11-04;
        # was previously swallowing write failures and leaving stale tables).
        cat(sprintf("  !!! etable failed for %s: %s
",
                    file_name, conditionMessage(e)))
        stop(sprintf("etable failed for %s: %s", file_name, conditionMessage(e)))
    })
}

# ---- 6. Reg runners --------------------------------------------------------
# Reusable runner: given a panel + an `ilst` column name on that panel,
# return list of 4 fitted models for outcomes (g, h, i, l) for a given rhs.
fit_block <- function(d, ilst_col, rhs, subset_filter = NULL,
                      lbl_prefix = NA_character_) {
    if (!is.null(subset_filter)) d <- d[eval(subset_filter)]
    fe <- sprintf("firm_id + bank_year_fe + %s", ilst_col)
    mk_lbl <- function(outcome) {
        if (is.na(lbl_prefix)) NA_character_
        else sprintf("%s | %s | %s", lbl_prefix, ilst_col, outcome)
    }
    out <- list()
    out$g <- feols(as.formula(paste0("outcome_loan_growth ~ ", rhs, " | ", fe)),
                   data = d, cluster = ~industry_id)
    out$h <- feols(as.formula(paste0("outcome_log_loan   ~ ", rhs, " | ", fe)),
                   data = d, cluster = ~industry_id)
    out$i <- feglm_safe(as.formula(paste0("outcome_new_loan     ~ ", rhs, " | ", fe)),
                   data = d, family = binomial(link = "logit"),
                   cluster = ~industry_id,
                   .label = mk_lbl("new_loan"))
    out$l <- feglm_safe(as.formula(paste0("outcome_first_loan ~ ", rhs, " | ", fe)),
                   data = d, family = binomial(link = "logit"),
                   cluster = ~industry_id,
                   .label = mk_lbl("first_loan"))
    out
}

# RHS specs
RHS <- list(
    reg1 = paste(
        "scope1_log_intensity_lag:paris + scope2_log_intensity_lag:paris +",
        "scope1_log_intensity_diff_lag:paris + scope2_log_intensity_diff_lag:paris +",
        "ln_totalassets_lag + leverage_ratio_lag +",
        "capex_totalassets_ratio_lag + ebitda_assets_ratio_lag"),
    relative = paste(
        "scope1_log_rel_intensity_lag:paris + scope2_log_rel_intensity_lag:paris +",
        "scope1_log_rel_intensity_diff_lag:paris + scope2_log_rel_intensity_diff_lag:paris +",
        "ln_totalassets_lag + leverage_ratio_lag +",
        "capex_totalassets_ratio_lag + ebitda_assets_ratio_lag")
)

# Build one US+EU table for a given (US ilst col, EU ilst col, RHS key,
# US subset, EU subset, output file name).
run_pair <- function(us_ilst, eu_ilst, rhs_key,
                     us_filter = NULL, eu_filter = NULL,
                     out_file) {
    cat(sprintf("\n--- %s ---\n", out_file))
    rhs <- RHS[[rhs_key]]
    lbl_stem <- sub("\\.tex$", "", out_file)
    us_models <- fit_block(data_us, us_ilst, rhs, subset_filter = us_filter,
                           lbl_prefix = sprintf("%s | US", lbl_stem))
    eu_models <- fit_block(data_eu, eu_ilst, rhs, subset_filter = eu_filter,
                           lbl_prefix = sprintf("%s | EU", lbl_stem))
    safe_etable(list(us_models$g, us_models$h, us_models$i, us_models$l,
                     eu_models$g, eu_models$h, eu_models$i, eu_models$l),
                out_file)
}

# ---- 7. MAIN: 4 reg families × 2 US bucket variants -----------------------
cat("\n=== Main spec (EU = country × 2 buckets) ===\n")
for (us_spec in c("us4b", "us2b")) {
    us_ilst <- paste0(us_spec, "_ilst")
    eu_ilst <- "eu2b_ilst"
    sfx <- sprintf("%s_eu_country2b", us_spec)

    # reg1 — firm-level log intensity, full sample
    run_pair(us_ilst, eu_ilst, rhs_key = "reg1",
             out_file = sprintf("reg1_%s.tex", sfx))

    # reg2 — log relative intensity, full sample
    run_pair(us_ilst, eu_ilst, rhs_key = "relative",
             out_file = sprintf("reg2_%s.tex", sfx))

    # reg3 — brown subset
    run_pair(us_ilst, eu_ilst, rhs_key = "relative",
             us_filter = quote(industry_brown_class_ft == "brown"),
             eu_filter = quote(industry_brown_class_ft == "brown"),
             out_file = sprintf("reg3brown_%s.tex", sfx))

    # reg4 — non-brown subset
    run_pair(us_ilst, eu_ilst, rhs_key = "relative",
             us_filter = quote(industry_brown_class_ft == "non_brown"),
             eu_filter = quote(industry_brown_class_ft == "non_brown"),
             out_file = sprintf("reg4nonbrown_%s.tex", sfx))
}

# ---- 8. ROBUSTNESS: reg4 non-brown, EU = NUTS-2 × 4 buckets ---------------
cat("\n=== Robustness (reg4 non-brown, EU = NUTS-2 × 4 buckets) ===\n")
for (us_spec in c("us4b", "us2b")) {
    us_ilst <- paste0(us_spec, "_ilst")
    sfx <- sprintf("%s_eu_nuts2_4b_ROBUST", us_spec)
    run_pair(us_ilst, "eunuts4b_ilst", rhs_key = "relative",
             us_filter = quote(industry_brown_class_ft == "non_brown"),
             eu_filter = quote(industry_brown_class_ft == "non_brown"),
             out_file = sprintf("reg4nonbrown_%s.tex", sfx))
}

cat("\n=== run_new_benchmark_ilst.R done ===\n")

# Known-non-converged cell, suppressed downstream by
# script/suppress_nonconv_cells.py:
#   reg3brown_us2b_eu_country2b.tex col 3 — US new_loan under the
#   us2b (state x 2-bucket) ILST variant. Confirmed quasi-separated:
#   outer glm.iter hits 300, inner demeaning hits fixef.iter cap.
check_all_converged(
    script = "run_new_benchmark_ilst.R",
    expected_failures = c(
        "reg3brown_us2b_eu_country2b | US | us2b_ilst | new_loan"
    )
)
