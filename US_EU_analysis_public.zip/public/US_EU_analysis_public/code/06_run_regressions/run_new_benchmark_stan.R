#!/usr/bin/env Rscript
# run_new_benchmark_stan.R
# ---------------------------------------------------------------------------
# Benchmark reg1-5 under the new ILST FE, using STAN-deflated emission
# intensity variables in place of the GDP-deflated versions.
#
# Replaces on the RHS (both scopes; lag / diff / diff_lag):
#   reg1: ln_ghg_scope{1,2}_intensity_lag        ->  ln_ghg_scope{1,2}_intensity_stan_lag
#         (and diff_lag)
#   reg2-4: ghg_scope{1,2}_log_relative_intensity_lag ->  ghg_scope{1,2}_log_relative_intensity_stan_lag
#         (and diff_lag)
#   reg5: ln_scope{1,2}_intensity_industry_lag  ->  ln_scope{1,2}_intensity_industry_stan_lag
#         (and diff_lag)
#
# Sample restriction: uses the STAN FT brown classification
# industry_brown_class_ft_stan for reg3/reg4 (per user request:
# only FT brown/non-brown, not TV/p90 variants).
#
# FE (unchanged from new benchmark):
#   reg1-4: firm_id + bank_year_fe + ilst   (US state x 4b, EU country x 2b)
#   reg5:   firm_id + bank_year_fe + lst    (drops industry from cell)
#
# Cluster: ~industry_id.
# US bucket variant: state x 4 buckets (matches other threshold-family runs).
# Only the country/2b EU spec is produced (no NUTS-2 x 4 robustness here).
#
# Outputs (under output/tables/tables_vJun2026_ILSTbenchmark/):
#   reg{1,2,3brown,4nonbrown,5_between}_us4b_eu_country2b_stan.tex
# ---------------------------------------------------------------------------

suppressPackageStartupMessages({
    library(data.table)
    library(fixest)
})

# --- portability shim: source config + dict from replication_package root ---
suppressWarnings({
    .REPL_ROOT <- Sys.getenv("REPL_ROOT")
    if (!nzchar(.REPL_ROOT)) {
        .this <- tryCatch(normalizePath(sys.frame(1)$ofile, mustWork = FALSE),
                          error = function(e) "")
        if (nzchar(.this)) .REPL_ROOT <- normalizePath(file.path(dirname(.this), "..", ".."),
                                                       mustWork = FALSE)
    }
    if (!nzchar(.REPL_ROOT)) .REPL_ROOT <- normalizePath("../..", mustWork = FALSE)
    Sys.setenv(REPL_ROOT = .REPL_ROOT)
})
options(repl.verbose = FALSE)
source(file.path(Sys.getenv("REPL_ROOT"), "config_public.R"))
source(file.path(CODE_DIR, "06_run_regressions", "_public_loader.R"))
source(file.path(Sys.getenv("REPL_ROOT"), "code/06_run_regressions/_feglm_helpers.R"))
source(file.path(CODE_DIR, "06_run_regressions", "dict.R"))
# --- end shim ---


data_dir <- DATA_INTER
output_dir <- OUT_TABLES
if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)

# dict
dict <- c(dict,
          scope1_log_intensity_stan_lag       = "Log (Intensity)$_{t-1}$ (Scope 1) [STAN]",
          scope2_log_intensity_stan_lag       = "Log (Intensity)$_{t-1}$ (Scope 2) [STAN]",
          scope1_log_intensity_stan_diff_lag  = "$\\Delta$Log(Intensity)$_{t-1}$ (S1) [STAN]",
          scope2_log_intensity_stan_diff_lag  = "$\\Delta$Log(Intensity)$_{t-1}$ (S2) [STAN]",
          scope1_log_rel_intensity_stan_lag       = "Rel. Intensity$_{t-1}$ (S1) [STAN]",
          scope2_log_rel_intensity_stan_lag       = "Rel. Intensity$_{t-1}$ (S2) [STAN]",
          scope1_log_rel_intensity_stan_diff_lag  = "$\\Delta$Rel. Intensity$_{t-1}$ (S1) [STAN]",
          scope2_log_rel_intensity_stan_diff_lag  = "$\\Delta$Rel. Intensity$_{t-1}$ (S2) [STAN]",
          scope1_log_intensity_industry_stan_lag       = "Log Ind. Intensity$_{t-1}$ (S1) [STAN]",
          scope2_log_intensity_industry_stan_lag       = "Log Ind. Intensity$_{t-1}$ (S2) [STAN]",
          scope1_log_intensity_industry_stan_diff_lag  = "$\\Delta$Log Ind. Intensity$_{t-1}$ (S1) [STAN]",
          scope2_log_intensity_industry_stan_diff_lag  = "$\\Delta$Log Ind. Intensity$_{t-1}$ (S2) [STAN]")
cat(sprintf("Loaded dict with %d label entries\n", length(dict)))

# panel + ratios + bank_year_fe
.ai <- load_analysis_input()
data_us <- .ai$data_us
data_eu <- .ai$data_eu
data_us <- add_ratios(data_us)
data_eu <- add_ratios(data_eu)
data_us[, bank_year_fe := as.factor(bank_id):as.factor(deal_year)]
data_eu[, bank_year_fe := as.factor(bank_id):as.factor(deal_year)]

# ---- coverage diagnostics before running -----------------------------------
diag_stan_coverage <- function(d, label) {
    cat(sprintf("\n%s coverage:\n", label))
    for (v in c("scope1_log_intensity_stan_lag",
                "scope1_log_rel_intensity_stan_lag",
                "scope1_log_intensity_industry_stan_lag",
                "industry_brown_class_ft_stan")) {
        if (v %in% names(d)) {
            cat(sprintf("  %-55s %d/%d (%.1f%%)\n", v,
                        sum(!is.na(d[[v]])), nrow(d),
                        100*mean(!is.na(d[[v]]))))
        } else {
            cat(sprintf("  %-55s [MISSING]\n", v))
        }
    }
    if ("industry_brown_class_ft_stan" %in% names(d)) {
        ct <- d[!is.na(industry_brown_class_ft_stan),
                .N, by = industry_brown_class_ft_stan]
        cat("  STAN FT category:\n"); print(ct)
    }
}
diag_stan_coverage(data_us, "data_us")
diag_stan_coverage(data_eu, "data_eu")

stopifnot("scope1_log_intensity_industry_stan_lag" %in% names(data_us))

# ---- ILST + LST builders (US 4b, EU country 2b) ----------------------------
build_ilst <- function(panel, loc_col, n_buckets, out_name) {
    p <- copy(panel); setDT(p)
    p[, fyear_match := deal_year - 1L]
    fy <- unique(
        p[!is.na(at_rank_within_year) & !is.na(industry_id) & industry_id != "" &
          !is.na(get(loc_col)) & get(loc_col) != "",
          .(firm_id, fyear_match, industry_id,
            loc_eff = as.character(get(loc_col)), at_rank_within_year)],
        by = c("firm_id","fyear_match"))
    fy[, sb := as.integer(ceiling(at_rank_within_year * n_buckets)),
       by = fyear_match]
    fy[sb > n_buckets, sb := n_buckets]; fy[sb < 1L, sb := 1L]
    fy[, cell := paste(industry_id, loc_eff, sb, fyear_match, sep="_")]
    keep <- fy[, .(firm_id, fyear_match, cell)]
    setnames(keep, "cell", out_name)
    if (out_name %in% names(p)) p[, (out_name) := NULL]
    p <- merge(p, keep, by = c("firm_id","fyear_match"), all.x = TRUE)
    p[, fyear_match := NULL]
    p
}
build_lst <- function(panel, loc_col, n_buckets, out_name) {
    p <- copy(panel); setDT(p)
    p[, fyear_match := deal_year - 1L]
    fy <- unique(
        p[!is.na(at_rank_within_year) & !is.na(get(loc_col)) & get(loc_col) != "",
          .(firm_id, fyear_match,
            loc_eff = as.character(get(loc_col)), at_rank_within_year)],
        by = c("firm_id","fyear_match"))
    fy[, sb := as.integer(ceiling(at_rank_within_year * n_buckets)),
       by = fyear_match]
    fy[sb > n_buckets, sb := n_buckets]; fy[sb < 1L, sb := 1L]
    fy[, cell := paste(loc_eff, sb, fyear_match, sep="_")]
    keep <- fy[, .(firm_id, fyear_match, cell)]
    setnames(keep, "cell", out_name)
    if (out_name %in% names(p)) p[, (out_name) := NULL]
    p <- merge(p, keep, by = c("firm_id","fyear_match"), all.x = TRUE)
    p[, fyear_match := NULL]
    p
}
data_us <- build_ilst(data_us, "state_id", 4L, "us4b_ilst")
data_us <- build_lst (data_us, "state", 4L, "us4b_lst")
data_eu <- build_ilst(data_eu, "country_id",   2L, "eu2b_ilst")
data_eu <- build_lst (data_eu, "loc",   2L, "eu2b_lst")

# etable writer
safe_etable <- function(models, file_name) {
    tryCatch({
        etable(models, dict = dict, style.tex = style.tex("aer"),
               signif.code = c("***"=0.01, "**"=0.05, "*"=0.10),
               fitstat = ~ r2 + n, digits = "r3", tex = TRUE,
               file = file.path(output_dir, file_name), replace = TRUE)
        cat(sprintf("  wrote %s\n", file_name))
    }, error = function(e) {
        # Log, then propagate so FAIL_FAST/run.sh halts (fixed 2026-11-04;
        # was previously swallowing write failures and leaving stale tables).
        cat(sprintf("  !!! etable failed for %s: %s
",
                    file_name, conditionMessage(e)))
        stop(sprintf("etable failed for %s: %s", file_name, conditionMessage(e)))
    })
}

fit_block <- function(d, cell_col, rhs, lbl_prefix = NA_character_) {
    fe <- sprintf("firm_id + bank_year_fe + %s", cell_col)
    mk_lbl <- function(outcome) {
        if (is.na(lbl_prefix)) NA_character_
        else sprintf("%s | %s | %s", lbl_prefix, cell_col, outcome)
    }
    list(
        g = feols(as.formula(paste0("outcome_loan_growth ~ ", rhs, " | ", fe)),
                  data = d, cluster = ~industry_id),
        h = feols(as.formula(paste0("outcome_log_loan   ~ ", rhs, " | ", fe)),
                  data = d, cluster = ~industry_id),
        i = feglm_safe(as.formula(paste0("outcome_new_loan     ~ ", rhs, " | ", fe)),
                  data = d, family = binomial(link = "logit"),
                  cluster = ~industry_id,
                  .label = mk_lbl("new_loan")),
        l = feglm_safe(as.formula(paste0("outcome_first_loan ~ ", rhs, " | ", fe)),
                  data = d, family = binomial(link = "logit"),
                  cluster = ~industry_id,
                  .label = mk_lbl("first_loan"))
    )
}

CONTROLS_TAIL <- "ln_totalassets_lag + leverage_ratio_lag + capex_totalassets_ratio_lag + ebitda_assets_ratio_lag"

# --- reg1 (firm-level log intensity) ---------------------------------------
cat("\n=== reg1 STAN ===\n")
rhs1 <- paste(
    "scope1_log_intensity_stan_lag:paris + scope2_log_intensity_stan_lag:paris +",
    "scope1_log_intensity_stan_diff_lag:paris + scope2_log_intensity_stan_diff_lag:paris +",
    CONTROLS_TAIL)
us <- fit_block(data_us, "us4b_ilst", rhs1, lbl_prefix = "reg1_stan | US")
eu <- fit_block(data_eu, "eu2b_ilst", rhs1, lbl_prefix = "reg1_stan | EU")
safe_etable(list(us$g, us$h, us$i, us$l, eu$g, eu$h, eu$i, eu$l),
            "reg1_us4b_eu_country2b_stan.tex")

# --- reg2 (within, log relative) -------------------------------------------
cat("\n=== reg2 STAN ===\n")
rhs2 <- paste(
    "scope1_log_rel_intensity_stan_lag:paris + scope2_log_rel_intensity_stan_lag:paris +",
    "scope1_log_rel_intensity_stan_diff_lag:paris + scope2_log_rel_intensity_stan_diff_lag:paris +",
    CONTROLS_TAIL)
us <- fit_block(data_us, "us4b_ilst", rhs2, lbl_prefix = "reg2_stan | US")
eu <- fit_block(data_eu, "eu2b_ilst", rhs2, lbl_prefix = "reg2_stan | EU")
safe_etable(list(us$g, us$h, us$i, us$l, eu$g, eu$h, eu$i, eu$l),
            "reg2_us4b_eu_country2b_stan.tex")

# --- reg3 (brown FT STAN) ---------------------------------------------------
cat("\n=== reg3 brown FT-STAN ===\n")
du <- data_us[industry_brown_class_ft_stan == "brown"]
de <- data_eu[industry_brown_class_ft_stan == "brown"]
cat(sprintf("  US rows: %d  |  EU rows: %d\n", nrow(du), nrow(de)))
us <- fit_block(du, "us4b_ilst", rhs2, lbl_prefix = "reg3brown_stan | US")
eu <- fit_block(de, "eu2b_ilst", rhs2, lbl_prefix = "reg3brown_stan | EU")
safe_etable(list(us$g, us$h, us$i, us$l, eu$g, eu$h, eu$i, eu$l),
            "reg3brown_us4b_eu_country2b_stan.tex")

# --- reg4 (non-brown FT STAN) -----------------------------------------------
cat("\n=== reg4 non-brown FT-STAN ===\n")
du <- data_us[industry_brown_class_ft_stan == "non_brown"]
de <- data_eu[industry_brown_class_ft_stan == "non_brown"]
cat(sprintf("  US rows: %d  |  EU rows: %d\n", nrow(du), nrow(de)))
us <- fit_block(du, "us4b_ilst", rhs2, lbl_prefix = "reg4nonbrown_stan | US")
eu <- fit_block(de, "eu2b_ilst", rhs2, lbl_prefix = "reg4nonbrown_stan | EU")
safe_etable(list(us$g, us$h, us$i, us$l, eu$g, eu$h, eu$i, eu$l),
            "reg4nonbrown_us4b_eu_country2b_stan.tex")

# --- reg5 (between-industry, LST FE) ---------------------------------------
cat("\n=== reg5 between STAN (LST) ===\n")
rhs5 <- paste(
    "scope1_log_intensity_industry_stan_lag:paris + scope2_log_intensity_industry_stan_lag:paris +",
    "scope1_log_intensity_industry_stan_diff_lag:paris + scope2_log_intensity_industry_stan_diff_lag:paris +",
    CONTROLS_TAIL)
us <- fit_block(data_us, "us4b_lst", rhs5, lbl_prefix = "reg5_stan | US")
eu <- fit_block(data_eu, "eu2b_lst", rhs5, lbl_prefix = "reg5_stan | EU")
safe_etable(list(us$g, us$h, us$i, us$l, eu$g, eu$h, eu$i, eu$l),
            "reg5_between_us4b_eu_country2b_stan.tex")

cat("\n=== run_new_benchmark_stan.R done ===\n")

# Known-non-converged cell, suppressed downstream by
# script/suppress_nonconv_cells.py:
#   reg3brown_us4b_eu_country2b_stan.tex col 7 — EU new_loan
check_all_converged(
    script = "run_new_benchmark_stan.R",
    expected_failures = c(
        "reg3brown_stan | EU | eu2b_ilst | new_loan"
    )
)
