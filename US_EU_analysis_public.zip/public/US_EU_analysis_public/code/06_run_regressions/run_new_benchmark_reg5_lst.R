#!/usr/bin/env Rscript
#
# run_new_benchmark_reg5_lst.R
# ---------------------------------------------------------------------------
# Between-industry regression (reg5) for the new (Jun 2026) benchmark.
#
# The reg5 regressor is the industry-level (SIC 2-digit) log emission
# intensity at fiscalyear = deal_year - 1, so it varies only at the
# (industry x year) level. Using ILST cells would absorb the regressor
# entirely (since ILST contains industry x year as a sub-structure).
# Instead, the FE block uses an LST cell -- Location x Size x Time --
# which drops the industry dimension from ILST while keeping the same
# location, size-bucket, and deal-year definitions as the main benchmark:
#
#   US LST = state   x size_bucket(4 or 2, loan-sample) x deal_year
#   EU LST = loc     x size_bucket(2,        loan-sample) x deal_year   (country)
#   EU LST robustness = nuts2 x size_bucket(4, loan-sample) x deal_year
#
# Size buckets are still constructed from unique (firm_id, deal_year - 1)
# firm-years in each loan panel, ranked within deal_year.
#
# FE: firm_id + bank_year_fe + lst, cluster ~industry_id.
# RHS (all columns from analysis_input.rds::panel_loan — see NEUTRAL_SCHEMA.md):
#   scope1_log_intensity_industry_lag       : paris
#   scope2_log_intensity_industry_lag       : paris
#   scope1_log_intensity_industry_diff_lag  : paris
#   scope2_log_intensity_industry_diff_lag  : paris
#   + ln_totalassets_lag + leverage_ratio_lag
#   + capex_totalassets_ratio_lag + ebitda_assets_ratio_lag
#
# Outputs (under output/tables/tables_vJun2026_ILSTbenchmark/):
#   reg5_between_us4b_eu_country2b.tex
#   reg5_between_us2b_eu_country2b.tex
#   reg5_between_us4b_eu_nuts2_4b_ROBUST.tex
#   reg5_between_us2b_eu_nuts2_4b_ROBUST.tex
# ---------------------------------------------------------------------------

suppressPackageStartupMessages({
    library(data.table)
    library(fixest)
})

# --- portability shim: source config + dict from replication_package root ---
suppressWarnings({
    .REPL_ROOT <- Sys.getenv("REPL_ROOT")
    if (!nzchar(.REPL_ROOT)) {
        .this <- tryCatch(normalizePath(sys.frame(1)$ofile, mustWork = FALSE),
                          error = function(e) "")
        if (nzchar(.this)) .REPL_ROOT <- normalizePath(file.path(dirname(.this), "..", ".."),
                                                       mustWork = FALSE)
    }
    if (!nzchar(.REPL_ROOT)) .REPL_ROOT <- normalizePath("../..", mustWork = FALSE)
    Sys.setenv(REPL_ROOT = .REPL_ROOT)
})
options(repl.verbose = FALSE)
source(file.path(Sys.getenv("REPL_ROOT"), "config_public.R"))
source(file.path(CODE_DIR, "06_run_regressions", "_public_loader.R"))
source(file.path(Sys.getenv("REPL_ROOT"), "code/06_run_regressions/_feglm_helpers.R"))
source(file.path(CODE_DIR, "06_run_regressions", "dict.R"))
# --- end shim ---


data_dir <- DATA_INTER
output_dir <- OUT_TABLES
if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)
cat("Writing tables to: ", output_dir, "\n", sep = "")

# ---- 1. dict from source-of-truth ------------------------------------------
cat(sprintf("Loaded dict with %d label entries\n", length(dict)))

# ---- 2. Load panel + ratios + bank_year_fe ----------------------------------
.ai <- load_analysis_input()
data_us <- .ai$data_us
data_eu <- .ai$data_eu
data_us <- add_ratios(data_us)
data_eu <- add_ratios(data_eu)

data_us[, bank_year_fe := as.factor(bank_id):as.factor(deal_year)]
data_eu[, bank_year_fe := as.factor(bank_id):as.factor(deal_year)]

# ---- 4. LST builder (NO industry dimension) --------------------------------
# Size buckets are ranked within deal_year - 1 on unique (firm_id, fyear_match)
# firm-years, identical rule to the ILST builder; only the cell label drops
# industry_id.
build_loansample_lst <- function(panel, loc_col, n_buckets, label,
                                 colname_prefix) {
    p <- copy(panel); setDT(p)
    p[, fyear_match := deal_year - 1L]
    fy <- unique(
        p[!is.na(at_rank_within_year) &
          !is.na(get(loc_col)) & get(loc_col) != "",
          .(firm_id, fyear_match,
            loc_eff = as.character(get(loc_col)), at_rank_within_year)],
        by = c("firm_id", "fyear_match")
    )
    fy[, size_bucket := as.integer(ceiling(
            at_rank_within_year * n_buckets
        )), by = fyear_match]
    fy[size_bucket > n_buckets, size_bucket := n_buckets]
    fy[size_bucket < 1L,        size_bucket := 1L]
    # Cell = location x size x time (no industry)
    fy[, lst := paste(loc_eff, size_bucket, fyear_match, sep = "_")]
    keep <- fy[, .(firm_id, fyear_match,
                   sb = size_bucket, lst_new = lst)]
    setnames(keep, c("sb","lst_new"),
             c(paste0(colname_prefix, "_size_bucket"),
               paste0(colname_prefix, "_lst")))
    p <- merge(p, keep, by = c("firm_id", "fyear_match"), all.x = TRUE)
    p[, fyear_match := NULL]
    n_with  <- sum(!is.na(p[[paste0(colname_prefix, "_lst")]]))
    n_cells <- p[!is.na(get(paste0(colname_prefix, "_lst"))),
                 uniqueN(get(paste0(colname_prefix, "_lst")))]
    cat(sprintf("  %-30s rows w/ LST: %d/%d (%.1f%%); cells: %d\n",
                label, n_with, nrow(p), 100*n_with/nrow(p), n_cells))
    p
}

data_us <- build_loansample_lst(data_us, "state_id", 4L,
                                "US state x 4 buckets", "us4b")
data_us <- build_loansample_lst(data_us, "state_id", 2L,
                                "US state x 2 buckets", "us2b")
data_eu <- build_loansample_lst(data_eu, "country_id",   2L,
                                "EU country x 2 buckets", "eu2b")
data_eu <- build_loansample_lst(data_eu, "nuts2_id", 4L,
                                "EU NUTS-2 x 4 buckets (robust)", "eunuts4b")

# ---- 5. etable writer ------------------------------------------------------
safe_etable <- function(models, file_name) {
    tryCatch({
        etable(models, dict = dict, style.tex = style.tex("aer"),
               signif.code = c("***"=0.01, "**"=0.05, "*"=0.10),
               fitstat = ~ r2 + n, digits = "r3", tex = TRUE,
               file = file.path(output_dir, file_name), replace = TRUE)
        cat(sprintf("  wrote %s\n", file_name))
    }, error = function(e) {
        # Log, then propagate so FAIL_FAST/run.sh halts (fixed 2026-11-04;
        # was previously swallowing write failures and leaving stale tables).
        cat(sprintf("  !!! etable failed for %s: %s
",
                    file_name, conditionMessage(e)))
        stop(sprintf("etable failed for %s: %s", file_name, conditionMessage(e)))
    })
}

# ---- 6. Reg5 RHS + runner --------------------------------------------------
RHS5 <- paste(
    "scope1_log_intensity_industry_lag:paris +",
    "scope2_log_intensity_industry_lag:paris +",
    "scope1_log_intensity_industry_diff_lag:paris +",
    "scope2_log_intensity_industry_diff_lag:paris +",
    "ln_totalassets_lag + leverage_ratio_lag +",
    "capex_totalassets_ratio_lag + ebitda_assets_ratio_lag")

fit_block <- function(d, lst_col) {
    fe <- sprintf("firm_id + bank_year_fe + %s", lst_col)
    list(
        g = feols(as.formula(paste0("outcome_loan_growth ~ ", RHS5, " | ", fe)),
                  data = d, cluster = ~industry_id),
        h = feols(as.formula(paste0("outcome_log_loan   ~ ", RHS5, " | ", fe)),
                  data = d, cluster = ~industry_id),
        i = feglm_safe(as.formula(paste0("outcome_new_loan     ~ ", RHS5, " | ", fe)),
                  data = d, family = binomial(link = "logit"),
                  cluster = ~industry_id),
        l = feglm_safe(as.formula(paste0("outcome_first_loan ~ ", RHS5, " | ", fe)),
                  data = d, family = binomial(link = "logit"),
                  cluster = ~industry_id)
    )
}

run_pair <- function(us_lst, eu_lst, out_file) {
    cat(sprintf("\n--- %s ---\n", out_file))
    us_models <- fit_block(data_us, us_lst)
    eu_models <- fit_block(data_eu, eu_lst)
    safe_etable(list(us_models$g, us_models$h, us_models$i, us_models$l,
                     eu_models$g, eu_models$h, eu_models$i, eu_models$l),
                out_file)
}

# ---- 7. MAIN: 2 US bucket variants x EU country-2b LST ---------------------
cat("\n=== reg5 between-industry, LST FE (main) ===\n")
run_pair("us4b_lst", "eu2b_lst",
         "reg5_between_us4b_eu_country2b.tex")
run_pair("us2b_lst", "eu2b_lst",
         "reg5_between_us2b_eu_country2b.tex")

# ---- 8. ROBUSTNESS: EU NUTS-2 x 4 buckets LST ------------------------------
cat("\n=== reg5 between-industry, LST FE (robustness: EU NUTS-2 x 4) ===\n")
run_pair("us4b_lst", "eunuts4b_lst",
         "reg5_between_us4b_eu_nuts2_4b_ROBUST.tex")
run_pair("us2b_lst", "eunuts4b_lst",
         "reg5_between_us2b_eu_nuts2_4b_ROBUST.tex")

cat("\n=== run_new_benchmark_reg5_lst.R done ===\n")

check_all_converged(script = "run_new_benchmark_reg5_lst.R")
