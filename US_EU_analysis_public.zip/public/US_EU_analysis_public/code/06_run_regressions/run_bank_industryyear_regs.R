#!/usr/bin/env Rscript
#
# run_bank_industryyear_regs.R
# ---------------------------------------------------------------------------
# Estimates the "Within-Industry Analysis: Bank-Industry Level" table
# (appendix Table A.9) on the vJun2026 debugged sample. Produces a 3-column
# table: Full Sample | US | EU.
#
# Specification (eq:within_bankind in the main draft):
#   loan_ratio_nonbrown_{bjt}
#     = beta1 * ln(EI1_{jt-1}) * PrePartis
#     + beta2 * ln(EI1_{jt-1}) * PostParis
#     + beta3 * ln(EI1_{jt-1}) * NZBA_b
#     + alpha * NZBA_b
#     + delta_t + delta_j + eps
#
#   LHS: outcome_loan_ratio_nonbrown = share of bank b's loans to industry j in
#        year t that went to the "cleanest" firms within industry j (bottom
#        25% of firm scope-1 intensity, FIXED THRESHOLD pooled within
#        industry_id across years -- see build_regression_panel.R:5g).
#   RHS: scope1_log_intensity_industry_lag  (industry j's lagged log
#        scope-1 emission intensity, computed at industry_id level).
#   FE:  industry_id + deal_year
#   Cluster: industry_id
#
# INPUT
#   data/analysis_input.rds
#     -> data_bank_industryyear         (worldwide, Table A.9 col 1)
#        data_us_bank_industryyear      (US,        Table A.9 col 2)
#        data_eu_bank_industryyear      (EU,        Table A.9 col 3)
#
# OUTPUT
#   output/tables/bank_industryyear_nonbrown_nzba_paris.tex
#     A self-contained tabular fragment matching the existing
#     slides_bhavyaa_v112025/bank_industryyear_nonbrown_nzba_paris.tex
#     layout, ready to drop into revision_main.tex Appendix A.9.
#
# NZBA
#   The current panel does not carry an NZBA membership flag (nzba_dum) --
#   see build_regression_panel.R:299-302. If the column is absent, the two
#   NZBA-related coefficients are dropped and the fragment is written with
#   the remaining Paris interactions only, and a warning is printed.
# ---------------------------------------------------------------------------

suppressPackageStartupMessages({
    library(data.table)
    library(fixest)
})

# --- portability shim: source config from replication_package root ---
suppressWarnings({
    .REPL_ROOT <- Sys.getenv("REPL_ROOT")
    if (!nzchar(.REPL_ROOT)) {
        .this <- tryCatch(normalizePath(sys.frame(1)$ofile, mustWork = FALSE),
                          error = function(e) "")
        if (nzchar(.this)) .REPL_ROOT <- normalizePath(file.path(dirname(.this), "..", ".."),
                                                       mustWork = FALSE)
    }
    if (!nzchar(.REPL_ROOT)) .REPL_ROOT <- normalizePath("../..", mustWork = FALSE)
    Sys.setenv(REPL_ROOT = .REPL_ROOT)
})
options(repl.verbose = FALSE)
source(file.path(Sys.getenv("REPL_ROOT"), "config_public.R"))
source(file.path(CODE_DIR, "06_run_regressions", "_public_loader.R"))
# --- end shim ---


# ---- paths ------------------------------------------------------------------
out_dir   <- Sys.getenv("OUT_DIR", OUT_TABLES)
out_file  <- file.path(out_dir, "bank_industryyear_nonbrown_nzba_paris.tex")
if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE)
cat("=== run_bank_industryyear_regs.R ===\n")
cat("  out:  ", out_file,  "\n\n")

# ---- load -------------------------------------------------------------------
.ai <- load_analysis_input()
biy <- .ai$panel_bank_industry_year
data_bank_industryyear    <- as.data.frame(biy[sample_region == "world"])
data_us_bank_industryyear <- as.data.frame(biy[sample_region == "US"])
data_eu_bank_industryyear <- as.data.frame(biy[sample_region == "EU"])

required_datasets <- c("data_bank_industryyear",
                       "data_us_bank_industryyear",
                       "data_eu_bank_industryyear")
missing_ds <- setdiff(required_datasets, ls())
if (length(missing_ds)) {
    stop("Panel is missing the following object(s): ",
         paste(missing_ds, collapse = ", "),
         "\nRe-run script/build_regression_panel.R with the 2026-09 patch to (re)create them.")
}

# ---- Bank-industry-year aggregates ------------------------------------------
# "Cleanest firms" = firms in the bottom 25% of scope-1 intensity WITHIN their
# own SIC 2-digit industry, using a FIXED threshold pooled across years
# (i.e., one p25 cutoff per industry_id). build_regression_panel.R Step 5g
# already computes these via the Tier-2 construction-code industry classifier (firm flag
# "nonbrown_within_industry_ft_fixed") + build_bank_industryyear():
#   loan_ratio_nonbrown_{bjt} = sum(loans to nonbrown_within_industry_ft_fixed
#                                   firms in cell) / sum(all loans in cell)
# Each sample uses its own sample-specific p25 cutoff:
#   data_bank_industryyear      : worldwide loans, worldwide within-sic p25
#   data_us_bank_industryyear   : US loans,        US within-sic p25
#   data_eu_bank_industryyear   : EU loans,        EU within-sic p25
panels_full <- list(
    full = as.data.table(data_bank_industryyear),
    us   = as.data.table(data_us_bank_industryyear),
    eu   = as.data.table(data_eu_bank_industryyear)
)
for (nm in names(panels_full)) {
    d <- panels_full[[nm]]
    cat(sprintf("  %-4s panel: %d rows  (mean outcome_loan_ratio_nonbrown = %.3f)\n",
                nm, nrow(d), mean(d$outcome_loan_ratio_nonbrown, na.rm = TRUE)))
}

# No cell-level restriction here -- every bank-industry-year cell in the
# pre-built aggregate contributes.
panels <- panels_full

# ---- Attach NZBA membership from Bhavyaa's original mapping file ------------
# Source: OneDrive/.../empirical_interestrate_pricing/data/<REMOVED: NZBA merged in exporter>
#   232 NZBA member banks with join year/month, DealScan-style names.
# We construct a TIME-VARYING nzba_dum: 1 iff the bank has joined NZBA by
# the loan's deal_year (i.e., deal_year >= join_year). Direct bank_id
# match rate against our panel: 147/232 NZBA banks (63%; includes every
# major member).
nzba_csv <- Sys.getenv("NZBA_CSV",
    "<<<REMOVED: NZBA merged in exporter>>>")
have_nzba <- FALSE
if (file.exists(nzba_csv)) {
    nzba <- fread(nzba_csv, header = FALSE, na.strings = c("NA",""))
    setnames(nzba, c("bank_id", "join_year", "join_month"))
    nzba <- nzba[!is.na(bank_id) & bank_id != "x"]
    nzba <- unique(nzba, by = "bank_id")  # de-dup any repeat rows

    attach_nzba <- function(d) {
        d <- merge(d, nzba, by = "bank_id", all.x = TRUE)
        # time-varying: bank is treated NZBA once its join year has passed
        d[, nzba_dum := as.integer(!is.na(join_year) &
                                    deal_year >= join_year)]
        d[, c("join_year","join_month") := NULL]
        d
    }
    panels <- lapply(panels, attach_nzba)
    cat(sprintf("\n  attached time-varying nzba_dum from %d NZBA banks in %s\n",
                nrow(nzba), basename(nzba_csv)))
    for (nm in names(panels)) {
        cat(sprintf("  %-4s: rows w/ nzba_dum=1: %d (%.1f%% of panel; %d unique banks)\n",
                    nm,
                    sum(panels[[nm]]$nzba_dum == 1, na.rm = TRUE),
                    100*mean(panels[[nm]]$nzba_dum == 1, na.rm = TRUE),
                    uniqueN(panels[[nm]][nzba_dum == 1, bank_id])))
    }
    have_nzba <- TRUE
} else {
    warning("NZBA CSV not found at ", nzba_csv,
            "\n  Falling back to Paris-only version of eq:within_bankind.")
}

# ---- estimation -------------------------------------------------------------
# Build paris_pre / paris_post from `paris` (a factor "0"/"1"). Interactions
# use the standard fixest ":" so coefficient names are stable across panels.
fit_one <- function(d) {
    d <- copy(d)
    d[, paris_pre  := as.integer(as.character(paris) == "0")]
    d[, paris_post := as.integer(as.character(paris) == "1")]

    if (have_nzba) {
        fml <- outcome_loan_ratio_nonbrown ~
            nzba_dum +
            paris_pre  : scope1_log_intensity_industry_lag +
            paris_post : scope1_log_intensity_industry_lag +
            scope1_log_intensity_industry_lag : nzba_dum |
            industry_id + deal_year
    } else {
        fml <- outcome_loan_ratio_nonbrown ~
            paris_pre  : scope1_log_intensity_industry_lag +
            paris_post : scope1_log_intensity_industry_lag |
            industry_id + deal_year
    }
    feols(fml, data = d, cluster = ~industry_id)
}

fits <- lapply(panels, fit_one)
for (nm in names(fits)) {
    cat(sprintf("\n--- %s ---\n", toupper(nm)))
    print(summary(fits[[nm]]))
}

# ---- LaTeX fragment ---------------------------------------------------------
# Same layout as slides_bhavyaa_v112025/bank_industryyear_nonbrown_nzba_paris.tex.
stars <- function(p) {
    if (is.na(p)) return("")
    if (p < 0.001) return("$^{***}$")
    if (p < 0.01)  return("$^{**}$")
    if (p < 0.05)  return("$^{*}$")
    ""
}
fmt_coef <- function(b, p) sprintf("%.3f%s", b, stars(p))
fmt_se   <- function(s)    sprintf("(%.3f)", s)

# Extract cluster-robust (b, se, p) for a term name; if the term contains
# a ":" try both orderings, because fixest sometimes reorders the two
# operands (observed here: Pre-Paris kept as `paris_pre:ln_...` but
# Post-Paris flipped to `ln_...:paris_post` in the same fit).
get_row <- function(fit, term) {
    ct <- coeftable(fit)  # already cluster-robust when clustered fit
    candidates <- term
    if (grepl(":", term, fixed = TRUE)) {
        parts <- strsplit(term, ":", fixed = TRUE)[[1]]
        if (length(parts) == 2L)
            candidates <- c(term, paste(rev(parts), collapse = ":"))
    }
    hit <- intersect(candidates, rownames(ct))
    if (length(hit) == 0L) return(list(b = NA_real_, se = NA_real_, p = NA_real_))
    list(b  = ct[hit[1], "Estimate"],
         se = ct[hit[1], "Std. Error"],
         p  = ct[hit[1], "Pr(>|t|)"])
}

# The interaction term names fixest emits for a formula like
# `paris_pre : scope1_log_intensity_industry_lag` are
# "paris_pre:scope1_log_intensity_industry_lag" -- fixest doesn't reorder
# names because both are numeric. If a term goes missing, get_row() returns
# NAs and the cell prints as "---".
if (have_nzba) {
    rows <- list(
        list(label = "NZBA",
             term  = "nzba_dum"),
        list(label = "Pre-Paris $\\times$ Log (Industry Intensity)$_{t-1} (Scope 1)$",
             term  = "paris_pre:scope1_log_intensity_industry_lag"),
        list(label = "Post-Paris $\\times$ Log (Industry Intensity)$_{t-1} (Scope 1)$",
             term  = "paris_post:scope1_log_intensity_industry_lag"),
        list(label = "Log (Industry Intensity)$_{t-1} (Scope 1)$ $\\times$ NZBA",
             term  = "scope1_log_intensity_industry_lag:nzba_dum")
    )
} else {
    rows <- list(
        list(label = "Pre-Paris $\\times$ Log (Industry Intensity)$_{t-1} (Scope 1)$",
             term  = "paris_pre:scope1_log_intensity_industry_lag"),
        list(label = "Post-Paris $\\times$ Log (Industry Intensity)$_{t-1} (Scope 1)$",
             term  = "paris_post:scope1_log_intensity_industry_lag")
    )
}

fmt_cell <- function(fit, term) {
    r <- get_row(fit, term)
    if (is.na(r$b)) list(coef = "---", se = "") else
        list(coef = fmt_coef(r$b, r$p), se = fmt_se(r$se))
}

lines <- character(0)
lines <- c(lines,
    "",
    "\\begingroup",
    "\\centering",
    "\\begin{tabular}{lccc}",
    "   \\toprule",
    "    & \\multicolumn{3}{c}{Ratio of loans to cleanest firms within industries}\\\\",
    "                              & Full Sample           & US           & EU\\\\",
    "   \\midrule "
)

col_order <- c("full", "us", "eu")
for (r in rows) {
    coefs <- sapply(col_order, function(nm) fmt_cell(fits[[nm]], r$term)$coef)
    ses   <- sapply(col_order, function(nm) fmt_cell(fits[[nm]], r$term)$se)
    lines <- c(lines,
        sprintf("   %-63s & %-13s & %-13s & %-13s\\\\",
                r$label, coefs[1], coefs[2], coefs[3]),
        sprintf("   %-63s & %-13s & %-13s & %-13s\\\\",
                "", ses[1], ses[2], ses[3])
    )
}

# Fit stats row + FE row
r2s  <- sapply(col_order, function(nm) sprintf("%.2f", fitstat(fits[[nm]], "r2", verbose = FALSE)$r2))
nobs <- sapply(col_order, function(nm) formatC(nobs(fits[[nm]]), format = "d", big.mark = ","))

lines <- c(lines,
    "    \\\\",
    sprintf("   %-63s & %-13s & %-13s & %-13s\\\\",
            "R$^2$", r2s[1], r2s[2], r2s[3]),
    sprintf("   %-63s & %-13s & %-13s & %-13s\\\\",
            "Observations", nobs[1], nobs[2], nobs[3]),
    "    \\\\",
    "   deal\\_year fixed effects                                        & $\\checkmark$  & $\\checkmark$  & $\\checkmark$\\\\",
    "   Industry fixed effects                                          & $\\checkmark$  & $\\checkmark$  & $\\checkmark$\\\\",
    "   \\bottomrule",
    "\\end{tabular}",
    "\\par\\endgroup",
    ""
)

writeLines(lines, out_file)
cat(sprintf("\nWrote %s\n", out_file))

if (!have_nzba) {
    cat("\nNOTE: NZBA was not available in the panel; the fragment above\n",
        "     shows the Paris-only variant. To include NZBA rows,\n",
        "     merge nzba_dum into the loan panel upstream.\n", sep = "")
}
