#!/usr/bin/env Rscript
#
# run_new_benchmark_thresholds.R
# ---------------------------------------------------------------------------
# Threshold robustness for the new ILST benchmark (Jun 2026 spec).
# Re-runs reg3 (brown) and reg4 (non-brown) under three alternative
# brown/non-brown classification rules — drawn verbatim from the EERrev
# script — with the new ILST FE block.
#
# Threshold variants (subset-filter column in the panel):
#   TV       — time-varying threshold, top 25%
#              `industry_brown_class_tv`           == "brown"         / "non_brown"
#   FT_P90   — fixed threshold, top 10%
#              `industry_brown_class_ft_p90`    == "brown" / "non_brown"
#   TV_P90   — time-varying threshold, top 10%
#              `industry_brown_class_p90`       == "brown"  / "non_brown"
#
# FE (unchanged from new benchmark): firm_id + bank_year_fe + ilst,
# cluster ~industry_id. US ILST = state x 4 size quartiles x deal_year.
# EU ILST = country (loc) x 2 size buckets x deal_year. Size buckets
# ranked within deal_year from unique (firm_id, deal_year-1) firm-years
# in each loan panel.
#
# Output suffix follows the existing convention (`_tv`, `_ft_p90`, `_p90`)
# composed with the cell suffix (`_us4b_eu_country2b`):
#   reg{3brown,4nonbrown}_us4b_eu_country2b_{tv,ft_p90,p90}.tex
#
# Only US-4b is produced (per user request, 2025-06-24).
# ---------------------------------------------------------------------------

suppressPackageStartupMessages({
    library(data.table)
    library(fixest)
})

# --- portability shim: source config + dict from replication_package root ---
suppressWarnings({
    .REPL_ROOT <- Sys.getenv("REPL_ROOT")
    if (!nzchar(.REPL_ROOT)) {
        .this <- tryCatch(normalizePath(sys.frame(1)$ofile, mustWork = FALSE),
                          error = function(e) "")
        if (nzchar(.this)) .REPL_ROOT <- normalizePath(file.path(dirname(.this), "..", ".."),
                                                       mustWork = FALSE)
    }
    if (!nzchar(.REPL_ROOT)) .REPL_ROOT <- normalizePath("../..", mustWork = FALSE)
    Sys.setenv(REPL_ROOT = .REPL_ROOT)
})
options(repl.verbose = FALSE)
source(file.path(Sys.getenv("REPL_ROOT"), "config_public.R"))
source(file.path(CODE_DIR, "06_run_regressions", "_public_loader.R"))
source(file.path(Sys.getenv("REPL_ROOT"), "code/06_run_regressions/_feglm_helpers.R"))
source(file.path(CODE_DIR, "06_run_regressions", "dict.R"))
# --- end shim ---


data_dir <- DATA_INTER
output_dir <- OUT_TABLES
if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)
cat("Writing tables to: ", output_dir, "\n", sep = "")

# ---- 1. dict from source-of-truth ------------------------------------------
cat(sprintf("Loaded dict with %d label entries\n", length(dict)))

# ---- 2. Load panel + ratios + bank_year_fe ----------------------------------
.ai <- load_analysis_input()
data_us <- .ai$data_us
data_eu <- .ai$data_eu
data_us <- add_ratios(data_us)
data_eu <- add_ratios(data_eu)

data_us[, bank_year_fe := as.factor(bank_id):as.factor(deal_year)]
data_eu[, bank_year_fe := as.factor(bank_id):as.factor(deal_year)]

# ---- 3. Sanity-check threshold columns are present -------------------------
required_cols <- c("industry_brown_class_tv",        # TV
                   "industry_brown_class_ft_p90", # FT x p90
                   "industry_brown_class_p90")    # TV x p90
for (col in required_cols) {
    for (panel_name in c("data_us","data_eu")) {
        d <- get(panel_name)
        if (!col %in% names(d)) {
            stop(sprintf("Threshold column `%s` missing from %s", col, panel_name))
        }
    }
}
cat("All threshold columns present in both panels.\n")

# Print coverage for each threshold to confirm we have firms to filter on
for (col in required_cols) {
    cat(sprintf("  %s\n", col))
    for (panel_name in c("data_us","data_eu")) {
        d <- get(panel_name)
        cat(sprintf("    %s: %s\n", panel_name,
                    paste(names(table(d[[col]], useNA = "ifany")),
                          unname(table(d[[col]], useNA = "ifany")),
                          sep = "=", collapse = ", ")))
    }
}

# ---- 4. ILST builder (same as run_new_benchmark_ilst.R) --------------------
data_us <- build_loansample_ilst(data_us, loc_col = "state_id", n_buckets = 4L,
                                 label = "US state x 4 buckets",
                                 colname_prefix = "us4b")
data_eu <- build_loansample_ilst(data_eu, loc_col = "country_id",   n_buckets = 2L,
                                 label = "EU country x 2 buckets",
                                 colname_prefix = "eu2b")

# ---- 5. etable writer ------------------------------------------------------
# Forwards to etable_safe() in _feglm_helpers.R, which also captures
# the "VCOV matrix is not positive definite" warnings fixest emits
# lazily during table assembly (per-fit capture inside feglm_safe
# does not see them).
safe_etable <- function(models, file_name) {
    etable_safe(models, file_name, output_dir = output_dir, dict = dict)
}

# ---- 6. Reg runners --------------------------------------------------------
RHS_REL <- paste(
    "scope1_log_rel_intensity_lag:paris +",
    "scope2_log_rel_intensity_lag:paris +",
    "scope1_log_rel_intensity_diff_lag:paris +",
    "scope2_log_rel_intensity_diff_lag:paris +",
    "ln_totalassets_lag + leverage_ratio_lag +",
    "capex_totalassets_ratio_lag + ebitda_assets_ratio_lag")

fit_block <- function(d, ilst_col, lbl_prefix = NA_character_) {
    fe <- sprintf("firm_id + bank_year_fe + %s", ilst_col)
    mk_lbl <- function(outcome) {
        if (is.na(lbl_prefix)) NA_character_
        else sprintf("%s | %s | %s", lbl_prefix, ilst_col, outcome)
    }
    list(
        g = feols(as.formula(paste0("outcome_loan_growth ~ ", RHS_REL, " | ", fe)),
                  data = d, cluster = ~industry_id),
        h = feols(as.formula(paste0("outcome_log_loan   ~ ", RHS_REL, " | ", fe)),
                  data = d, cluster = ~industry_id),
        i = feglm_safe(as.formula(paste0("outcome_new_loan     ~ ", RHS_REL, " | ", fe)),
                  data = d, family = binomial(link = "logit"),
                  cluster = ~industry_id,
                  .label = mk_lbl("new_loan")),
        l = feglm_safe(as.formula(paste0("outcome_first_loan ~ ", RHS_REL, " | ", fe)),
                  data = d, family = binomial(link = "logit"),
                  cluster = ~industry_id,
                  .label = mk_lbl("first_loan"))
    )
}

run_subset <- function(filter_col, brown_label, nonbrown_label, sfx_threshold) {
    cat(sprintf("\n=== Threshold variant: %s ===\n", sfx_threshold))

    # reg3 — brown
    cat(sprintf("  -- reg3 (brown: %s == %s) --\n", filter_col, brown_label))
    du <- data_us[get(filter_col) == brown_label]
    de <- data_eu[get(filter_col) == brown_label]
    cat(sprintf("     US rows: %d  |  EU rows: %d\n", nrow(du), nrow(de)))
    reg3_stem <- sprintf("reg3brown_us4b_eu_country2b_%s", sfx_threshold)
    us_mods <- fit_block(du, "us4b_ilst",
                         lbl_prefix = sprintf("%s | US", reg3_stem))
    eu_mods <- fit_block(de, "eu2b_ilst",
                         lbl_prefix = sprintf("%s | EU", reg3_stem))
    safe_etable(list(us_mods$g, us_mods$h, us_mods$i, us_mods$l,
                     eu_mods$g, eu_mods$h, eu_mods$i, eu_mods$l),
                paste0(reg3_stem, ".tex"))

    # reg4 — non-brown
    cat(sprintf("  -- reg4 (non-brown: %s == %s) --\n", filter_col, nonbrown_label))
    du <- data_us[get(filter_col) == nonbrown_label]
    de <- data_eu[get(filter_col) == nonbrown_label]
    cat(sprintf("     US rows: %d  |  EU rows: %d\n", nrow(du), nrow(de)))
    reg4_stem <- sprintf("reg4nonbrown_us4b_eu_country2b_%s", sfx_threshold)
    us_mods <- fit_block(du, "us4b_ilst",
                         lbl_prefix = sprintf("%s | US", reg4_stem))
    eu_mods <- fit_block(de, "eu2b_ilst",
                         lbl_prefix = sprintf("%s | EU", reg4_stem))
    safe_etable(list(us_mods$g, us_mods$h, us_mods$i, us_mods$l,
                     eu_mods$g, eu_mods$h, eu_mods$i, eu_mods$l),
                paste0(reg4_stem, ".tex"))
}

# ---- 7. Execute three threshold variants -----------------------------------
run_subset("industry_brown_class_tv",
           "brown",        "non_brown",        "tv")
run_subset("industry_brown_class_ft_p90",
           "brown", "non_brown", "ft_p90")
run_subset("industry_brown_class_p90",
           "brown",    "non_brown",    "p90")

cat("\n=== run_new_benchmark_thresholds.R done ===\n")

# Known VCOV-non-PD cells, pinned down in the Nov 2 full-stage-06 rerun
# (chol()-based check in feglm_safe). Downstream,
# script/suppress_nonconv_cells.py keeps the reported coefficients and
# SEs and attaches the "did not converge" footnote.
#
# All 7 affected cells are brown-industry logits in the ft_p90 and p90
# threshold variants — small subsamples where the cluster-robust VCOV
# needed numerical patching to pass the chol() PD test.
check_all_converged(
    script = "run_new_benchmark_thresholds.R",
    expected_failures = c(
        "reg3brown_us4b_eu_country2b_ft_p90 | US | us4b_ilst | new_loan",
        "reg3brown_us4b_eu_country2b_ft_p90 | US | us4b_ilst | first_loan",
        "reg3brown_us4b_eu_country2b_ft_p90 | EU | eu2b_ilst | new_loan",
        "reg3brown_us4b_eu_country2b_ft_p90 | EU | eu2b_ilst | first_loan",
        "reg3brown_us4b_eu_country2b_p90 | US | us4b_ilst | first_loan",
        "reg3brown_us4b_eu_country2b_p90 | EU | eu2b_ilst | new_loan",
        "reg3brown_us4b_eu_country2b_p90 | EU | eu2b_ilst | first_loan"
    )
)
