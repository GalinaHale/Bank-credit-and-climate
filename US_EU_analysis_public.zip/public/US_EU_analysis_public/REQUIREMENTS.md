# Requirements — public replication tier

## R

Tested with R 4.5.2.

Required CRAN packages:

| Package | Minimum | Notes |
|---|---|---|
| `data.table` | ≥ 1.15 | fast panel manipulation |
| `fixest` | ≥ 0.12 | fixed-effects estimation (`feols`, `feglm`, `etable`) |
| `digest` | any | optional; used only by the WILDBS provenance check in Stage 07 (`WILDBS_PANEL_SHA`). The default `run_all.sh` path consumes the shipped bootstrap CSV and does not call it. |

Install:

```r
install.packages(c("data.table", "fixest"))
install.packages("digest")  # optional
```

No other CRAN packages are used. Earlier revisions of this package referenced `fwildclusterboot` (an alternative WCR implementation never adopted) and `fmt` (never imported); both have been removed.

## Python

Tested with Python 3.10 and 3.11.

Stage-08 Python builders use **only the Python standard library** (`os`, `re`, `pathlib`, `csv`, `sys`, `argparse`, `collections`). No third-party packages are required.

The `requirements.txt` at the repo root exists for environments that still want a canonical pip install hook; it may be empty on a clean deploy.

## System

- ≥ 16 GB RAM (fixest on the ~163K-row panel with the ILST FE block has a transient ~8 GB footprint).
- Any POSIX shell for `run_all.sh`, `verify_clean_run.sh`, and the per-stage `run.sh` scripts.
- LaTeX distribution with `booktabs`, `graphicx`, `siunitx` for compiling tables alongside the manuscript. The public tier does not compile LaTeX itself; it emits `.tex` fragments that drop into the manuscript.

## Wall-clock expectation

On a modern workstation (16 GB RAM, single-threaded R):

| Stage | Time | Notes |
|---|---|---|
| 06 — all benchmark + robustness regression tables | ~45 min | 10 R runners; the age runner alone can take ~1h on tough logit cells. |
| 07 — wild cluster bootstrap p-values | ~5 seconds | Reads `code/07_wild_bootstrap/results_csv/wildbs_pvalues_B500.csv` (shipped B = 500). To **rebuild** p-values from scratch, run `WILDBS_B=500 WILDBS_NCORES=16 bash code/07_wild_bootstrap/run.sh --run-server` — that is a ~6-day job on 16 cores and lives entirely in the server path. |
| 08 — table + figure assembly | ~2 min | Pure Python standard-library scripts. |

Total for a cold run against a fresh `analysis_input.rds`, using the shipped bootstrap p-values: on the order of 45 min — 1 h. The B = 500 wild-cluster bootstrap CSV is the only pre-computed intermediate shipped; everything else is regenerated.
