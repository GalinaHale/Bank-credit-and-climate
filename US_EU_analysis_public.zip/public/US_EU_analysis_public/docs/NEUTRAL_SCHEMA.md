# Neutral analysis schema — `analysis_input.rds`

This document defines the data contract the public analysis code consumes. It is strictly a specification: every column has a type, a meaning, and a role in the models. No column exposes a source-vendor field code or entity identifier. The map from vendor fields to this schema lives only in the licensed construction-code package (available on request; see `DATA_AVAILABILITY.md`) and is not distributed with this public tier.

## File layout

`analysis_input.rds` holds a named list with two data.frames:

```r
list(
    panel_loan               = data.frame(...),   # loan-level panel for reg1–5
    panel_bank_industry_year = data.frame(...)    # bank × industry × year aggregate for Table A.9
)
```

The scope-2-on-scope-1 diagnostic runs on `panel_loan` directly — the FE structure `firm_id + industry_id:deal_year` (US) or `+ country_id` (EU) collapses it to firm-year.

## Identifier conventions

Every identifier is an opaque sequential integer. The numbering is deterministic given the restricted panel, but the integer values themselves carry no information about the referenced entity.

| Column | Type | Domain | Meaning |
|---|---|---|---|
| `firm_id` | integer | `1..N_firm` | Borrower. Used as borrower FE. |
| `bank_id` | integer | `1..N_bank` | Lead-arranger bank. `bank_id` in `panel_bank_industry_year` lives in its own keyspace and does NOT cross-reference `bank_id` in `panel_loan` (the two panels are aggregated on different granularities in the construction pipeline). |
| `industry_id` | integer | `1..N_industry` | Industry grouping. Also the standard-error cluster. |
| `country_id` | integer | `1..N_country` | Country of borrower HQ. |
| `state_id` | integer | `1..N_state_us` or `NA` | US state (US rows only; `NA` elsewhere). |
| `nuts2_id` | integer | `1..N_nuts2` or `NA` | NUTS-2 region (EU rows, where matched). |
| `deal_year` | integer | `2000..2024` | Loan-origination year. |
| `sample_region` | character | `"US"` / `"EU"` / `"world"` | Panel side. Public code filters on this instead of reading a split file. |

## `panel_loan` columns

### Outcomes

| Column | Type | Notes |
|---|---|---|
| `outcome_loan_growth` | numeric | Per-lender loan-amount growth. |
| `outcome_log_loan` | numeric | Log per-lender loan amount. |
| `outcome_new_loan` | integer {0,1} | New-loan dummy. |
| `outcome_first_loan` | integer {0,1} | First-loan dummy. |

### Firm-level emission-intensity regressors (headline)

Four main variants per scope, lagged and first-differenced:

| Column | Type |
|---|---|
| `scope1_log_intensity_lag`, `scope1_log_intensity_diff_lag` | numeric |
| `scope2_log_intensity_lag`, `scope2_log_intensity_diff_lag` | numeric |
| `scope1_log_rel_intensity_lag`, `scope1_log_rel_intensity_diff_lag` | numeric |
| `scope2_log_rel_intensity_lag`, `scope2_log_rel_intensity_diff_lag` | numeric |

### Industry-level emission-intensity regressors (reg5 between)

Industry-level log emission intensity, built at the (industry × year) level
and then merged onto each loan row for the between-industry regression
(reg5). Because the regressor is industry-level, the reg5 FE block is
additive (industry + year, no `industry × year` interaction) so the
regressor is not absorbed. See `code/06_run_regressions/run_new_benchmark_reg5_lst.R`.

| Column | Type |
|---|---|
| `scope1_log_intensity_industry_lag`, `scope1_log_intensity_industry_diff_lag` | numeric |
| `scope2_log_intensity_industry_lag`, `scope2_log_intensity_industry_diff_lag` | numeric |

### Scope 1+2 sum variants (robustness)

| Column | Type |
|---|---|
| `scope12_log_intensity_lag`, `scope12_log_intensity_diff_lag` | numeric |
| `scope12_log_rel_intensity_lag`, `scope12_log_rel_intensity_diff_lag` | numeric |

### STAN-deflated variants (robustness)

Mirror of the base intensity family computed on a denominator that is deflated with the **OECD STAN value-added producer deflator** rather than the baseline **World Bank GDP deflator**. Both deflator series are public (see `DATA_AVAILABILITY.md` → "Ancillary public inputs") and enter upstream in the licensed panel build (`build_regression_panel.R` + `add_stan_intensity_to_*.R`); only the resulting `_stan`-suffixed columns are carried into this neutral schema. The `run_new_benchmark_stan.R` runner consumes these columns to produce the STAN-robustness tables.

| Column | Type |
|---|---|
| `scope1_log_intensity_stan_lag`, `scope1_log_intensity_stan_diff_lag` | numeric |
| `scope2_log_intensity_stan_lag`, `scope2_log_intensity_stan_diff_lag` | numeric |
| `scope1_log_rel_intensity_stan_lag`, `scope1_log_rel_intensity_stan_diff_lag` | numeric |
| `scope2_log_rel_intensity_stan_lag`, `scope2_log_rel_intensity_stan_diff_lag` | numeric |
| `scope1_log_intensity_industry_stan_lag`, `scope1_log_intensity_industry_stan_diff_lag` | numeric |
| `scope2_log_intensity_industry_stan_lag`, `scope2_log_intensity_industry_stan_diff_lag` | numeric |

### Paris indicator

| Column | Type | Domain | Notes |
|---|---|---|---|
| `paris` | **factor** | `"0"` / `"1"` | **Must be factor.** The RHS `x:paris` produces two interactions (`x:paris0` pre-Paris, `x:paris1` post-Paris). Collapsing to integer would produce a single coefficient and change the specification of every reg1–5 table. |
| `paris_pre` | integer {0,1} | | Pre-Paris indicator. Used by the WILDBS runner. |
| `paris_post` | integer {0,1} | | Post-Paris indicator. Used by the WILDBS runner. |

### Firm-level controls (pre-baked ratios)

| Column | Type | Notes |
|---|---|---|
| `ln_totalassets_lag` | numeric | Log total assets, lagged. |
| `leverage_ratio_lag` | numeric | Pre-baked leverage ratio, lagged. |
| `capex_totalassets_ratio_lag` | numeric | Pre-baked CAPEX/assets ratio, lagged. |
| `ebitda_assets_ratio_lag` | numeric | Pre-baked EBITDA/assets ratio, lagged. |

### Firm age (robustness)

| Column | Type |
|---|---|
| `firm_age_lag` | numeric |
| `firm_age_gt10` | integer {0,1} |
| `firm_age_above_pooled_median` | integer {0,1} |
| `firm_age_nonmissing` | integer {0,1} |

### Size-bucket rank (for ILST / LST cell construction in public code)

| Column | Type | Domain | Notes |
|---|---|---|---|
| `at_rank_within_year` | numeric | `(0, 1]` | Anonymized within-year total-assets quantile position over unique firm-year rows. Public ILST / LST builders compute `size_bucket = ceiling(at_rank_within_year * n_buckets)`. |

### Industry brown / non-brown classifications (subset filters)

| Column | Type | Values |
|---|---|---|
| `industry_brown_class_ft` | character | `"brown"`, `"non_brown"`, `NA` |
| `industry_brown_class_p90` | character | same |
| `industry_brown_class_ft_p90` | character | same |
| `industry_brown_class_ft_stan` | character | same |
| `industry_brown_class_tv` | character | same |

### Scope-2-on-scope-1 diagnostic (on `panel_loan`)

| Column | Type |
|---|---|
| `firm_scope1_intensity_sales` | numeric |
| `firm_scope2_intensity_sales` | numeric |

## `panel_bank_industry_year` columns (Table A.9)

Keys: `bank_id`, `industry_id`, `deal_year`, `sample_region ∈ {"world", "US", "EU"}`.

| Column | Type | Notes |
|---|---|---|
| `outcome_loan_ratio_nonbrown` | numeric | Share of lead-bank $b$'s loans to industry $j$ in year $t$ allocated to the cleanest firms within industry $j$. |
| `scope1_log_intensity_industry_lag` | numeric | Lagged industry-level log scope-1 intensity. |
| `paris` | factor | Same as `panel_loan`; see note above. |
| `paris_pre`, `paris_post` | integer {0,1} | |
| `nzba_dum` | integer {0,1} | NZBA bank-year indicator, where available. |

## Not exposed

The following are present in the restricted panel the Tier-2 exporter consumes, but are not in `analysis_input.rds`:

- Raw-vendor firm and lender identifiers and names.
- Raw-vendor industry classifications and geographic codes.
- Raw Compustat sub-fields that go into the pre-baked ratios.
- Deal dates, maturities, and purposes.
- Any crosswalk values.

The scanner at `../scan_public_disclosure.sh` enforces this by refusing any deposit whose files mention a source-vendor identifier or field code.

## Changelog

- **2026-11-13.** Initial version. Loose anonymized-ID variant.
- **2026-11-13 (audit fix).** Explicit source-field mappings removed from this document; they live only in the Tier-2 construction-code package (`SOURCE_TO_NEUTRAL_MAPPING.md`). `paris` clarified as factor (prior version was ambiguous about its type).
- **2026-11-19 (audit fix).** Added "Industry-level emission-intensity regressors" section to `panel_loan` for the four industry-level scope-1/scope-2 (level + diff) columns reg5 consumes; the Tier-2 exporter was updated in the same pass to produce them under these names (previously only the STAN-deflated variants were in the exporter's colmap, which left reg5 reaching for legacy raw names).
