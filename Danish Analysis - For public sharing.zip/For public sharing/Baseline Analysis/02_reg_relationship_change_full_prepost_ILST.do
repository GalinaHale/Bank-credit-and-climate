********************************************************************************
* Relationship entry/exit regressions: balanced full sample
* run "${do}Baseline Analysis/02_reg_relationship_change_full_prepost_ILST.do"

********************************************************************************
* run "${do}Baseline Analysis/02_reg_relationship_change_full_prepost_ILST.do"
/*
INPUT:
    ${data}balanced_firm_credit_full_covfix.dta
    ${temp}kene_ma_file.dta
    ${temp}relative_ei
    ${temp}incumbent.dta
    ${temp}new_entrants.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}within_industry_analysis_relations_balanced_all_prepost_ilst_covfix.txt
        -> Appendix Table B.17: 

LOG:
    ${logs}use_data_regs_relationship_full_prepost_ILST_covfix.log

DEPENDENCIES / NOTES:
    Requires baseline, 02a and 02b above. Reads the covfix balanced file.
*/


capture log close
log using ${logs}use_data_regs_relationship_full_prepost_ILST_covfix.log, replace
set scheme lean1


global cntrl1_l "L.lassets  L.fixed_ratio L.leverage_ratio   L.roa" 
global cntrl1 "lassets  fixed_ratio leverage_ratio   roa" 


use ${data}balanced_firm_credit_full_covfix.dta, replace


sort cvrnr cvrnr_b year
distinct cvrnr cvrnr_b year



**********************further data cleaning before regression***********************
**generate dummy bank_id for NEVER firms
destring cvrnr, gen(firmid)


replace bankid =0 if missing(bankid)


***generate firm bank id
capture drop id
egen id = group(firmid  bankid)
format id %19.9g
distinct id  


***generate bank year fixed dummies
capture drop bank_year 
egen bank_year = group(bankid year)
format bank_year %19.9g
distinct bank_year

****construct industry fixed dummies 
replace ind2 =0 if missing(ind2)
capture drop ind2year 
egen ind2year= group(ind2 year)
format   ind2year %19.9g



isid id year
bysort id (year): assert year == year[_n-1] + 1 if _n > 1
sort id year

***construct entry and exit(1 for entering a first time relations with a bank) and exit dummy
capture drop entry 
gen entry = .
bysort id (year): replace entry = 1 if account_balance[_n-1] ==. & account_balance[_n] != .  & account_balance[_n+1] != . & ever_rel ==1 & year>2003
replace entry =0 if entry  == .
tab entry 
tab entry year


capture drop exit
gen exit = .
bysort id (year): replace exit = 1 if account_balance[_n-1] != .  &  account_balance[_n] != .  &  account_balance[_n+1] == . & ever_rel ==1 & year<2019
replace exit =0 if exit == .
tab exit
tab exit year

* Apply the original size rule only after constructing entry and exit.
**keep if firm size is at least 2 to remove self-employed
keep if f_size >=2



sort id year


************generate loan outcome vars*********

**fill in zeros and compute log(balance) as l_balance
**fill in zeros 
capture drop nonmissing_balance 
gen nonmissing_balance = account_balance
replace nonmissing_balance=0 if missing(account_balance)
**log of account balance as l_balance
capture drop l_balance 
gen l_balance= 0
replace l_balance= log(nonmissing_balance) if  nonmissing_balance>0



**log change as growth in 100%
sort firmid bankid year
xtset id year
capture drop l_loan_change
gen l_loan_change = l_balance-l.l_balance  
replace l_loan_change=l_loan_change*100



***alternative definitions: gen loan growth using symmetric growth by taking into account 0
capture drop loan_change
gen loan_change = nonmissing_balance-l.nonmissing_balance

capture drop loan_growth
gen loan_growth = loan_change/(0.5*nonmissing_balance+0.5*l.nonmissing_balance)*100




***generate extensive margin variables
capture drop ext_l_loan 
gen ext_l_loan = 0
replace ext_l_loan =1 if loan_change>0 & loan_change !=.
tab ext_l_loan 


***fill in zeros for missing vars of loan outcomes
foreach i of varlist  l_balance loan_growth ext_l_loan l_loan_change{
	replace  `i' =0 if missing(`i') 
}




*****merge to obtain energy intensity variables
capture drop  kene 
capture drop kene_m3 
capture drop energy_intensity_1 
capture drop lenergy_intensity_1 
capture drop change_ei
capture drop post_paris_lenergy_intensity_1
capture drop pre_paris_lenergy_intensity_1
capture drop pre_paris_change_ei
capture drop post_paris_change_ei

merge m:1 firmid year using ${temp}kene_ma_file.dta
capture drop _merge



****merge to obtain relative energy intensity variables**********

capture drop  post_relative_ei_indyear
capture drop  pre_relative_ei_indyear

capture drop change_relative_ei_indyear
capture drop pre_change_relative_ei_indyear
capture drop post_change_relative_ei_indyear

merge m:1 firmid year using ${temp}relative_ei
capture drop _merge




tsset id year

****tssset the data
capture program drop meany
program def meany, rclass
args var spec
sum `var' if e(sample), mean
estadd scalar Meany=r(mean)
end

tsset id year


***baseline ilst: industry(naces2)*location(nuts2)*size(5)*year
capture drop size_q
xtile size_q =lassets, nq(5)

capture drop ILST
egen ILST = group(ind2 jur_bel_region_kode size_q year)



***********************Appendix TABLE B.17***********************************
*****all firms, linear specification, relation changes
***replace missing vars as 0
foreach var in entry exit{
	replace `var' = 0 if `var'==.
}


reghdfe entry   pre_relative_ei_indyear  pre_change_relative_ei_indyear  post_relative_ei_indyear   post_change_relative_ei_indyear lassets  fixed_ratio leverage_ratio   roa,   absorb(cvrnr  bank_year ILST)  cluster(ind2)
estimates store model1
meany entry    model1



reghdfe exit   pre_relative_ei_indyear  pre_change_relative_ei_indyear  post_relative_ei_indyear   post_change_relative_ei_indyear lassets  fixed_ratio leverage_ratio   roa,   absorb(cvrnr  bank_year ILST)  cluster(ind2)
estimates store model2
meany exit    model2



****merge to incumbent and entrant firms
capture drop _merge
capture drop incumbent

merge m:1 cvrnr year using  ${temp}incumbent.dta
drop if _merge ==2



capture drop _merge
capture drop new_entrants
 
merge m:1 cvrnr year using ${temp}new_entrants.dta
drop if _merge ==2



****incumbent firms
reghdfe entry   pre_relative_ei_indyear  pre_change_relative_ei_indyear  post_relative_ei_indyear   post_change_relative_ei_indyear lassets  fixed_ratio leverage_ratio   roa if incumbent==1,   absorb(cvrnr  bank_year ILST)  cluster(ind2)
estimates store model3
meany entry    model3



reghdfe exit   pre_relative_ei_indyear  pre_change_relative_ei_indyear  post_relative_ei_indyear   post_change_relative_ei_indyear  lassets  fixed_ratio leverage_ratio   roa if incumbent==1,  absorb(cvrnr  bank_year ILST)  cluster(ind2)
estimates store model4
meany exit    model4


****new_entrants
reghdfe entry   pre_relative_ei_indyear  pre_change_relative_ei_indyear  post_relative_ei_indyear   post_change_relative_ei_indyear lassets  fixed_ratio leverage_ratio   roa if new_entrants==1,   absorb(cvrnr  bank_year ILST)  cluster(ind2)
estimates store model5
meany entry    model5



reghdfe exit   pre_relative_ei_indyear  pre_change_relative_ei_indyear  post_relative_ei_indyear   post_change_relative_ei_indyear lassets  fixed_ratio leverage_ratio   roa if new_entrants==1,  absorb(cvrnr  bank_year ILST)  cluster(ind2)
estimates store model6
meany exit    model6



esttab model1 model2 model3 model4 model5 model6  using ${exports}within_industry_analysis_relations_balanced_all_prepost_ilst_covfix.txt, replace style(tab) cells(b(star fmt(%9.3f)) se(par fmt(%9.3f))) label stats( r2 N, fmt( %9.3f %9.0fc) labels("R-sq" "N" )) starlevels(* 0.10 ** 0.05 *** 0.01)    keep(pre_relative_ei_indyear  pre_change_relative_ei_indyear  post_relative_ei_indyear   post_change_relative_ei_indyear  lassets  fixed_ratio leverage_ratio   roa) order(pre_relative_ei_indyear  pre_change_relative_ei_indyear  post_relative_ei_indyear   post_change_relative_ei_indyear lassets  fixed_ratio leverage_ratio   roa)

log close
