********************************************************************************
* Passive and active credit reallocation: AR(1) and AR(2)
* run "${do}Baseline Analysis/04_passive_active_credit_reallocation.do"

********************************************************************************
/*
INPUT:
    ${exports}forgraph_table_2003_2009_5bins_general.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}ar1.tex
        -> AR(1) supporting table; Table B.12
    ${exports}ar2.tex
        -> AR(2) supporting table; Table B.12

LOG:
    ${logs}passive_active_analysis.log
*/
clear all
set more off
capture log close


log using ${logs}passive_active_analysis.log, replace

use "${exports}forgraph_table_2003_2009_5bins_general.dta", replace


tsset ei_bin year, yearly

replace share_credit_output=share_of_credit_100/share_of_output_100
xtserial share_credit_output

*benchmark: AR1 with FE
eststo clear
eststo: xtreg share_credit_output l.share_credit_output i.ei_bin i.year
esttab using ${exports}ar1.tex, b(4) se(4) ar2(3) scalars(N) varwidth(25) label nobaselevels interaction(" $\times$ ") star(* 0.10 ** 0.05 *** 0.01) style(tex) replace booktabs alignment(D{.}{.}{-1}) title(AR(1) \label{tab:ar1})
predict predicted_share_co3

gen predicted_share_c3=predicted_share_co3*share_of_output_100
gen passive_bin_c3=predicted_share_c3*total_credit/100
gen active_bin_c3=bin_credit-passive_bin_c3

bysort ei_bin: tabstat active_bin_c3, stats(median mean)
bysort ei_bin: tabstat active_bin_c3 if year<2006, stats(median mean)
bysort ei_bin: tabstat active_bin_c3 if year>2016, stats(median mean)

bysort ei_bin: tabstat passive_bin_c3, stats(median mean)
bysort ei_bin: tabstat passive_bin_c3 if year<2006, stats(median mean)
bysort ei_bin: tabstat passive_bin_c3 if year>2016, stats(median mean)

*robustness: AR2 with FE
eststo clear
xtreg share_credit_output l.share_credit_output l2.share_credit_output i.ei_bin i.year
esttab using ${exports}ar2.tex, b(4) se(4) ar2(3) scalars(N) varwidth(25) label nobaselevels interaction(" $\times$ ") star(* 0.10 ** 0.05 *** 0.01) style(tex) replace booktabs alignment(D{.}{.}{-1}) title(AR(2) \label{tab:ar2})
predict predicted_share_co4

gen predicted_share_c4=predicted_share_co4*share_of_output_100
gen passive_bin_c4=predicted_share_c4*total_credit/100
gen active_bin_c4=bin_credit-passive_bin_c4

bysort ei_bin: tabstat active_bin_c4, stats(median mean)
bysort ei_bin: tabstat active_bin_c4 if year<2006, stats(median mean)
bysort ei_bin: tabstat active_bin_c4 if year>2016, stats(median mean)

bysort ei_bin: tabstat passive_bin_c4, stats(median mean)
bysort ei_bin: tabstat passive_bin_c4 if year<2006, stats(median mean)
bysort ei_bin: tabstat passive_bin_c4 if year>2016, stats(median mean)

log close 
