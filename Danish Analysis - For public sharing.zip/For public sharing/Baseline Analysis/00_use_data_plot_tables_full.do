********************************************************************************
* Descriptive figures and allocation-bin data: full sample
* Fixed data-derived energy intensity thresholds are redacted as xxxxx.
* Restore the appropriate thresholds in an authorized environment before running.
* This script is not directly executable.
* run "${do}Baseline Analysis/00_use_data_plot_tables_full.do"

********************************************************************************
/*
INPUT:
    ${data}firm_credit_full.dta
    ${data}transition_risk_v2.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}figure_ei_bar_first3.pdf -- Figure 6, left
    ${exports}figure_ei_bar_last3.pdf -- Figure 6, right
    ${exports}figure_ei_bar_first3_ind.pdf -- Figure 7, left
    ${exports}figure_ei_bar_last3_ind.pdf -- Figure 7, right
    ${exports}credit_share_general.pdf -- Figure 8
    ${exports}credit_share_within.pdf -- Figure 9
    ${exports}credit_share_within_brown.pdf -- Figure 10, left
    ${exports}credit_share_within_nonbrown.pdf -- Figure 10, right
    ${exports}credit_share_between.pdf -- Figure 11
    ${exports}ei_bin_output_credit_share_combined.pdf -- Figure 12
    ${exports}credit_share_within_top90.pdf -- Online Appendix Figure F.1
    ${exports}ei_bin_output_credit_share_within_combined.pdf -- Appendix Figure B.18
    ${exports}ei_bin_output_credit_share_between_combined.pdf -- Appendix Figure B.19
    ${exports}forgraph_table_2003_2009_5bins_general.dta
        Allocation-bin data for Figure 13-related analysis and script 04.

LOG:
    ${logs}use_data_plot_tables_full_sample.log

*/
capture log close
log using ${logs}use_data_plot_tables_full_sample.log, replace



use ${data}firm_credit_full.dta, replace

**keep if firm size is at least 2 to remove self-employed
keep if f_size >=2

sort cvrnr cvrnr_b year
distinct cvrnr cvrnr_b year
**********************further data cleaning ***********************
**generate dummy bank_id for NEVER firms
destring cvrnr, gen(firmid)
destring cvrnr_b, gen(bankid)
replace bankid =0 if missing(bankid)


***generate firm bank id
capture drop id
egen id = group(firmid  bankid)
format id %19.9g
distinct id    


***generate bank year fixed dummies
capture drop bank_year 
egen bank_year = group(bankid year)
format bank_year %19.9g
distinct bank_year  

****construct industry fixed dummies 
replace ind2 =0 if missing(ind2)
capture drop ind2year 
egen ind2year= group(ind2 year)
format   ind2year %19.9g



************generate loan outcome vars*********
**fill in zeros and compute log(balance) as l_balance
**fill in zeros 
capture drop nonmissing_balance 
gen nonmissing_balance = account_balance
replace nonmissing_balance=0 if missing(account_balance)
**log of account balance as l_balance
capture drop l_balance 
gen l_balance= 0
replace l_balance= log(nonmissing_balance) if  nonmissing_balance>0



**log change as growth in 100%
sort firmid bankid year
xtset id year
capture drop l_loan_change
gen l_loan_change = l_balance-l.l_balance  
replace l_loan_change=l_loan_change*100



***alternative definitions: gen loan growth using symmetric growth by taking into account 0
capture drop loan_change
gen loan_change = nonmissing_balance-l.nonmissing_balance

capture drop loan_growth
gen loan_growth = loan_change/(0.5*nonmissing_balance+0.5*l.nonmissing_balance)*100

su loan_growth  l_loan_change l_balance, det



***generate extensive margin variables
capture drop ext_l_loan 
gen ext_l_loan = 0
replace ext_l_loan =1 if loan_change>0 & loan_change !=.
tab ext_l_loan 


***fill in zeros for missing vars of loan outcomes
foreach i of varlist  l_balance loan_growth ext_l_loan l_loan_change{
	replace  `i' =0 if missing(`i') 
}




************generate energy intensity variables**********************
*** energy_intensity_1, lenergy_intensity_1, change of energy intensity
***use moving average of energy consumption (kene) after 2016
preserve

collapse (first) kene vtv, by(firmid year)
xtset firmid year
tsegen kene_m3 = rowmean(L(0/4).kene)
replace kene = kene_m3 if year >2016 & missing(kene)

capture drop energy_intensity_1
gen energy_intensity_1 = kene/(vtv/1000000) 
label var energy_intensity_1 "firm level energy purchase per thousand DKK value added:kene/(vtv/1000)"

capture drop lenergy_intensity_1
gen lenergy_intensity_1= log(energy_intensity_1)

capture drop change_ei
gen change_ei= lenergy_intensity_1-L.lenergy_intensity_1

save ${temp}kene_ma_file.dta, replace
restore 

capture drop  kene 
capture drop kene_m3 
capture drop energy_intensity_1 
capture drop lenergy_intensity_1 change_ei

merge m:1 firmid year using ${temp}kene_ma_file.dta
capture drop _merge



tabstat kene, by(year)

tabstat energy_intensity_1, by(year)



****tssset the data
capture program drop meany
program def meany, rclass
args var spec
sum `var' if e(sample), mean
estadd scalar Meany=r(mean)
end

tsset id year



**************************************************************************
***generating plots for facts part of danish data
**************************************************************************

**************************************************************************
***what is the firm energy intensity distribution for first 3 years vs last 3 years for the full firm sample
**************************************************
collapse (sum) account_balance (sum)  sum_interest (mean) kene (mean) vtv (mean) energy_intensity_1 (mean) ind2, by(firmid year)


distinct firmid year  
 
***indentify first and last 3 years of sample
summarize year, meanonly
local start = r(min)
local end = r(max)

capture drop  time_group 
gen time_group =.

replace time_group = 1 if inrange(year, `start', `start'+2 )
replace time_group = 2 if inrange(year, `end'-2, `end')
tab time_group year

save  ${temp}forgraph.dta, replace


****generate histogram plot for first 3 years
use  ${temp}forgraph.dta, replace

***set a few negative values of energy consumption, account balance, and value added, to missing
replace vtv =. if vtv<0
replace kene =. if kene<0
replace energy_intensity_1 =. if energy_intensity_1 <0
replace account_balance =. if account_balance<0

save ${temp}forgraph_nonegative.dta, replace

keep if time_group== 1 

capture drop ei_basemean
bysort firmid: egen ei_basemean = mean(energy_intensity_1)
bysort firmid: keep if _n==1

capture drop bin5
xtile bin5 = ei_basemean, n(5) 
tab bin5 


graph bar  ei_basemean, over(bin5) title("2003-2005", size(large)) ytitle("") bar(1,color(green%30)) ylabel(0(40)160, nogrid labsize(large)) 
graph save  ${graphs}ei_bar_first3.gph, replace
graph export ${exports}figure_ei_bar_first3.pdf, as(pdf) replace	
 

***hist for the last 3 years
use  ${temp}forgraph.dta, replace

***set a few negative values of energy consumption, account balance, and value added, to missing
replace vtv =. if vtv<0
replace kene =. if kene<0
replace energy_intensity_1 =. if energy_intensity_1 <0
replace account_balance =. if account_balance<0


keep if time_group== 2



capture drop ei_basemean
bysort firmid: egen ei_basemean = mean(energy_intensity_1)
bysort firmid: keep if _n==1

capture drop bin5
xtile bin5 = ei_basemean, n(5) 
tab bin5 

graph bar ei_basemean, over(bin5) title("2017-2019", size(large)) ytitle("") bar(1,color(green%30)) ylabel(0(40)160, nogrid labsize(large)) 
graph save  ${graphs}ei_bar_last3.gph, replace
graph export ${exports}figure_ei_bar_last3.pdf, as(pdf) replace	
 




**************************************************************************
***Do banks shift lending in general? split firms into brown and non brown by energy intensity over the first 3 years and plot the total credit allocation
use ${temp}forgraph_nonegative.dta, replace

keep if energy_intensity_1 !=.
***define brown dummy using the whole sample
capture drop  ei_basemean
bysort firmid: egen ei_basemean = mean(energy_intensity_1)

capture drop brown_dummy
xtile brown_dummy = energy_intensity_1 if energy_intensity_1 !=., n(4) 

capture drop is_brown
gen is_brown =(brown_dummy ==4)
replace is_brown = 0 if missing(brown_dummy)
tab is_brown


***indentify first and last 3 years of sample
summarize year, meanonly
local start = r(min)
local end = r(max)

capture drop  time_group 
gen time_group =.

replace time_group = 1 if inrange(year, `start', `start'+2 )
replace time_group = 2 if inrange(year, `end'-2, `end')
tab time_group is_brown



****generate histogram plot 
keep if !missing(time_group)
collapse (sum) credit = account_balance if energy_intensity_1 !=., by(time_group is_brown)

*bysort time_group is_brown: egen credit = total(account_balance)

bysort time_group: egen total_credit = total(credit)

gen credit_share = credit/total_credit


label define brown_lbl 0 "Non dirty firms"      1 "Dirty firms"
label values is_brown brown_lbl

graph bar  credit_share, ///
 over(time_group, relabel(1"2003-2005"   2 "2017-2019" ) label(labsize(large) )) ///
over(is_brown,  label(labsize(large))) ///
 ascategory ///
 bar(1, color(orange%30)) ///
 bar(2, color(green%30)) bar(3, color(green%30))  bar(4, color(orange%30)) ///
 ytitle("") legend(off) ylabel(, nogrid labsize(large))

 
graph save  ${graphs}credit_share_general.gph, replace
graph export ${exports}credit_share_general.pdf, as(pdf) replace	
 



**************************************************************************
***Do banks shift lending within brown and green industry? split firms into brown and non brown by relative energy intensity and plot the toal credit allocation
use ${temp}forgraph_nonegative.dta, replace

keep if energy_intensity_1 !=.

****calculate relative energy intensity
capture drop lenergy_intensity_1
gen lenergy_intensity_1= log(energy_intensity_1)



********************************************************************
capture drop relative_ei_indyear
local var "lenergy_intensity_1"

** collapse by industry to obtain the mean and sd of the industry sample 
capture drop _merge
foreach  v in `var'{
preserve	
collapse (mean) mean_`v' =`v' (sd) sd_`v'  = `v', by(ind2 year) 
save ${temp}collapse_`v', replace
restore
capture drop _merge 
capture drop mean_`v' 
capture drop sd_`v'
merge m:1 ind2 year using ${temp}collapse_`v'
sort ind2 year
gen relative_ei_indyear = (`v'-mean_`v')/sd_`v'
*drop if relative_ei_indyear == .
}
su  relative_ei_indyear, det


capture drop  relative_ei_basemean
bysort firmid: egen relative_ei_basemean = mean(relative_ei_indyear)

***define brown firms
capture drop brown_dummy
xtile brown_dummy = relative_ei_indyear   if  relative_ei_indyear  != ., nquantiles(4)

capture drop is_brown
gen is_brown =(brown_dummy ==4)
replace is_brown = 0 if missing(brown_dummy)
tab is_brown


***check number of unique firms in each group 
distinct firmid if brown==1 & time_group==1
distinct firmid if brown==1 & time_group==2
 
****generate histogram plot 
keep if !missing(time_group)
collapse (sum) credit = account_balance if  relative_ei_indyear  != ., by(time_group is_brown)

bysort time_group: egen total_credit = total(credit)

gen credit_share = credit/total_credit

label define brown_lbl 0 "Non dirty firms"      1 "Dirty firms"
label values is_brown brown_lbl


graph bar  credit_share, ///
 over(time_group, relabel(1"2003-2005"   2 "2017-2019" ) label(labsize(large) )) ///
over(is_brown,  label(labsize(large))) ///
 ascategory ///
 bar(1, color(orange%30)) ///
 bar(2, color(green%30)) bar(3, color(green%30))  bar(4, color(orange%30)) ///
 ytitle("") legend(off) ylabel(, nogrid labsize(large))

 
graph save  ${graphs}credit_share_within.gph, replace
graph export ${exports}credit_share_within.pdf, as(pdf) replace	
 
 
 
**************************************************************************
*Robustness:
*split firms into brown and non brown by relative energy intensity using 90% threshold
*and plot the toal credit allocation
use ${temp}forgraph_nonegative.dta, replace

keep if energy_intensity_1 !=.

****calculate relative energy intensity
capture drop lenergy_intensity_1
gen lenergy_intensity_1= log(energy_intensity_1)



capture drop relative_ei_indyear
local var "lenergy_intensity_1"

** collapse by industry to obtain the mean and sd of the industry sample 
capture drop _merge
foreach  v in `var'{
preserve	
collapse (mean) mean_`v' =`v' (sd) sd_`v'  = `v', by(ind2 year) 
save ${temp}collapse_`v', replace
restore
capture drop _merge 
capture drop mean_`v' 
capture drop sd_`v'
merge m:1 ind2 year using ${temp}collapse_`v'
sort ind2 year
gen relative_ei_indyear = (`v'-mean_`v')/sd_`v'
*drop if relative_ei_indyear == .
}
su  relative_ei_indyear, det


capture drop  relative_ei_basemean
bysort firmid: egen relative_ei_basemean = mean(relative_ei_indyear)

***define brown firms
capture drop p90_relative_ei
su relative_ei_indyear, det
local p90_relative_ei= r(p90)

capture drop is_brown  

gen is_brown = relative_ei_indyear>= `p90_relative_ei'

replace is_brown = 0 if missing(relative_ei_indyear)
tab is_brown


***check number of unique firms in each group 
distinct firmid if is_brown==1 & time_group==1
distinct firmid if is_brown==1 & time_group==2
 
****generate histogram plot 
keep if !missing(time_group)
collapse (sum) credit = account_balance if  relative_ei_indyear  != ., by(time_group is_brown)

bysort time_group: egen total_credit = total(credit)

gen credit_share = credit/total_credit

label define brown_lbl 0 "Non dirty firms"      1 "Dirty firms"
label values is_brown brown_lbl


graph bar  credit_share, ///
 over(time_group, relabel(1"2003-2005"   2 "2017-2019" ) label(labsize(large) )) ///
over(is_brown,  label(labsize(large))) ///
 ascategory ///
 bar(1, color(orange%30)) ///
 bar(2, color(green%30)) bar(3, color(green%30))  bar(4, color(orange%30)) ///
 ytitle("") legend(off) ylabel(, nogrid labsize(large))

 
graph save  ${graphs}credit_share_within_top90.gph, replace
graph export ${exports}credit_share_within_top90.pdf, as(pdf) replace	
 
 
**************************************************************************
***Are indusries getting greener?
** industry emission distribution
use ${data}transition_risk_v2.dta, replace
tsset ind2 year
capture drop emission_intensity

*deflator (statistik banken: pris112)
gen deflator=.
replace deflator=68 if year==1995
replace deflator=69.5 if year==1996
replace deflator=71 if year==1997
replace deflator=72.3 if year==1998
replace deflator=74.1 if year==1999
replace deflator=76.2 if year==2000
replace deflator=78 if year==2001
replace deflator=79.9 if year==2002
replace deflator=81.6 if year==2003
replace deflator=82.5 if year==2004
replace deflator=84 if year==2005
replace deflator=85.6 if year==2006
replace deflator=87.1 if year==2007
replace deflator=90.1 if year==2008
replace deflator=91.2 if year==2009
replace deflator=93.3 if year==2010
replace deflator=95.9 if year==2011
replace deflator=98.2 if year==2012
replace deflator=99 if year==2013
replace deflator=99.6 if year==2014
replace deflator=100 if year==2015
replace deflator=100.3 if year==2016
replace deflator=101.4 if year==2017
replace deflator=102.2 if year==2018
replace deflator=103 if year==2019
replace deflator = deflator/100


gen rva_detailed = gva_detailed/deflator 

gen emission_intensity=GHG_total/rva_detailed
label variable emission_intensity "GHG_total/rva_detailed"
su emission_intensity, det



***indentify first and last 3 years of sample
summarize year, meanonly
local start = 2003
local end = 2019

capture drop  time_group 
gen time_group =.

replace time_group = 1 if inrange(year, `start', `start'+2 )
replace time_group = 2 if inrange(year, `end'-2, `end')
tab time_group year

save  ${temp}transition_risk_v2.dta, replace


****generate histogram plot for first 3 years
use ${temp}transition_risk_v2.dta, replace
keep if time_group== 1 & !missing(emission_intensity)

capture drop bin5
xtile bin5 = emission_intensity if emission_intensity !=., n(5)
tab bin5

gen emission_intensity_100 =emission_intensity*100

graph bar  (mean) emission_intensity_100, over(bin5) title("2003-2005", size(large))  ytitle("") bar(1,color(green%30))  ylabel(0(20)60, nogrid  labsize(large))

 
 
 
graph save  ${graphs}figure_ei_bar_first3_ind.gph, replace
graph export ${exports}figure_ei_bar_first3_ind.pdf, as(pdf) replace	
 


****generate histogram plot for last 3 years
use ${temp}transition_risk_v2.dta, replace
keep if time_group== 2 & !missing(emission_intensity)

capture drop bin5
xtile bin5 = emission_intensity if emission_intensity !=., n(5)
tab bin5

gen emission_intensity_100 =emission_intensity*100


graph bar  (mean) emission_intensity_100, over(bin5) title("2017-2019", size(large))  ytitle("") bar(1,color(green%30))  ylabel(0(20)60, nogrid  labsize(large))

 
graph save  ${graphs}figure_ei_bar_last3_ind.gph, replace
graph export ${exports}figure_ei_bar_last3_ind.pdf, as(pdf) replace	
 


****restore credit data and merge with industry emission
use ${temp}forgraph_nonegative.dta, replace

capture drop _merge
capture drop emission_intensity 
merge m:1 ind2 year using ${temp}transition_risk_v2.dta
drop if _merge ==2
capture drop _merge

keep if  emission_intensity !=.

***define brown firms
capture drop  emission_intensity_basemean
bysort firmid: egen emission_intensity_basemean = mean(emission_intensity)

capture drop brown_dummy
xtile brown_dummy =emission_intensity if emission_intensity !=., nquantiles(4)

capture drop is_brown
gen is_brown =(brown_dummy ==4)
replace is_brown = 0 if missing(brown_dummy)

***indentify first and last 3 years of sample
summarize year, meanonly
local start = 2003
local end = 2019

capture drop  time_group 
gen time_group =.

replace time_group = 1 if inrange(year, `start', `start'+2 )
replace time_group = 2 if inrange(year, `end'-2, `end')
tab time_group is_brown


***check number of unique firms in each group 
distinct firmid if brown==1 & time_group==1
distinct firmid if brown==1 & time_group==2


****generate histogram plot 

keep if !missing(time_group)
collapse (sum) credit = account_balance, by(time_group is_brown)

bysort time_group: egen total_credit = total(credit)

gen credit_share = credit/total_credit


label define brown_lbl 0 "Non dirty firms"      1 "Dirty firms"
label values is_brown brown_lbl


graph bar  credit_share, ///
 over(time_group, relabel(1"2003-2005"   2 "2017-2019" ) label(labsize(large) )) ///
over(is_brown,  label(labsize(large))) ///
 ascategory ///
 bar(1, color(orange%30)) ///
 bar(2, color(green%30)) bar(3, color(green%30))  bar(4, color(orange%30)) ///
 ytitle("") legend(off) ylabel(, nogrid labsize(large))

 
graph save  ${graphs}credit_share_between.gph, replace
graph export ${exports}credit_share_between.pdf, as(pdf) replace	
 



****** Create two subplots for within industry allocation between brown vs nonbrown sector

use ${temp}forgraph_nonegative.dta, replace

keep if energy_intensity_1 !=.

****calculate relative energy intensity
capture drop lenergy_intensity_1
gen lenergy_intensity_1= log(energy_intensity_1)

capture drop relative_ei_indyear
local var "lenergy_intensity_1"

** collapse by industry to obtain the mean and sd of the industry sample 
capture drop _merge
foreach  v in `var'{
preserve	
collapse (mean) mean_`v' =`v' (sd) sd_`v'  = `v', by(ind2 year) 
save ${temp}collapse_`v', replace
restore
capture drop _merge 
capture drop mean_`v' 
capture drop sd_`v'
merge m:1 ind2 year using ${temp}collapse_`v'
sort ind2 year
gen relative_ei_indyear = (`v'-mean_`v')/sd_`v'
*drop if relative_ei_indyear == .
}
su  relative_ei_indyear, det



capture drop _merge
capture drop emission_intensity 
merge m:1 ind2 year using ${temp}transition_risk_v2.dta
drop if _merge ==2
capture drop _merge


capture drop  brown_ind
su emission_intensity, det
gen brown_ind = (emission_intensity>= r(p75))
replace brown_ind= . if emission_intensity ==.
tab ind2label if brown_ind ==1



*****************For firms in brown industry**********
preserve
keep if brown_ind==1
capture drop  relative_ei_basemean
bysort firmid: egen relative_ei_basemean = mean(relative_ei_indyear)

***define brown firms
capture drop brown_dummy
xtile brown_dummy = relative_ei_indyear   if  relative_ei_indyear  != ., nquantiles(4)

capture drop is_brown
gen is_brown =(brown_dummy ==4)
replace is_brown = 0 if missing(brown_dummy)
tab is_brown


 
****generate histogram plot 
keep if !missing(time_group)
collapse (sum) credit = account_balance if  relative_ei_indyear  != ., by(time_group is_brown)

bysort time_group: egen total_credit = total(credit)

gen credit_share = credit/total_credit

label define brown_lbl 0 "Non dirty firms"      1 "Dirty firms"
label values is_brown brown_lbl


graph bar  credit_share, ///
 over(time_group, relabel(1"2003-2005"   2 "2017-2019" ) label(labsize(large) )) ///
over(is_brown,  label(labsize(large))) ///
 ascategory ///
 bar(1, color(orange%30)) ///
 bar(2, color(green%30)) bar(3, color(green%30))  bar(4, color(orange%30)) ///
 ytitle("") legend(off) ylabel(, nogrid labsize(large))

 
graph save  ${graphs}credit_share_within_brown.gph, replace
graph export ${exports}credit_share_within_brown.pdf, as(pdf) replace	
 
restore


*****************For firms in non-brown industry**********
preserve
keep if brown_ind!=1
capture drop  relative_ei_basemean
bysort firmid: egen relative_ei_basemean = mean(relative_ei_indyear)

***define brown firms
capture drop brown_dummy
xtile brown_dummy = relative_ei_indyear   if  relative_ei_indyear  != ., nquantiles(4)

capture drop is_brown
gen is_brown =(brown_dummy ==4)
replace is_brown = 0 if missing(brown_dummy)
tab is_brown


 
****generate histogram plot 
keep if !missing(time_group)
collapse (sum) credit = account_balance if  relative_ei_indyear  != ., by(time_group is_brown)

bysort time_group: egen total_credit = total(credit)

gen credit_share = credit/total_credit

label define brown_lbl 0 "Non dirty firms"      1 "Dirty firms"
label values is_brown brown_lbl


graph bar  credit_share, ///
 over(time_group, relabel(1"2003-2005"   2 "2017-2019" ) label(labsize(large) )) ///
over(is_brown,  label(labsize(large))) ///
 ascategory ///
 bar(1, color(green%30)) ///
 bar(2, color(green%30)) bar(3, color(green%30))  bar(4, color(green%30)) ///
 ytitle("") legend(off) ylabel(, nogrid labsize(large))

 
graph save  ${graphs}credit_share_within_nonbrown.gph, replace
graph export ${exports}credit_share_within_nonbrown.pdf, as(pdf) replace	
 
restore




**************************************************************************
***passive vs active allocation in general
**************************************************************************
****split into 5 bins based on energy intensity 

****restore credit data and merge with industry emission
use ${temp}forgraph_nonegative.dta, replace


capture drop _merge
capture drop emission_intensity 
merge m:1 ind2 year using ${temp}transition_risk_v2.dta
drop if _merge ==2
capture drop _merge


save ${temp}forgraph_passive_active.dta, replace


preserve
***calculate the benchmark (mean) for each bins and save the numbers for the benchmark
keep if year<=2005
keep if energy_intensity_1!= . //universe of firms with energy intensity info
capture drop ei_bin
xtile ei_bin =  energy_intensity_1 if energy_intensity_1!= ., nq(4) 
tab ei_bin


capture drop benchmark_ei_bin 
bysort ei_bin: egen benchmark_ei_bin = mean(energy_intensity_1) if  ei_bin != .

 
bysort benchmark_ei_bin: keep if _n==1
keep benchmark_ei_bin 
drop if benchmark_ei_bin == .
save  ${temp}benchmark_ei_bin, replace
restore




********plots for first 3 years
use ${temp}forgraph_passive_active.dta, replace

keep if year <=2005

***split the firms  for every year into 5 bins based on benchmark values saved before

capture drop  ei_bin

gen  ei_bin = .

replace  ei_bin =1 if energy_intensity_1<=xxxxx & energy_intensity_1 != .

replace  ei_bin =2 if energy_intensity_1>xxxxx & energy_intensity_1<=xxxxx &energy_intensity_1 != .

replace  ei_bin =3 if energy_intensity_1>xxxxx  & energy_intensity_1<=xxxxx & energy_intensity_1 != .

replace  ei_bin =4 if energy_intensity_1>xxxxx & energy_intensity_1<=xxxxx  & energy_intensity_1 != .

replace  ei_bin = 5 if energy_intensity_1>xxxxx & energy_intensity_1 != . 

tab  ei_bin



capture drop vtv_million
gen  vtv_million = vtv/1000000

***sum of total output 
tabstat vtv_million, by(ei_bin) s(sum n) 

***sum of total credit
tabstat account_balance, by(ei_bin) s(sum n) 

**hare of total output in each group
capture drop bin_output 
bysort ei_bin: egen bin_output = total(vtv_million) if  ei_bin != .
tab  bin_output 

capture drop total_output
egen total_output =  total(vtv_million) if  ei_bin != .

capture drop share_of_output 
gen share_of_output = bin_output/total_output if  ei_bin != .

*}

su energy_intensity_1, det
tabstat  vtv_million, by(ei_bin) s(sum n)
tabstat  share_of_output, by(ei_bin) s(mean)



***share of total credit in each group
capture drop account_balance_bill
gen  account_balance_bill= account_balance/1000000000


capture drop bin_credit
bysort ei_bin: egen bin_credit = total(account_balance_bill) if  ei_bin != .
tab  bin_credit

capture drop total_credit
egen total_credit =  total(account_balance_bill) if  ei_bin != .

capture drop share_of_credit
gen share_of_credit = bin_credit/total_credit  if  ei_bin != .


save ${temp}ei_bin_first3, replace


use ${temp}ei_bin_first3, replace

egen unique_firm = tag(firmid)


collapse (mean) bin_output (mean) total_output (mean) share_of_output (mean) bin_credit (mean) total_credit (mean) share_of_credit (sum) unique_firm (mean) energy_intensity_1 , by(ei_bin)

capture drop share_of_output_100 share_of_credit_100
gen  share_of_output_100= share_of_output*100
gen  share_of_credit_100= share_of_credit*100

save ${temp}forgraph_first3, replace


use ${temp}forgraph_first3, replace
graph bar  (mean) share_of_output_100 share_of_credit_100, over(ei_bin) bar(1, color(green%30)) bar(2, color(orange%30)) title("2003-2005", size(large)) ytitle("") plotregion(style(none)) graphregion(style(none))  ylab(0(10)40, nogrid labsize(large))       legend(off) 
graph save  ${graphs}ei_bin_output_credit_share_first3.gph, replace
*graph export ${exports}ei_bin_output_credit_share_first3.pdf, as(pdf) replace	
 






********plots for last 3 years
use ${temp}forgraph_passive_active.dta, replace

	
keep if year >=2017

***split the firms  for every year into 5 bins based on benchmark values saved before

capture drop  ei_bin

gen  ei_bin = .

replace  ei_bin =1 if energy_intensity_1<=xxxxx & energy_intensity_1 != .

replace  ei_bin =2 if energy_intensity_1>xxxxx & energy_intensity_1<=xxxxx &energy_intensity_1 != .

replace  ei_bin =3 if energy_intensity_1>xxxxx  & energy_intensity_1<=xxxxx & energy_intensity_1 != .

replace  ei_bin =4 if energy_intensity_1>xxxxx & energy_intensity_1<=xxxxx  & energy_intensity_1 != .

replace  ei_bin = 5 if energy_intensity_1>xxxxx & energy_intensity_1 != . 

tab  ei_bin

distinct firmid if ei_bin ==1
distinct firmid  if ei_bin ==2
distinct firmid  if ei_bin ==3
distinct firmid  if ei_bin ==4
distinct firmid  if ei_bin ==5


capture drop vtv_million
gen  vtv_million = vtv/1000000

***sum of total output 
tabstat vtv_million, by(ei_bin) s(sum n) 


***sum of total credit
tabstat account_balance, by(ei_bin) s(sum n) 

***total share of total output in each group
capture drop bin_output 
bysort ei_bin: egen bin_output = total(vtv_million) if  ei_bin != .
tab  bin_output 

capture drop total_output
egen total_output =  total(vtv_million) if  ei_bin != .

capture drop share_of_output 
gen share_of_output = bin_output/total_output if  ei_bin != .

*}

su energy_intensity_1, det
tabstat  vtv_million, by(ei_bin) s(sum n)
tabstat  share_of_output, by(ei_bin) s(mean)



***share of total credit in each group
capture drop account_balance_bill
gen  account_balance_bill= account_balance/1000000000


capture drop bin_credit
bysort ei_bin: egen bin_credit = total(account_balance_bill) if  ei_bin != .
tab  bin_credit

capture drop total_credit
egen total_credit =  total(account_balance_bill) if  ei_bin != .

capture drop share_of_credit
gen share_of_credit = bin_credit/total_credit  if  ei_bin != .


save ${temp}ei_bin_last3, replace


use ${temp}ei_bin_last3, replace

egen unique_firm = tag(firmid)
su unique_firm

collapse (mean) bin_output (mean) total_output (mean) share_of_output (mean) bin_credit (mean) total_credit (mean) share_of_credit (sum) unique_firm (mean) energy_intensity_1 , by(ei_bin)

capture drop share_of_output_100 share_of_credit_100
gen  share_of_output_100= share_of_output*100
gen  share_of_credit_100= share_of_credit*100

save ${temp}forgraph_last3, replace

use  ${temp}forgraph_last3, replace
graph bar  (mean) share_of_output_100 share_of_credit_100, over(ei_bin) bar(1, color(green%30)) bar(2, color(orange%30)) title("2017-2019", size(large)) ytitle("") plotregion(style(none)) graphregion(style(none))  ylab(0(10)40, nogrid labsize(large))    legend(position(1) ring(0) rows(2) region(lstyle(none)) label(1 "Output Density" ) label(2 "Credit Density") bmargin(small) size(large)) 
graph save  ${graphs}ei_bin_output_credit_share_last3.gph, replace
*graph export ${exports}ei_bin_output_credit_share_last3.pdf, as(pdf) replace	




graph combine ${graphs}ei_bin_output_credit_share_first3.gph ${graphs}ei_bin_output_credit_share_last3.gph, row(1) iscale(1) imargin(zero)
graph export ${exports}ei_bin_output_credit_share_combined.pdf, as(pdf) replace	





****************loop for all years*************************************************
use ${temp}forgraph_passive_active.dta, replace

	
forvalues i= 2003(1)2019{
	
preserve


keep if year ==`i'

***split the firms  for every year into 5 bins based on benchmark values saved before

capture drop  ei_bin

gen  ei_bin = .
replace  ei_bin =1 if energy_intensity_1<=xxxxx & energy_intensity_1 != .

replace  ei_bin =2 if energy_intensity_1>xxxxx & energy_intensity_1<=xxxxx &energy_intensity_1 != .

replace  ei_bin =3 if energy_intensity_1>xxxxx  & energy_intensity_1<=xxxxx & energy_intensity_1 != .

replace  ei_bin =4 if energy_intensity_1>xxxxx & energy_intensity_1<=xxxxx  & energy_intensity_1 != .

replace  ei_bin = 5 if energy_intensity_1>xxxxx & energy_intensity_1 != . 


tab  ei_bin


capture drop vtv_million
gen  vtv_million = vtv/1000000

 

***total share of total output in each group
capture drop bin_output 
bysort ei_bin: egen bin_output = total(vtv_million) if  ei_bin != .


capture drop total_output
egen total_output =  total(vtv_million) if  ei_bin != .

capture drop share_of_output 
gen share_of_output = bin_output/total_output if  ei_bin != .


***total share of total credit in each group
capture drop account_balance_bill
gen  account_balance_bill= account_balance/1000000000


capture drop bin_credit
bysort ei_bin: egen bin_credit = total(account_balance_bill) if  ei_bin != .
tab  bin_credit

capture drop total_credit
egen total_credit =  total(account_balance_bill) if  ei_bin != .

capture drop share_of_credit
gen share_of_credit = bin_credit/total_credit  if  ei_bin != .


save ${temp}ei_bin_`i', replace


use ${temp}ei_bin_`i', replace

egen unique_firm = tag(firmid)


collapse (mean) bin_output (mean) total_output (mean) share_of_output (mean) bin_credit (mean) total_credit (mean) share_of_credit (sum) unique_firm (mean) energy_intensity_1 , by(ei_bin)

capture drop share_of_output_100 share_of_credit_100
gen  share_of_output_100= share_of_output*100
gen  share_of_credit_100= share_of_credit*100

save ${temp}forgraph_`i', replace


restore
}



forvalues i= 2003(1)2019{
	
use ${temp}forgraph_`i', replace

capture drop year 

gen year = `i'

drop if ei_bin == .

save ${temp}forgraph_`i', replace
}


use ${temp}forgraph_2003, replace

forvalues i= 2004(1)2019{
	
append using  ${temp}forgraph_`i'

capture drop if ei_bin == .
}

*capture drop  energy_intensity_1 unique_firm share_of_credit share_of_output

capture drop share_credit_output

gen share_credit_output = share_of_credit_100/share_of_output_100*100


capture drop share_output_credit

gen share_output_credit= share_of_output_100/share_of_credit_100*100

***label the variables
label var ei_bin "firm energy intensity bins based on the first 3 years, bin 1 (lowest), bin 5 (highest)"

label var bin_output "total output (real value added) per bin in millions DKK"

label var total_output "total output (real value added) for all 5 bins in millions DKK"

label var bin_credit "total credit per bin in billions DKK"

label var total_credit "total credit for all 5 bins in billions DKK"

label var share_of_output "bin output as a share of total output (bin_output/total_output)"

label var share_of_credit "bin credit as a share of total credit (bin_credit/total_credit)"

label var unique_firm "the number of unique firms in each bin"

label var share_of_credit_100  "bin credit as a share of total credit in percent (bin_credit/total_credit*100)"

label var share_of_output_100  "bin output as a share of total output in percent (bin_output/total_output*100)"

label var share_credit_output  "share_of_credit_100/share_of_output_100*100"

label var share_output_credit  "share_of_output_100/share_of_credit*100"

label var energy_intensity_1 "average energy consumption per 1000 DKK value added per bin"

save  ${exports}forgraph_table_2003_2009_5bins_general.dta, replace







 
**************************************************************************
***passive vs active allocation within industry
**************************************************************************
****split into 5 bins based on relative energy intensity 

****calculate relative energy intensity
use ${temp}forgraph_passive_active.dta, replace

capture drop lenergy_intensity_1
gen lenergy_intensity_1= log(energy_intensity_1)
capture drop relative_ei_indyear
local var "lenergy_intensity_1"

** collapse by industry to obtain the mean and sd of the industry sample 
capture drop _merge
foreach  v in `var'{
preserve	
collapse (mean) mean_`v' =`v' (sd) sd_`v'  = `v', by(ind2 year) 
save ${temp}collapse_`v', replace
restore
capture drop _merge mean_`v' sd_`v'
merge m:1 ind2 year using ${temp}collapse_`v'
sort ind2 year
gen relative_ei_indyear = (`v'-mean_`v')/sd_`v'
*drop if relative_ei_indyear == .
}
su  relative_ei_indyear, det



preserve
keep if year<=2005
capture drop ei_bin
xtile ei_bin =   relative_ei_indyear if  relative_ei_indyear!= ., nq(4) 
tab ei_bin

***calculate the benchmark (mean) for each bins and save the numbers for the benchmark
capture drop benchmark_ei_bin 
bysort ei_bin: egen benchmark_ei_bin = mean(relative_ei_indyear) if  ei_bin != .
bysort benchmark_ei_bin: keep if _n==1
keep benchmark_ei_bin 
drop if benchmark_ei_bin == .
save  ${temp}benchmark_ei_bin_within, replace
restore





********plots for first 3 years
preserve
	
keep if year <=2005

***split the firms  for every year into 5 bins based on benchmark values saved before

capture drop  ei_bin

gen  ei_bin = .

replace  ei_bin =1 if  relative_ei_indyear<=xxxxx &  relative_ei_indyear != .

replace  ei_bin =2 if relative_ei_indyear>xxxxx & relative_ei_indyear<=xxxxx & relative_ei_indyear != .

replace  ei_bin =3 if relative_ei_indyear>xxxxx & relative_ei_indyear<=xxxxx & relative_ei_indyear != .


replace  ei_bin =4 if relative_ei_indyear>xxxxx & relative_ei_indyear<=xxxxx & relative_ei_indyear != .

replace  ei_bin = 5 if relative_ei_indyear>xxxxx & relative_ei_indyear != . 

tab  ei_bin



capture drop vtv_million
gen  vtv_million = vtv/1000000

***sum of total output 
tabstat vtv_million, by(ei_bin) s(sum n) 


***sum of total credit
tabstat account_balance, by(ei_bin) s(sum n) 

***total share of total output in each group
capture drop bin_output 
bysort ei_bin: egen bin_output = total(vtv_million) if  ei_bin != .
tab  bin_output 

capture drop total_output
egen total_output =  total(vtv_million) if  ei_bin != .

capture drop share_of_output 
gen share_of_output = bin_output/total_output if  ei_bin != .

*}

su energy_intensity_1, det
tabstat  vtv_million, by(ei_bin) s(sum n)
tabstat  share_of_output, by(ei_bin) s(mean)



***share of total credit in each group
capture drop account_balance_bill
gen  account_balance_bill= account_balance/1000000000


capture drop bin_credit
bysort ei_bin: egen bin_credit = total(account_balance_bill) if  ei_bin != .
tab  bin_credit

capture drop total_credit
egen total_credit =  total(account_balance_bill) if  ei_bin != .

capture drop share_of_credit
gen share_of_credit = bin_credit/total_credit  if  ei_bin != .


save ${temp}ei_bin_first3, replace


use ${temp}ei_bin_first3, replace

egen unique_firm = tag(firmid)


collapse (mean) bin_output (mean) total_output (mean) share_of_output (mean) bin_credit (mean) total_credit (mean) share_of_credit (sum) unique_firm (mean) energy_intensity_1 , by(ei_bin)

capture drop share_of_output_100 share_of_credit_100
gen  share_of_output_100= share_of_output*100
gen  share_of_credit_100= share_of_credit*100

label var share_of_credit_100 "Credit Density"
label var share_of_output_100 "Output Density"

save ${temp}forgraph_first3, replace


graph bar  (mean) share_of_output_100 share_of_credit_100, over(ei_bin) bar(1, color(green%30)) bar(2, color(orange%30)) title("2003-2005", size(large)) ytitle("") plotregion(style(none)) graphregion(style(none))  ylab(0(10)40, nogrid labsize(large))    legend(off)
graph save  ${graphs}ei_bin_output_credit_share_first3_within.gph, replace
*graph export ${exports}ei_bin_output_credit_share_first3_within.pdf, as(pdf) replace	
 
restore




********plots for last 3 years

preserve
	
keep if year >=2017

***split the firms  for every year into 5 bins based on benchmark values saved before

capture drop  ei_bin

gen  ei_bin = .

replace  ei_bin =1 if  relative_ei_indyear<=xxxxx &  relative_ei_indyear != .

replace  ei_bin =2 if relative_ei_indyear>xxxxx & relative_ei_indyear<=xxxxx & relative_ei_indyear != .

replace  ei_bin =3 if relative_ei_indyear>xxxxx & relative_ei_indyear<=xxxxx & relative_ei_indyear != .

replace  ei_bin =4 if relative_ei_indyear>xxxxx & relative_ei_indyear<=xxxxx & relative_ei_indyear != .

replace  ei_bin = 5 if relative_ei_indyear>xxxxx & relative_ei_indyear != . 

tab  ei_bin



capture drop vtv_million
gen  vtv_million = vtv/1000000

***sum of total output 
tabstat vtv_million, by(ei_bin) s(sum n) 


***sum of total credit
tabstat account_balance, by(ei_bin) s(sum n) 

***total share of total output in each group
capture drop bin_output 
bysort ei_bin: egen bin_output = total(vtv_million) if  ei_bin != .
tab  bin_output 

capture drop total_output
egen total_output =  total(vtv_million) if  ei_bin != .

capture drop share_of_output 
gen share_of_output = bin_output/total_output if  ei_bin != .

*}

su energy_intensity_1, det
tabstat  vtv_million, by(ei_bin) s(sum n)
tabstat  share_of_output, by(ei_bin) s(mean)



***share of total credit in each group
capture drop account_balance_bill
gen  account_balance_bill= account_balance/1000000000


capture drop bin_credit
bysort ei_bin: egen bin_credit = total(account_balance_bill) if  ei_bin != .
tab  bin_credit

capture drop total_credit
egen total_credit =  total(account_balance_bill) if  ei_bin != .

capture drop share_of_credit
gen share_of_credit = bin_credit/total_credit  if  ei_bin != .


save ${temp}ei_bin_last3, replace


use ${temp}ei_bin_last3, replace

egen unique_firm = tag(firmid)


collapse (mean) bin_output (mean) total_output (mean) share_of_output (mean) bin_credit (mean) total_credit (mean) share_of_credit (sum) unique_firm (mean) energy_intensity_1 , by(ei_bin)

capture drop share_of_output_100 share_of_credit_100
gen  share_of_output_100= share_of_output*100
gen  share_of_credit_100= share_of_credit*100

label var share_of_credit_100 "Credit Density"
label var share_of_output_100 "Output Density"

su unique_firm

save ${temp}forgraph_last3, replace

graph bar  (mean) share_of_output_100 share_of_credit_100, over(ei_bin) bar(1, color(green%30)) bar(2, color(orange%30)) title("2017-2019", size(large)) ytitle("") plotregion(style(none)) graphregion(style(none))  ylab(0(10)40, nogrid labsize(large))    legend(position(1) ring(0) rows(2) region(lstyle(none)) label(1 "Output Density" ) label(2 "Credit Density") bmargin(small) size(large)) 
graph save  ${graphs}ei_bin_output_credit_share_last3_within.gph, replace
*graph export ${exports}ei_bin_output_credit_share_last3_within.pdf, as(pdf) replace	
 
 

restore





graph combine ${graphs}ei_bin_output_credit_share_first3_within.gph ${graphs}ei_bin_output_credit_share_last3_within.gph, row(1) iscale(1) imargin(zero)
graph export ${exports}ei_bin_output_credit_share_within_combined.pdf, as(pdf) replace	



	
****************loop for all years*************************************************
use ${temp}forgraph_passive_active.dta, replace

capture drop lenergy_intensity_1
gen lenergy_intensity_1= log(energy_intensity_1)
capture drop relative_ei_indyear
local var "lenergy_intensity_1"

** collapse by industry to obtain the mean and sd of the industry sample 
capture drop _merge
foreach  v in `var'{
preserve	
collapse (mean) mean_`v' =`v' (sd) sd_`v'  = `v', by(ind2 year) 
save ${temp}collapse_`v', replace
restore
capture drop _merge mean_`v' sd_`v'
merge m:1 ind2 year using ${temp}collapse_`v'
sort ind2 year
gen relative_ei_indyear = (`v'-mean_`v')/sd_`v'
*drop if relative_ei_indyear == .
}
su  relative_ei_indyear, det



	
forvalues i= 2003(1)2019{
	
preserve

*quietly{


keep if year ==`i'

***split the firms  for every year into 5 bins based on benchmark values saved before

capture drop  ei_bin

gen  ei_bin = .

replace  ei_bin =1 if  relative_ei_indyear<=xxxxx &  relative_ei_indyear != .

replace  ei_bin =2 if relative_ei_indyear>xxxxx & relative_ei_indyear<=xxxxx & relative_ei_indyear != .

replace  ei_bin =3 if relative_ei_indyear>xxxxx & relative_ei_indyear<=xxxxx & relative_ei_indyear != .

replace  ei_bin =4 if relative_ei_indyear>xxxxx & relative_ei_indyear<=xxxxx & relative_ei_indyear != .

replace  ei_bin = 5 if relative_ei_indyear>xxxxx & relative_ei_indyear != . 

tab  ei_bin



capture drop vtv_million
gen  vtv_million = vtv/1000000

 

***total share of total output in each group
capture drop bin_output 
bysort ei_bin: egen bin_output = total(vtv_million) if  ei_bin != .


capture drop total_output
egen total_output =  total(vtv_million) if  ei_bin != .

capture drop share_of_output 
gen share_of_output = bin_output/total_output if  ei_bin != .


***total share of total credit in each group
capture drop account_balance_bill
gen  account_balance_bill= account_balance/1000000000


capture drop bin_credit
bysort ei_bin: egen bin_credit = total(account_balance_bill) if  ei_bin != .
tab  bin_credit

capture drop total_credit
egen total_credit =  total(account_balance_bill) if  ei_bin != .

capture drop share_of_credit
gen share_of_credit = bin_credit/total_credit  if  ei_bin != .


save ${temp}ei_bin_`i', replace


use ${temp}ei_bin_`i', replace

egen unique_firm = tag(firmid)


collapse (mean) bin_output (mean) total_output (mean) share_of_output (mean) bin_credit (mean) total_credit (mean) share_of_credit (sum) unique_firm (mean) relative_ei_indyear, by(ei_bin)

capture drop share_of_output_100 share_of_credit_100
gen  share_of_output_100= share_of_output*100
gen  share_of_credit_100= share_of_credit*100

save ${temp}forgraph_`i', replace


restore
}


forvalues i= 2003(1)2019{
	
use ${temp}forgraph_`i', replace

capture drop year 

gen year = `i'

drop if ei_bin == .

save ${temp}forgraph_`i', replace
}


use ${temp}forgraph_2003, replace

forvalues i= 2004(1)2019{
	
append using  ${temp}forgraph_`i'

capture drop if ei_bin == .
}

*capture drop  energy_intensity_1 unique_firm share_of_credit share_of_output

capture drop share_credit_output 

gen share_credit_output =share_of_credit_100/share_of_output_100*100


capture drop share_output_credit

gen share_output_credit= share_of_output_100/share_of_credit_100*100

***label the variables
label var ei_bin "firm RELATIVE energy intensity bins based on the first 3 years, bin 1 (lowest), bin 5 (highest)"

label var bin_output "total output (real value added) per bin in millions DKK"

label var total_output "total output (real value added) for all 5 bins in millions DKK"

label var bin_credit "total credit per bin in billions DKK"

label var total_credit "total credit for all 5 bins in billions DKK"

label var share_of_output "bin output as a share of total output (bin_output/total_output)"

label var share_of_credit "bin credit as a share of total credit (bin_credit/total_credit)"

label var unique_firm "the number of unique firms in each bin"

label var share_of_credit_100  "bin credit as a share of total credit in percent (bin_credit/total_credit*100)"

label var share_of_output_100  "bin output as a share of total output in percent (bin_output/total_output*100)"

label var share_credit_output  "share_of_credit_100/share_of_output_100*100"

label var share_output_credit  "share_of_output_100/share_of_credit*100"

label var relative_ei_indyear "relative energy intensity per bin"

save  ${exports}forgraph_table_2003_2009_5bins_within.dta, replace



**************************************************************************
***passive vs active allocation between industry
**************************************************************************
****split into 5 bins based on between emission intensity 

preserve

use ${data}transition_risk_v2.dta, replace
tsset ind2 year
capture drop emission_intensity

*deflator (statistik banken: pris112)
gen deflator=.
replace deflator=68 if year==1995
replace deflator=69.5 if year==1996
replace deflator=71 if year==1997
replace deflator=72.3 if year==1998
replace deflator=74.1 if year==1999
replace deflator=76.2 if year==2000
replace deflator=78 if year==2001
replace deflator=79.9 if year==2002
replace deflator=81.6 if year==2003
replace deflator=82.5 if year==2004
replace deflator=84 if year==2005
replace deflator=85.6 if year==2006
replace deflator=87.1 if year==2007
replace deflator=90.1 if year==2008
replace deflator=91.2 if year==2009
replace deflator=93.3 if year==2010
replace deflator=95.9 if year==2011
replace deflator=98.2 if year==2012
replace deflator=99 if year==2013
replace deflator=99.6 if year==2014
replace deflator=100 if year==2015
replace deflator=100.3 if year==2016
replace deflator=101.4 if year==2017
replace deflator=102.2 if year==2018
replace deflator=103 if year==2019
replace deflator = deflator/100


gen rva_detailed = gva_detailed/deflator 

gen emission_intensity=GHG_total/rva_detailed
label variable emission_intensity "GHG_total/rva_detailed"
su emission_intensity, det


save ${temp}transition_risk_v2.dta, replace



***calculate the benchmark (mean) for each bins and save the numbers for the benchmark

use  ${temp}transition_risk_v2.dta, replace
keep if year>=2003 & year<=2005
tab year

capture drop ei_bin
capture drop emission_intensity_100 
gen  emission_intensity_100 =emission_intensity*100
xtile ei_bin = emission_intensity_100 if  emission_intensity_100 != ., nq(4) 
tab ei_bin

capture drop benchmark_ei_bin 
bysort ei_bin: egen benchmark_ei_bin = mean(emission_intensity_100)

 
bysort benchmark_ei_bin: keep if _n==1
keep benchmark_ei_bin 
drop if benchmark_ei_bin == .
save  ${temp}benchmark_ei_bin_between, replace

restore 




****restore credit data and merge with industry emission
use ${temp}forgraph_passive_active.dta, replace
capture drop _merge
capture drop emission_intensity
merge m:1 ind2 year using ${temp}transition_risk_v2.dta
drop if _merge ==2



********plots for first 3 years
preserve
gen  emission_intensity_100 =emission_intensity*100

keep if year <=2005

***split the firms  for every year into 5 bins based on benchmark values saved before

capture drop  ei_bin

gen  ei_bin = .

replace  ei_bin =1 if  emission_intensity_100<=xxxxx & emission_intensity_100 != .

replace  ei_bin =2 if emission_intensity_100>xxxxx  & emission_intensity_100<=xxxxx & emission_intensity_100 != .

replace  ei_bin =3 if emission_intensity_100>xxxxx  & emission_intensity_100<=xxxxx & emission_intensity_100 != .

replace  ei_bin =4 if emission_intensity_100>xxxxx  & emission_intensity_100<=xxxxx  & emission_intensity_100 != .

replace  ei_bin = 5 if emission_intensity_100>xxxxx & emission_intensity_100 != . 

tab  ei_bin



capture drop vtv_million
gen  vtv_million = vtv/1000000

***sum of total output 
tabstat vtv_million, by(ei_bin) s(sum n) 


***sum of total credit
tabstat account_balance, by(ei_bin) s(sum n) 

***total share of total output in each group
capture drop bin_output 
bysort ei_bin: egen bin_output = total(vtv_million) if  ei_bin != .
tab  bin_output 

capture drop total_output
egen total_output =  total(vtv_million) if  ei_bin != .

capture drop share_of_output 
gen share_of_output = bin_output/total_output if  ei_bin != .

*}

su energy_intensity_1, det
tabstat  vtv_million, by(ei_bin) s(sum n)
tabstat  share_of_output, by(ei_bin) s(mean)



***share of total credit in each group
capture drop account_balance_bill
gen  account_balance_bill= account_balance/1000000000


capture drop bin_credit
bysort ei_bin: egen bin_credit = total(account_balance_bill) if  ei_bin != .
tab  bin_credit

capture drop total_credit
egen total_credit =  total(account_balance_bill) if  ei_bin != .

capture drop share_of_credit
gen share_of_credit = bin_credit/total_credit  if  ei_bin != .


save ${temp}ei_bin_first3, replace


use ${temp}ei_bin_first3, replace

egen unique_firm = tag(firmid)


collapse (mean) bin_output (mean) total_output (mean) share_of_output (mean) bin_credit (mean) total_credit (mean) share_of_credit (sum) unique_firm (mean) energy_intensity_1 , by(ei_bin)

capture drop share_of_output_100 share_of_credit_100
gen  share_of_output_100= share_of_output*100
gen  share_of_credit_100= share_of_credit*100

label var share_of_credit_100 "Credit Density"
label var share_of_output_100 "Output Density"

save ${temp}forgraph_first3, replace

su unique_firm

use ${temp}forgraph_first3, replace
graph bar  (mean) share_of_output_100 share_of_credit_100, over(ei_bin) bar(1, color(green%30)) bar(2, color(orange%30)) title("2003-2005", size(large)) ytitle("") plotregion(style(none)) graphregion(style(none))  ylab(0(10)60, nogrid labsize(large))    legend(off)
graph save  ${graphs}ei_bin_output_credit_share_first3_between.gph, replace
*graph export ${exports}ei_bin_output_credit_share_first3_across.pdf, as(pdf) replace	

restore








******plots for last 3 years
preserve
gen  emission_intensity_100 =emission_intensity*100
	
keep if year >=2017

***split the firms  for every year into 5 bins based on benchmark values saved before

capture drop  ei_bin

gen  ei_bin = .

replace  ei_bin =1 if  emission_intensity_100<=xxxxx & emission_intensity_100 != .

replace  ei_bin =2 if emission_intensity_100>xxxxx  & emission_intensity_100<=xxxxx & emission_intensity_100 != .

replace  ei_bin =3 if emission_intensity_100>xxxxx  & emission_intensity_100<=xxxxx & emission_intensity_100 != .

replace  ei_bin =4 if emission_intensity_100>xxxxx  & emission_intensity_100<=xxxxx  & emission_intensity_100 != .

replace  ei_bin = 5 if emission_intensity_100>xxxxx & emission_intensity_100 != . 


tab  ei_bin




capture drop vtv_million
gen  vtv_million = vtv/1000000

***sum of total output 
tabstat vtv_million, by(ei_bin) s(sum n) 


***sum of total credit
tabstat account_balance, by(ei_bin) s(sum n) 

***total share of total output in each group
capture drop bin_output 
bysort ei_bin: egen bin_output = total(vtv_million) if  ei_bin != .
tab  bin_output 

capture drop total_output
egen total_output =  total(vtv_million) if  ei_bin != .

capture drop share_of_output 
gen share_of_output = bin_output/total_output if  ei_bin != .

*}

su energy_intensity_1, det
tabstat  vtv_million, by(ei_bin) s(sum n)
tabstat  share_of_output, by(ei_bin) s(mean)



***share of total credit in each group
capture drop account_balance_bill
gen  account_balance_bill= account_balance/1000000000


capture drop bin_credit
bysort ei_bin: egen bin_credit = total(account_balance_bill) if  ei_bin != .
tab  bin_credit

capture drop total_credit
egen total_credit =  total(account_balance_bill) if  ei_bin != .

capture drop share_of_credit
gen share_of_credit = bin_credit/total_credit  if  ei_bin != .


save ${temp}ei_bin_last3, replace


use ${temp}ei_bin_last3, replace

egen unique_firm = tag(firmid)


collapse (mean) bin_output (mean) total_output (mean) share_of_output (mean) bin_credit (mean) total_credit (mean) share_of_credit (sum) unique_firm (mean) energy_intensity_1 , by(ei_bin)

capture drop share_of_output_100 share_of_credit_100
gen  share_of_output_100= share_of_output*100
gen  share_of_credit_100= share_of_credit*100

label var share_of_credit_100 "Credit Density"
label var share_of_output_100 "Output Density"

save ${temp}forgraph_last3, replace

su unique_firm

use ${temp}forgraph_last3, replace
graph bar  (mean) share_of_output_100 share_of_credit_100, over(ei_bin) bar(1, color(green%30)) bar(2, color(orange%30)) title("2017-2019", size(large)) ytitle("") plotregion(style(none)) graphregion(style(none))  ylab(0(10)60, nogrid labsize(large))    legend(position(1) ring(0) rows(2) region(lstyle(none)) label(1 "Output Density" ) label(2 "Credit Density") bmargin(small) size(large)) 
graph save  ${graphs}ei_bin_output_credit_share_last3_between.gph, replace
*graph export ${exports}ei_bin_output_credit_share_last3_within.pdf, as(pdf) replace	
 
 

restore




graph combine ${graphs}ei_bin_output_credit_share_first3_between.gph ${graphs}ei_bin_output_credit_share_last3_between.gph, row(1) iscale(1) imargin(zero)
graph export ${exports}ei_bin_output_credit_share_between_combined.pdf, as(pdf) replace	



log close








