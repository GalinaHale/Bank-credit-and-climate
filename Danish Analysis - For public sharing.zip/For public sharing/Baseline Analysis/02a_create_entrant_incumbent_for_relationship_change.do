********************************************************************************
* Prepare incumbent and entrant indicators for relationship analysis
* run "${do}Baseline Analysis/02a_create_entrant_incumbent_for_relationship_change.do"
********************************************************************************
/*
* run "${do}Baseline Analysis/02a_create_entrant_incumbent_for_relationship_change.do"
/*
INPUT:
    ${data}firm_credit_full.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${temp}incumbent.dta
        -> Intermediate dataset
    ${temp}new_entrants.dta
        -> Intermediate dataset

LOG:
    ${logs}create_entrant_incumbent_for_relationship_change.log

DEPENDENCIES / NOTES:
    Run BEFORE the relationship baseline and Online Appendix C.14
*/
*/

capture log close
log using ${logs}create_entrant_incumbent_for_relationship_change.log, replace



****isolate the sample to incumbent firms only during the last 10 years
use ${data}firm_credit_full.dta, replace


**keep if firm size is at least 2 to remove self-employed
keep if f_size >=2

distinct cvrnr cvrnr_b year

sort cvrnr cvrnr_b year

collapse (mean) assets  (mean) kene (sum) account_balance, by(cvrnr year)

save ${temp}temp.dta, replace

keep if year>=2009
bysort cvrnr: gen duration=_N 
keep cvrnr  year duration

capture drop duration_max
bysort cvrnr: egen duration_max= max(duration)
tab duration_max

capture drop incumbent
gen  incumbent= (duration_max>10)
replace incumbent=. if duration_max ==.
tab incumbent


keep cvrnr year incumbent
sort cvrnr year
duplicates drop cvrnr year, force
save ${temp}incumbent.dta, replace




****isolate the sample to new firms entrants during entire sample
use ${temp}temp.dta, replace
capture drop  start_year
gen start_year = year if assets !=.
tab start_year
replace start_year = -9999 if start_year==.

capture drop start_year_min
bysort cvrnr: egen start_year_min= min(start_year)
replace start_year_min = . if start_year_min==-9999
tab start_year_min

capture drop new_entrants
gen new_entrants = (start_year_min != 2003)
replace new_entrants =. if  start_year_min ==.
tab new_entrants

keep cvrnr year new_entrants
sort cvrnr year

duplicates drop cvrnr year, force
save ${temp}new_entrants.dta, replace

log close
