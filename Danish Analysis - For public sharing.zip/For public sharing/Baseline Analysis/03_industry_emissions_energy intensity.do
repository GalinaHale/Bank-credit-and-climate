********************************************************************************
* Industry emissions and energy intensity: correlations and trends
* run "${do}Baseline Analysis/03_industry_emissions_energy intensity.do"

********************************************************************************
/*
INPUT:
    ${data}ind_energy_intensity_full.dta
    ${data}transition_risk_v2.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}ind_energy_emission_correlation.txt
        -> Appendix Table B.11
    ${exports}ind_energy_emission_correlation_after2016.txt
        -> Post-2016 comparison; 
    ${data}ind_emission_energy_intensity_full.dta
        -> Intermediate data required by G.1
    ${exports}figure_ei_egi_trend.pdf
        -> Figure 5

LOG:
    ${logs}use_data_reg_revision.log
*/


capture log close
log using ${logs}use_data_reg_revision.log, replace
set scheme stcolor




 
***********************************************************************
*****Comment 1: Correlation between ind_energy_intensity and emission intensity
use ${data}ind_energy_intensity_full.dta, replace 
bysort ind2 year: egen n_firms_indyr = nvals(firmid)
keep if n_firms_indyr >=20


bysort ind2 year: egen max_emission_share = max(firmid)
corr ind_energy_intensity emission_intensity

corr l_ind_emission_intensity l_ind_energy_intensity



collapse ind_energy_intensity emission_intensity (count) n_obs =firmid, by(ind2 year)
save ${temp}emission_energy_intensity_by_ind.dta, replace


use ${temp}emission_energy_intensity_by_ind.dta, replace

xtset ind2 year

***Regression tables

reg  emission_intensity ind_energy_intensity
estimates store model1

reghdfe   emission_intensity ind_energy_intensity, absorb(year)
estimates store model2


reghdfe   emission_intensity ind_energy_intensity, absorb(ind2)
estimates store model3


reghdfe   emission_intensity ind_energy_intensity, absorb(ind2 year)
estimates store model4

esttab   model1 model2 model3 model4 using ${exports}ind_energy_emission_correlation.txt, replace style(tab) cells(b(star fmt(%9.3f)) se(par fmt(%9.3f))) label stats(r2 N, fmt(%9.3f %9.0fc) labels( "R-sq" "N" )) starlevels(* 0.10 ** 0.05 *** 0.01)   keep(ind_energy_intensity)




*****Comment 2: imputation of firm energy consumption from 2016
use ${temp}emission_energy_intensity_by_ind.dta, replace
corr ind_energy_intensity emission_intensity if year>=2016


reg  emission_intensity ind_energy_intensity if year>=2016
estimates store model1

reghdfe   emission_intensity ind_energy_intensity if year>=2016, absorb(year)
estimates store model2


reghdfe   emission_intensity ind_energy_intensity if year>=2016, absorb(ind2)
estimates store model3


reghdfe   emission_intensity ind_energy_intensity if year>=2016, absorb(ind2 year)
estimates store model4

esttab   model1 model2 model3 model4 using ${exports}ind_energy_emission_correlation_after2016.txt, replace style(tab) cells(b(star fmt(%9.3f)) se(par fmt(%9.3f))) label stats(r2 N, fmt(%9.3f %9.0fc) labels( "R-sq" "N" )) starlevels(* 0.10 ** 0.05 *** 0.01)   keep(ind_energy_intensity)


***trend of industry emission and energy intensity
**prepare the data
use ${data}ind_energy_intensity_full.dta, replace
merge m:1 ind2 year using ${data}transition_risk_v2.dta
drop if _merge ==2
drop _merge
save ${data}ind_emission_energy_intensity_full.dta, replace

*trend of industry emission and energy intensity
use ${data}ind_emission_energy_intensity_full.dta, replace

bysort year: egen ave_ei=mean(emission_intensity) 
bysort year: egen ave_egi=mean(ind_energy_intensity)

gen energy_con_int = EnergyCon_t/rva_detailed  
bysort year: egen ave_egi_actual=mean(energy_con_int)


egen tag=tag(year)

*Use 2016 as base year
sum ave_egi if year==2016
local base1 =r(mean)

gen ave_egi_index =100*ave_egi/`base1'

sum ave_ei if year==2016
local base2 = r(mean)

gen ave_ei_index =100*ave_ei/`base2'


sum ave_egi_actual if year==2016
local base3 = r(mean)

gen ave_egi_actual_index =100*ave_egi_actual/`base3'


twoway (line ave_ei_index year if tag & year>2002) (line ave_egi_index year if tag & year>2002) (line ave_egi_actual_index year if tag & year>2002), xtitle("Year") ytitle("Average intensity index (2016=100)") xlabel(2003(2)2020) ylabel(40(20)160) legend(order(1 "Actual industry emission intensity" 2 "Firm aggregated energy intensity" 3 "Actual industry energy intensity") position(6) cols(2)) xline(2016, lpattern(line))

graph export ${exports}figure_ei_egi_trend.pdf, as(pdf) replace	
 
log close



