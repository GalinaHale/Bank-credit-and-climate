********************************************************************************
* Fill missing same-year firm covariates on the balanced panel
* run "${do}Baseline Analysis/02b_patch_balanced_covariates.do"

********************************************************************************
/*
INPUT:
    ${data}firm_credit_full.dta
    ${data}balanced_firm_credit_full.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${data}balanced_firm_credit_full_covfix.dta
        
LOG:
    ${logs}balanced_covariates_covfix.log

DEPENDENCIES / NOTES:
    Run AFTER data setup and BEFORE the relationship baseline and C.14.
    Fills missing covariates from the same firm-year only; no loan changes.
*/


capture log close
log using "${logs}balanced_covariates_covfix.log", replace

local covars f_size f_age ind2 jur_bel_region_kode ///
    lassets fixed_ratio leverage_ratio roa kene vtv

use "${data}firm_credit_full.dta", clear
keep cvrnr year `covars'
duplicates drop
isid cvrnr year
tempfile firm_year_covariates
save `firm_year_covariates'

use "${data}balanced_firm_credit_full.dta", clear
isid cvrnr bankid year
local original_N = _N

* Update missing covariates only; stop if existing nonmissing values conflict.
merge m:1 cvrnr year using `firm_year_covariates', ///
    keepusing(`covars') update keep(1 3 4 5) gen(merge_firm_info)
tab merge_firm_info, missing
assert merge_firm_info != 5
assert _N == `original_N'
isid cvrnr bankid year
drop merge_firm_info

save "${data}balanced_firm_credit_full_covfix.dta", replace
log close
