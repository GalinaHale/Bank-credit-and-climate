********************************************************************************
* Main-text Figure 16 and Online Appendix Table M.8: bank loan shares
* run "${do}Online Appendix/08_Figure16_Online_Appendix_M8_bank_ind_level_analysis.do"
********************************************************************************
/*
INPUT:
    ${data}firm_credit_full.dta
    ${temp}kene_ma_file.dta
    ${temp}relative_ei
    ${data}ind_energy_intensity_full.dta
    ${temp}transition_risk_v2.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}bank_share_green_within_full_prepost_Fig16M8.txt
        -> Online Appendix Table M.8
    ${exports}figure_bank_green_industry_year_fullsample_Fig16M8.pdf
        -> Main-text Figure 16: green-industry panel
    ${exports}figure_bank_brown_industry_year_fullsample_Fig16M8.pdf
        -> Main-text Figure 16: dirty-industry panel
    ${tables}bank_share_industry_year_fullsample_Fig16M8.txt
        -> Supporting year coefficients for Figure 16 

LOG:
    ${logs}use_data_regs_bank_ind_share_full_prepost_Fig16M8.log
*/


capture log close
log using ${logs}use_data_regs_bank_ind_share_full_prepost_Fig16M8.log, replace
set scheme lean1

global cntrl1_l "L.lassets_w L.fixed_ratio_w L.leverage_ratio_w   L.roa_w" 
global cntrl1 "lassets_w  fixed_ratio_w leverage_ratio_w   roa_w" 



use  ${data}firm_credit_full.dta, replace


* Same sample rule and timing as the current baseline; missing size is retained.
keep if f_size >=2
sort cvrnr cvrnr_b year
distinct cvrnr cvrnr_b year


**********************further data cleaning before regression***********************
**generate dummy bank_id for NEVER firms
destring cvrnr, gen(firmid)
destring cvrnr_b, gen(bankid)

replace bankid =0 if missing(bankid)


***generate firm bank id
capture drop id
egen id = group(firmid  bankid)
format id %19.9g



***generate bank year fixed dummies
capture drop bank_year 
egen bank_year = group(bankid year)
format bank_year %19.9g


****construct industry fixed dummies 
replace ind2 =0 if missing(ind2)
capture drop ind2year 
egen ind2year= group(ind2 year)
format   ind2year %19.9g



************generate loan outcome vars*********

**fill in zeros and compute log(balance) as l_balance
**fill in zeros 
capture drop nonmissing_balance 
gen nonmissing_balance = account_balance
replace nonmissing_balance=0 if missing(account_balance)
**log of account balance as l_balance
capture drop l_balance 
gen l_balance= 0
replace l_balance= log(nonmissing_balance) if  nonmissing_balance>0



**log change as growth in 100%
sort firmid bankid year
xtset id year
capture drop l_loan_change
gen l_loan_change = l_balance-l.l_balance  
replace l_loan_change=l_loan_change*100



***alternative definitions: gen loan growth using symmetric growth by taking into account 0
capture drop loan_change
gen loan_change = nonmissing_balance-l.nonmissing_balance

capture drop loan_growth
gen loan_growth = loan_change/(0.5*nonmissing_balance+0.5*l.nonmissing_balance)*100

su loan_growth  l_loan_change l_balance, det



***generate extensive margin variables
capture drop ext_l_loan 
gen ext_l_loan = 0
replace ext_l_loan =1 if loan_change>0 & loan_change !=.
tab ext_l_loan 


***fill in zeros for missing vars of loan outcomes
foreach i of varlist  l_balance loan_growth ext_l_loan l_loan_change{
	replace  `i' =0 if missing(`i') 
}


***winsorizing outliers for controls
winsor2  lassets  fixed_ratio leverage_ratio, cuts(1 99) 
winsor2  roa, cuts(1 99) 


***scale leverage ratio by 100 // ration in percentage points
replace leverage_ratio_w = leverage_ratio_w*100
replace roa_w = roa_w*100
replace fixed_ratio_w =  fixed_ratio_w*100


***merge to energy intensity variables
capture drop  kene
capture drop kene_m3 
capture drop energy_intensity_1
capture drop lenergy_intensity_1 
capture drop change_ei
capture drop  post_paris 
capture drop post_paris_lenergy_intensity_1
capture drop  post_paris_change_ei

capture drop  pre_paris 
capture drop pre_paris_lenergy_intensity_1
capture drop  pre_paris_change_ei

merge m:1 firmid year using ${temp}kene_ma_file.dta
capture drop _merge


****merge to obtain relative energy intensity variables**********

capture drop  post_relative_ei_indyear
capture drop  pre_relative_ei_indyear

capture drop change_relative_ei_indyear
capture drop pre_change_relative_ei_indyear
capture drop post_change_relative_ei_indyear

merge m:1 firmid year using ${temp}relative_ei
capture drop _merge


****merge to obtain industry energy/emission intensity variables**********

capture drop ind_energy_intensity
capture drop  l_ind_energy_intensity 
capture drop pre_ind_energy_intensity
capture drop post_ind_energy_intensity  
capture drop change_ind_energy_int 
capture drop pre_change_ind_energy_int
capture drop  post_change_ind_energy_int

capture drop pre_ind_emission_intensity 
capture drop post_ind_emission_intensity  
capture drop change_ind_emission_int 
capture drop pre_change_ind_emission_int 
capture drop post_change_ind_emission_int

capture drop rva_growth

merge m:1 firmid year using ${data}ind_energy_intensity_full.dta

capture drop _merge

xtset id year

global cntrl_ind_f "L.lassets_w  L.fixed_ratio_w L.leverage_ratio_w   L.roa_w   rva_growth" 


****tssset the data
capture program drop meany
program def meany, rclass
args var spec
sum `var' if e(sample), mean
estadd scalar Meany=r(mean)
end

tsset id year


******************within industry analysis**************************
****bank industry level green firm share shift
***aggregate account balance at bank industry year level
bysort cvrnr_b ind2 year: egen account_balance_bjt = total(account_balance)
***define green firm as bottom firm level relative energy intensity

su  relative_ei_indyear, det
gen green_firm = ( relative_ei_indyear<= r(p25))
tab  green_firm 


**aggregate account balance for green firm at bank industry year level
bysort cvrnr_b ind2 year: egen account_balance_green_bjt = total(account_balance*(green_firm==1))

***green share
gen green_firm_bjt = account_balance_green_bjt/account_balance_bjt


***brown share
su  relative_ei_indyear, det
gen brown_firm = (relative_ei_indyear>= r(p75)) if relative_ei_indyear!=.
tab  brown_firm 

bysort cvrnr_b ind2 year: egen account_balance_brown_bjt = total(account_balance*(brown_firm==1))
gen brown_firm_bjt = account_balance_brown_bjt/account_balance_bjt



****tssset the data
capture program drop meany
program def meany, rclass
args var spec
sum `var' if e(sample), mean
estadd scalar Meany=r(mean)
end

tsset id year




reghdfe green_firm_bjt  pre_ind_emission_intensity pre_ind_energy_intensity  post_ind_emission_intensity post_ind_energy_intensity  rva_growth,   absorb(year cvrnr_b ind2)   cluster(ind2)
estimates store model1
meany green_firm_bjt  model1



reghdfe green_firm_bjt  pre_change_ind_emission_int pre_change_ind_energy_int post_change_ind_emission_int post_change_ind_energy_int  rva_growth,    absorb(year cvrnr_b ind2)   cluster(ind2)
estimates store model2
meany  green_firm_bjt  model2


reghdfe green_firm_bjt   pre_ind_emission_intensity pre_ind_energy_intensity    pre_change_ind_emission_int pre_change_ind_energy_int post_ind_emission_intensity post_ind_energy_intensity post_change_ind_emission_int post_change_ind_energy_int  rva_growth,    absorb(year cvrnr_b ind2)   cluster(ind2)
estimates store model3
meany  green_firm_bjt  model3


esttab   model1  model2 model3  using ${exports}bank_share_green_within_full_prepost_Fig16M8.txt, replace style(tab) cells(b(star fmt(%9.3f)) se(par fmt(%9.3f))) label stats( r2 N, fmt( %9.3f %9.0fc) labels( "R-sq" "N" )) starlevels(* 0.10 ** 0.05 *** 0.01)   keep(pre_ind_emission_intensity pre_ind_energy_intensity    pre_change_ind_emission_int pre_change_ind_energy_int post_ind_emission_intensity post_ind_energy_intensity post_change_ind_emission_int post_change_ind_energy_int  rva_growth) order(pre_ind_emission_intensity pre_ind_energy_intensity    pre_change_ind_emission_int pre_change_ind_energy_int post_ind_emission_intensity post_ind_energy_intensity post_change_ind_emission_int post_change_ind_energy_int  rva_growth) 







************** between industry analysis at bank level**************************
* Figure 16: pooled industry thresholds from the current baseline.
preserve
use "${temp}transition_risk_v2.dta", clear
keep ind2 year emission_intensity
drop if missing(ind2) | missing(year)
duplicates drop
isid ind2 year
quietly summarize emission_intensity, detail
assert r(N) > 0
local p25 = r(p25)
local p75 = r(p75)
gen byte green_industry = emission_intensity <= `p25' if !missing(emission_intensity)
gen byte brown_industry = emission_intensity >= `p75' if !missing(emission_intensity)
keep ind2 year green_industry brown_industry
tempfile industry_groups
save `industry_groups'
restore

* Rebuild bank-year shares independently of the preceding M8 regressions.
use "${data}firm_credit_full.dta", clear
keep if f_size >= 2
drop if missing(cvrnr_b)
isid cvrnr cvrnr_b year
merge m:1 ind2 year using `industry_groups', keep(master match)
tab _merge, missing
drop _merge


***aggregate account balance at bank  year level
capture drop account_balance_bt 
bysort cvrnr_b year: egen account_balance_bt = total(account_balance)


**aggregate account balance for green firm at bank industry year level
bysort cvrnr_b year: egen account_balance_green_bt = total(account_balance*(green_industry==1))

***green share
gen green_industry_bt = account_balance_green_bt/account_balance_bt


***brown share
bysort cvrnr_b year: egen account_balance_brown_bt = total(account_balance*(brown_industry==1))
gen brown_industry_bt = account_balance_brown_bt/account_balance_bt


***regression
reghdfe green_industry_bt  ib2015.year,  absorb(cvrnr_b)   cluster(cvrnr_b)
estimates store model1
meany  green_industry_bt  model1

***plot the coef

set scheme plotplainblind
coefplot, keep(*.year) vertical ///
 xlabel(1 "2003" 2 "2004" 3 "2005" 4 "2006" 5 "2007" 6 "2008" 7 "2009" 8 "2010" 9 "2011" 10 "2012" 11 "2013" 12 "2014" 13 "2016" 14 "2017" 15 "2018" 16 "2019", angle(75) labsize(small)) ///
 yline(0, lcolor(gs8) lpattern(solid)) ///
  xline(12.5, lcolor(gs8) lpattern(dash)) ///
 ciopt(lcolor(blue%40)) ///
 mcolor(navy) msymbol(o) msize(small) ///
 ytitle("Coef estimates") 
 
graph save  ${graphs}figure_bank_green_industry_year_fullsample_Fig16M8.gph, replace
graph export ${exports}figure_bank_green_industry_year_fullsample_Fig16M8.pdf, as(pdf) replace	  




***brown industry share
reghdfe brown_industry_bt  ib2015.year,  absorb(cvrnr_b)   cluster(cvrnr_b)
estimates store model2
meany brown_industry_bt  model2

set scheme plotplainblind
coefplot, keep(*.year) vertical ///
 xlabel(1 "2003" 2 "2004" 3 "2005" 4 "2006" 5 "2007" 6 "2008" 7 "2009" 8 "2010" 9 "2011" 10 "2012" 11 "2013" 12 "2014" 13 "2016" 14 "2017" 15 "2018" 16 "2019", angle(75) labsize(small)) ///
 yline(0, lcolor(gs8) lpattern(solid)) ///
  xline(12.5, lcolor(gs8) lpattern(dash)) ///
 ciopt(lcolor(blue%40)) ///
 mcolor(navy) msymbol(o) msize(small) ///
 ytitle("Coef estimates") 
 
graph save  ${graphs}figure_bank_brown_industry_year_fullsample_Fig16M8.gph, replace
graph export ${exports}figure_bank_brown_industry_year_fullsample_Fig16M8.pdf, as(pdf) replace	  


esttab   model1 model2 using ${tables}bank_share_industry_year_fullsample_Fig16M8.txt, replace style(tab) cells(b(star fmt(%9.3f)) se(par fmt(%9.3f))) label stats( r2 N, fmt( %9.3f %9.0fc) labels( "R-sq" "N" )) starlevels(* 0.10 ** 0.05 *** 0.01)   keep(*.year) order(*.year) 






log close



