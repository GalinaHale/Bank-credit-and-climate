********************************************************************************
* Online Appendix Table G.1: alternative post-2016 energy imputation
* run "${do}Online Appendix/05_Online_Appendix_G1_alternative_energy_imputation.do"

********************************************************************************
/*
INPUT:
    ${data}ind_emission_energy_intensity_full.dta
    ${data}firm_credit_full.dta
    ${data}transition_risk_v2.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}between_industry_analysis1_fullsample_prepost_lst_altEI_G1.txt
        -> Online Appendix Table G.1

LOG:
    ${logs}use_data_reg_revision_kene_imputation_G1.log

*/


capture log close
log using ${logs}use_data_reg_revision_kene_imputation_G1.log, replace
set scheme lean1



 
***Robustness: allocate 2017-2019 proportionately to 2016 shares
***1. compute each firms share of industry total in 2016
use ${data}ind_emission_energy_intensity_full.dta, clear
isid firmid year
confirm variable kene ind2 EnergyCon_t
**industry totals
bysort ind2: egen ind_total_2016 = total(kene) if year==2016

* firm 2016 values
gen kene_2016 = kene if year==2016

* carry forward within firm
bysort firmid: egen firm_kene_2016= max(kene_2016)

* carry forward industry totals
bysort ind2: egen industry_kene_2016 = max(ind_total_2016)

* firm share within industry
gen share_2016 = firm_kene_2016/industry_kene_2016


***2. allocate post 2016 totals
gen kene_allocated =.

replace kene_allocated = share_2016*EnergyCon_t/100 if year>=2017 & year <=2019

***3 keep original values pre-2017
replace kene_allocated = kene if year <=2016

***4 validation check
bysort ind2 year: egen check_total = total(kene_allocated)

corr check_total EnergyCon_t if year>=2017

tabstat kene kene_allocated, by(year)

keep firmid year kene_allocated

save  ${temp}kene_allocated_full_G1.dta, replace






**************Rerun the full sample regression *********************
**************Rerun the full sample regression *********************
**************Rerun the full sample regression *********************
***use alternative measure of energy consumption (kene) after 2016

**Prepare the data 



global cntrl1_l "lag_lassets_w lag_fixed_ratio_w lag_leverage_ratio_w lag_roa_w" 
global cntrl1 "lassets_w  fixed_ratio_w leverage_ratio_w   roa_w" 



use  ${data}firm_credit_full.dta, clear

* Same sample rule and timing as the current baseline; missing size is retained.
keep if f_size >=2
sort cvrnr cvrnr_b year

**********************further data cleaning before regression***********************
**generate dummy bank_id for NEVER firms
destring cvrnr, gen(firmid)
destring cvrnr_b, gen(bankid)

replace bankid =0 if missing(bankid)


***generate firm bank id
capture drop id
egen id = group(firmid  bankid)
format id %19.9g
distinct id  

***generate bank year fixed dummies
capture drop bank_year
egen bank_year = group(bankid year)
format bank_year %19.9g
distinct bank_year  

****construct industry fixed dummies 
replace ind2 =0 if missing(ind2)
capture drop ind2year
egen ind2year= group(ind2 year)
format   ind2year %19.9g


************generate loan outcome vars*********

**fill in zeros and compute log(balance) as l_balance
**fill in zeros 
capture drop nonmissing_balance
gen nonmissing_balance = account_balance
replace nonmissing_balance=0 if missing(account_balance)
**log of account balance as l_balance
capture drop l_balance
gen l_balance= 0
replace l_balance= log(nonmissing_balance) if  nonmissing_balance>0



**log change as growth in 100%
sort firmid bankid year
xtset id year
capture drop l_loan_change
gen l_loan_change = l_balance-l.l_balance  
replace l_loan_change=l_loan_change*100



***alternative definitions: gen loan growth using symmetric growth by taking into account 0
capture drop loan_change
gen loan_change = nonmissing_balance-l.nonmissing_balance

capture drop loan_growth
gen loan_growth = loan_change/(0.5*nonmissing_balance+0.5*l.nonmissing_balance)*100

su loan_growth  l_loan_change l_balance, det



***generate extensive margin variables
capture drop ext_l_loan
gen ext_l_loan = 0
replace ext_l_loan =1 if loan_change>0 & loan_change !=.
tab ext_l_loan 


***fill in zeros for missing vars of loan outcomes
foreach i of varlist  l_balance loan_growth ext_l_loan l_loan_change{
	replace  `i' =0 if missing(`i') 
}


***winsorizing outliers for controls
winsor2  lassets  fixed_ratio leverage_ratio, cuts(1 99) 
winsor2  roa, cuts(1 99) 


***scale leverage ratio by 100 // ration in percentage points
replace leverage_ratio_w = leverage_ratio_w*100
replace roa_w = roa_w*100
replace fixed_ratio_w =  fixed_ratio_w*100

***construct firm-level lags using firm-year panel

preserve

keep firmid year lassets_w  fixed_ratio_w leverage_ratio_w roa_w

duplicates drop
isid firmid year
xtset firmid year

foreach v in lassets_w  fixed_ratio_w leverage_ratio_w roa_w{
	gen lag_`v'=L.`v'
}

keep firmid year lag_*

save  ${temp}firm_controls_lag_G1.dta, replace
restore 

merge m:1 firmid year using ${temp}firm_controls_lag_G1.dta, keepusing(lag_lassets_w  lag_fixed_ratio_w lag_leverage_ratio_w lag_roa_w) assert(match) nogen

*restore firm-bank panel for loan outcomes

xtset id



************generate energy intensity variables with allocated kene*************
*** energy_intensity_1, lenergy_intensity_1, change of energy intensity
capture drop kene_allocated
merge m:1 firmid year using  ${temp}kene_allocated_full_G1.dta, keep(master match)
tab _merge, missing

capture drop _merge


preserve

keep firmid year kene kene_allocated vtv
duplicates drop
isid firmid year
xtset firmid year

capture drop energy_intensity_1
gen energy_intensity_1 = kene_allocated/(vtv/1000000) 
label var energy_intensity_1 "firm level energy purchase per million DKK value added:kene/(vtv/1000000)"

capture drop lenergy_intensity_1
gen lenergy_intensity_1= log(energy_intensity_1)

capture drop change_ei
gen change_ei= lenergy_intensity_1-L.lenergy_intensity_1



capture drop change_ei_nolog //for summary stats
gen change_ei_nolog= energy_intensity_1-L.energy_intensity_1

***generate post paris dummy and interactions
capture drop post_paris
gen post_paris = (year >2016)
tab post_paris

tsset firmid year
capture drop post_paris_lenergy_intensity_1
gen post_paris_lenergy_intensity_1 =post_paris*L.lenergy_intensity_1

capture drop post_paris_change_ei
gen post_paris_change_ei =post_paris*L.change_ei


***generate pre paris dummy and interactions
capture drop pre_paris
gen pre_paris = (year <=2016)
tab pre_paris

capture drop pre_paris_lenergy_intensity_1
gen pre_paris_lenergy_intensity_1 =pre_paris*L.lenergy_intensity_1

capture drop pre_paris_change_ei
gen pre_paris_change_ei =pre_paris*L.change_ei




save ${temp}kene_ma_file_G1.dta, replace
restore 

capture drop kene
capture drop kene_allocated
capture drop energy_intensity_1
capture drop lenergy_intensity_1
capture drop change_ei
capture drop post_paris
capture drop post_paris_lenergy_intensity_1
capture drop post_paris_change_ei
capture drop change_ei_nolog
capture drop pre_paris
capture drop pre_paris_lenergy_intensity_1
capture drop pre_paris_change_ei

merge m:1 firmid year using ${temp}kene_ma_file_G1.dta, assert(match)
capture drop _merge





**gen size groups
capture drop size_q
xtile size_q =lassets, nq(5)



* Construct industry inputs explicitly using the baseline definitions.
preserve
use ${data}transition_risk_v2.dta, clear
tsset ind2 year
capture drop emission_intensity

*deflator (statistik banken: pris112)
capture drop deflator
gen deflator=.
replace deflator=81.6 if year==2003
replace deflator=82.5 if year==2004
replace deflator=84 if year==2005
replace deflator=85.6 if year==2006
replace deflator=87.1 if year==2007
replace deflator=90.1 if year==2008
replace deflator=91.2 if year==2009
replace deflator=93.3 if year==2010
replace deflator=95.9 if year==2011
replace deflator=98.2 if year==2012
replace deflator=99 if year==2013
replace deflator=99.6 if year==2014
replace deflator=100 if year==2015
replace deflator=100.3 if year==2016
replace deflator=101.4 if year==2017
replace deflator=102.2 if year==2018
replace deflator=103 if year==2019
replace deflator = deflator/100


capture drop rva_detailed
gen rva_detailed = gva_detailed/deflator 

gen emission_intensity=GHG_total/rva_detailed
label variable emission_intensity "GHG_total/rva_detailed"
su emission_intensity, det



keep ind2 year rva_detailed emission_intensity

*drop if no valid industry-year keys

drop if missing(ind2) | missing(year)

isid ind2 year

duplicates drop
save ${temp}transition_risk_G1.dta, replace
restore

capture drop rva_detailed
capture drop emission_intensity
merge m:1 ind2 year using ${temp}transition_risk_G1.dta, keep(master match)
tab _merge, missing
drop _merge


******between industry analysis, include rva growth using LST FEs****************
***construct industry level energy intensity variables
capture drop ind_energy_intensity
capture drop ind_kene
capture drop l_ind_energy_intensity
capture drop emission_intensity_1000
preserve

collapse (mean) kene_allocated ind2 rva_detailed pre_paris post_paris emission_intensity, by(firmid year)

sort firmid year
isid firmid year


****generate industry energy intensity and its interactions
bysort ind2 year: egen ind_kene = sum(kene_allocated)   
replace ind_kene = ind_kene/1000    //convert to per dkk as  kene is in thousand

xtset firmid year

gen ind_energy_intensity= ind_kene/rva_detailed
label var  ind_energy_intensity "ind_kene/rva_detailed"
su ind_energy_intensity, det

capture drop l_ind_energy_intensity
gen l_ind_energy_intensity = log(ind_energy_intensity)

capture drop pre_ind_energy_intensity
gen pre_ind_energy_intensity = pre_paris*L.l_ind_energy_intensity 


capture drop post_ind_energy_intensity
gen post_ind_energy_intensity = post_paris*L.l_ind_energy_intensity 


capture drop change_ind_energy_int
gen  change_ind_energy_int= l_ind_energy_intensity-L.l_ind_energy_intensity
su change_ind_energy_int, det

capture drop change_ind_energy_int_nolog
gen  change_ind_energy_int_nolog= ind_energy_intensity-L.ind_energy_intensity

capture drop pre_change_ind_energy_int
gen pre_change_ind_energy_int= pre_paris*L.change_ind_energy_int


capture drop post_change_ind_energy_int
gen post_change_ind_energy_int= post_paris*L.change_ind_energy_int



****generate industry emission intensity and its interactions
capture drop emission_intensity_1000
gen emission_intensity_1000 = 1000*emission_intensity


capture drop l_ind_emission_intensity
gen l_ind_emission_intensity  = log(emission_intensity_1000)

capture drop pre_ind_emission_intensity
gen pre_ind_emission_intensity  = pre_paris*L.l_ind_emission_intensity  


capture drop post_ind_emission_intensity
gen post_ind_emission_intensity = post_paris*L.l_ind_emission_intensity 


capture drop change_ind_emission_int
gen  change_ind_emission_int= l_ind_emission_intensity-L.l_ind_emission_intensity 
su change_ind_emission_int, det

capture drop change_ind_emission_int_nolog
gen  change_ind_emission_int_nolog= emission_intensity_1000-L.emission_intensity_1000


capture drop pre_change_ind_emission_int
gen pre_change_ind_emission_int= pre_paris*L.change_ind_emission_int


capture drop post_change_ind_emission_int
gen post_change_ind_emission_int= post_paris*L.change_ind_emission_int



capture drop rva_growth
gen rva_growth = (rva_detailed-L.rva_detailed)/(0.5*rva_detailed+0.5*L.rva_detailed)
su rva_growth


save ${temp}ind_energy_intensity_G1.dta, replace

restore

capture drop ind_energy_intensity
capture drop l_ind_energy_intensity
capture drop pre_ind_energy_intensity
capture drop post_ind_energy_intensity
capture drop change_ind_energy_int
capture drop pre_change_ind_energy_int
capture drop post_change_ind_energy_int

capture drop pre_ind_emission_intensity
capture drop post_ind_emission_intensity
capture drop change_ind_emission_int
capture drop pre_change_ind_emission_int
capture drop post_change_ind_emission_int

capture drop change_ind_emission_int_nolog
capture drop change_ind_energy_int_nolog
capture drop rva_growth

merge m:1 firmid year using ${temp}ind_energy_intensity_G1.dta, assert(match)

capture drop _merge



********************************************************************************
*Online Appendix Table G
*Online Appendix Table G
*Online Appendix Table G

****tssset the data
capture program drop meany
program def meany, rclass
args var spec
sum `var' if e(sample), mean
estadd scalar Meany=r(mean)
end

tsset id year

global cntrl_ind_f "lag_lassets_w lag_fixed_ratio_w lag_leverage_ratio_w lag_roa_w rva_growth" 


**generate LST FEs
capture drop LST
egen LST = group(jur_bel_region_kode size_q year)


reghdfe l_balance pre_ind_emission_intensity pre_ind_energy_intensity    pre_change_ind_emission_int pre_change_ind_energy_int post_ind_emission_intensity post_ind_energy_intensity post_change_ind_emission_int post_change_ind_energy_int  $cntrl_ind_f,  absorb(cvrnr  bank_year ind2 LST)  cluster(ind2)
estimates store model7
meany l_balance   model7



reghdfe loan_growth  pre_ind_emission_intensity pre_ind_energy_intensity    pre_change_ind_emission_int pre_change_ind_energy_int post_ind_emission_intensity post_ind_energy_intensity post_change_ind_emission_int post_change_ind_energy_int  $cntrl_ind_f,  absorb(cvrnr  bank_year ind2 LST)  cluster(ind2)
estimates store model8
meany  loan_growth    model8



reghdfe ext_l_loan  pre_ind_emission_intensity pre_ind_energy_intensity    pre_change_ind_emission_int pre_change_ind_energy_int post_ind_emission_intensity post_ind_energy_intensity post_change_ind_emission_int post_change_ind_energy_int  $cntrl_ind_f,  absorb(cvrnr  bank_year ind2 LST)  cluster(ind2)
estimates store model9
meany ext_l_loan   model9



esttab   model7 model8 model9 using ${exports}between_industry_analysis1_fullsample_prepost_lst_altEI_G1.txt, replace style(tab) cells(b(star fmt(%9.3f)) se(par fmt(%9.3f))) label stats( r2 N, fmt( %9.3f %9.0fc) labels( "R-sq" "N" )) starlevels(* 0.10 ** 0.05 *** 0.01)   keep(pre_ind_emission_intensity pre_ind_energy_intensity    pre_change_ind_emission_int pre_change_ind_energy_int post_ind_emission_intensity post_ind_energy_intensity post_change_ind_emission_int post_change_ind_energy_int  $cntrl_ind_f) order(pre_ind_emission_intensity pre_ind_energy_intensity    pre_change_ind_emission_int pre_change_ind_energy_int post_ind_emission_intensity post_ind_energy_intensity post_change_ind_emission_int post_change_ind_energy_int  $cntrl_ind_f) 



****check the correlation between energy intensity and emission intensity

corr emission_intensity_1000 ind_energy_intensity
corr emission_intensity_1000 energy_intensity_1 ind_energy_intensity


**check vif 

reg l_balance pre_ind_emission_intensity pre_ind_energy_intensity    pre_change_ind_emission_int pre_change_ind_energy_int post_ind_emission_intensity post_ind_energy_intensity post_change_ind_emission_int post_change_ind_energy_int  $cntrl_ind_f
estat vif















log close




