********************************************************************************
* Online Appendix Tables E.11-E.14: firm-age controls
* run "${do}Online Appendix/03_Online_Appendix_E11_E14_firmage.do"

********************************************************************************
/*
INPUT:
    ${data}firm_credit_full.dta
    ${data}transition_risk_v2.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}within_industry_analysis_fullsample_prepost_ilst_age_E11E14.txt
        -> Online Appendix Table E.11
    ${exports}within_industry_analysis_fullsample_prepost_brown_ilst_age_E11E14.txt
        -> Online Appendix Table E.12
    ${exports}within_industry_analysis_fullsample_prepost_nonbrown_ilst_age_E11E14.txt
        -> Online Appendix Table E.13
    ${exports}between_industry_analysis1_fullsample_prepost_lst_age_E11E14.txt
        -> Online Appendix Table E.14

LOG:
    ${logs}use_data_reg_full_sample_prepost_ILST_age_E11E14.log

*/


capture log close
log using ${logs}use_data_reg_full_sample_prepost_ILST_age_E11E14.log, replace
set scheme lean1

global cntrl1_l "lag_lassets_w  lag_fixed_ratio_w lag_leverage_ratio_w lag_roa_w lag_age_above_median lag_age_observed" 



use  ${data}firm_credit_full.dta, replace

**keep if firm size is at least 2 to remove self-employed
keep if f_size >=2

sort cvrnr cvrnr_b year
distinct cvrnr cvrnr_b year

**********************further data cleaning before regression***********************
**generate dummy bank_id for NEVER firms
destring cvrnr, gen(firmid)
destring cvrnr_b, gen(bankid)

replace bankid =0 if missing(bankid)


***generate firm bank id
capture drop id
egen id = group(firmid  bankid)
format id %19.9g
distinct id 

***generate bank year fixed dummies
capture drop bank_year 
egen bank_year = group(bankid year)
format bank_year %19.9g
distinct bank_year 

****construct industry fixed dummies 
replace ind2 =0 if missing(ind2)
capture drop ind2year 
egen ind2year= group(ind2 year)
format   ind2year %19.9g


************generate loan outcome vars*********

**fill in zeros and compute log(balance) as l_balance
**fill in zeros 
capture drop nonmissing_balance 
gen nonmissing_balance = account_balance
replace nonmissing_balance=0 if missing(account_balance)
**log of account balance as l_balance
capture drop l_balance 
gen l_balance= 0
replace l_balance= log(nonmissing_balance) if  nonmissing_balance>0



**log change as growth in 100%
sort firmid bankid year
xtset id year
capture drop l_loan_change
gen l_loan_change = l_balance-l.l_balance  
replace l_loan_change=l_loan_change*100



***alternative definitions: gen loan growth using symmetric growth by taking into account 0
capture drop loan_change
gen loan_change = nonmissing_balance-l.nonmissing_balance

capture drop loan_growth
gen loan_growth = loan_change/(0.5*nonmissing_balance+0.5*l.nonmissing_balance)*100

su loan_growth  l_loan_change l_balance, det



***generate extensive margin variables
capture drop ext_l_loan 
gen ext_l_loan = 0
replace ext_l_loan =1 if loan_change>0 & loan_change !=.
tab ext_l_loan 


***fill in zeros for missing vars of loan outcomes
foreach i of varlist  l_balance loan_growth ext_l_loan l_loan_change{
	replace  `i' =0 if missing(`i') 
}


***winsorizing outliers for controls
winsor2  lassets  fixed_ratio leverage_ratio, cuts(1 99) 
winsor2  roa, cuts(1 99) 


***scale leverage ratio by 100 // ration in percentage points
replace leverage_ratio_w = leverage_ratio_w*100
replace roa_w = roa_w*100
replace fixed_ratio_w =  fixed_ratio_w*100

***construct firm-level lags using firm-year panel

preserve

keep firmid year lassets_w  fixed_ratio_w leverage_ratio_w roa_w f_age

duplicates drop
isid firmid year

* Define age dummies on the baseline firm-year universe.
summarize f_age if !missing(f_age), detail
assert r(N) > 0
local pooled_median_age = r(p50)
gen byte age_observed = !missing(f_age)
gen byte age_above_median = (f_age > `pooled_median_age') if age_observed
replace age_above_median = 0 if !age_observed

xtset firmid year

foreach v in lassets_w  fixed_ratio_w leverage_ratio_w roa_w age_above_median age_observed{
	gen lag_`v'=L.`v'
}

keep firmid year lag_*

save  ${temp}firm_controls_lag_E11E14.dta, replace
restore 

merge m:1 firmid year using ${temp}firm_controls_lag_E11E14.dta, keepusing(lag_lassets_w  lag_fixed_ratio_w lag_leverage_ratio_w lag_roa_w lag_age_above_median lag_age_observed) assert(match) nogen

*restore firm-bank panel for loan outcomes

xtset id year


************generate energy intensity variables**********************
*** energy_intensity_1, lenergy_intensity_1, change of energy intensity

***use moving average of energy consumption (kene) after 2016
preserve

collapse (first) kene vtv, by(firmid year)
xtset firmid year
tsegen kene_m3 = rowmean(L(0/4).kene)
replace kene = kene_m3 if year >2016 & missing(kene)

capture drop energy_intensity_1
gen energy_intensity_1 = kene/(vtv/1000000) 
label var energy_intensity_1 "firm level energy purchase per million DKK value added:kene/(vtv/1000000)"

capture drop lenergy_intensity_1
gen lenergy_intensity_1= log(energy_intensity_1)

capture drop change_ei
gen change_ei= lenergy_intensity_1-L.lenergy_intensity_1



capture drop change_ei_nolog //for summary stats
gen change_ei_nolog= energy_intensity_1-L.energy_intensity_1

***generate post paris dummy and interactions
capture drop post_paris
gen post_paris = (year >2016)
tab post_paris

tsset firmid year
capture drop post_paris_lenergy_intensity_1
gen post_paris_lenergy_intensity_1 =post_paris*L.lenergy_intensity_1

capture drop post_paris_change_ei
gen post_paris_change_ei =post_paris*L.change_ei


***generate pre paris dummy and interactions
capture drop pre_paris
gen pre_paris = (year <=2016)
tab pre_paris

capture drop pre_paris_lenergy_intensity_1
gen pre_paris_lenergy_intensity_1 =pre_paris*L.lenergy_intensity_1

capture drop pre_paris_change_ei
gen pre_paris_change_ei =pre_paris*L.change_ei




save ${temp}kene_ma_file_E11E14.dta, replace
restore 

capture drop  kene 
capture drop kene_m3  
capture drop energy_intensity_1
capture drop  lenergy_intensity_1 
capture drop change_ei
capture drop  post_paris 
capture drop post_paris_lenergy_intensity_1
capture drop  post_paris_change_ei
capture drop change_ei_nolog
capture drop  pre_paris 
capture drop pre_paris_lenergy_intensity_1
capture drop  pre_paris_change_ei

merge m:1 firmid year using ${temp}kene_ma_file_E11E14.dta
capture drop _merge

tab year if year>2016 & !missing(kene)
tab year if year>2016 & missing(kene)


/*
***merge with NUTS3 location code

preserve 
use ${data}NUT3_KOM_crosswalk_2010_clean.dta, clear

gen jur_bel_kom_kode = LAU1_NAT_CODE

duplicates drop jur_bel_kom_kode, force

save ${temp}NUT3_KOM_formerge.dta, replace


restore 



merge m:1 jur_bel_kom_kode using ${temp}NUT3_KOM_formerge.dta
drop if _merge ==2
capture drop _merge
*/
****tssset the data
capture program drop meany
program def meany, rclass
args var spec
sum `var' if e(sample), mean
estadd scalar Meany=r(mean)
end

tsset id year



***********************Baseline fixed effect groups*******************

**gen size groups
capture drop size_q
xtile size_q =lassets, nq(5)



***Baseline: industry(naces2)*location(nuts2)*size(5)*year
capture drop ILST
egen ILST = group(ind2 jur_bel_region_kode size_q year)



********************within industry analysis****************************
*********************Online Appendix TABLE E.11************************************
*********************Online Appendix TABLE E.11************************************
*********************Online Appendix TABLE E.11************************************
capture drop relative_ei_indyear
local var "lenergy_intensity_1"

** collapse by industry to obtain the mean and sd of the industry sample 
capture drop _merge
foreach  v in `var'{
preserve	
collapse (mean) mean_`v' =`v' (sd) sd_`v'  = `v', by(ind2 year) 
save ${temp}collapse_E11E14_`v', replace
restore
capture drop _merge
capture drop mean_`v' sd_`v'
merge m:1 ind2 year using ${temp}collapse_E11E14_`v'
sort ind2 year
gen relative_ei_indyear = (`v'-mean_`v')/sd_`v'
}
su  relative_ei_indyear, det

gen l_relative_ei_indyear = log(relative_ei_indyear) //Log of relative measure

***construct pre and post dummy interations
capture drop _merge

preserve
collapse (mean) relative_ei_indyear l_relative_ei_indyear post_paris pre_paris, by(firmid year)

sort firmid year
duplicates drop firmid year, force

xtset firmid year
capture drop  post_relative_ei_indyear
gen post_relative_ei_indyear =post_paris*L.relative_ei_indyear

capture drop  pre_relative_ei_indyear
gen pre_relative_ei_indyear =pre_paris*L.relative_ei_indyear

capture drop change_relative_ei_indyear
gen change_relative_ei_indyear= relative_ei_indyear - L.relative_ei_indyear

capture drop post_change_relative_ei_indyear
gen post_change_relative_ei_indyear =post_paris*L.change_relative_ei_indyear

capture drop pre_change_relative_ei_indyear
gen pre_change_relative_ei_indyear =pre_paris*L.change_relative_ei_indyear

save ${temp}relative_ei_E11E14, replace

restore

capture drop  post_relative_ei_indyear
capture drop  pre_relative_ei_indyear
capture drop change_relative_ei_indyear
capture drop pre_change_relative_ei_indyear
capture drop post_change_relative_ei_indyear

merge m:1 firmid year using ${temp}relative_ei_E11E14




tsset id year





reghdfe  l_balance    pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear  $cntrl1_l,  absorb(cvrnr  bank_year ILST)  cluster(ind2)
estimates store model7
meany l_balance   model7


capture drop esample
gen esample = e(sample)
distinct cvrnr cvrnr_b year if esample==1


reghdfe loan_growth  pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear $cntrl1_l,   absorb(cvrnr  bank_year ILST) cluster(ind2)
estimates store model8
meany  loan_growth   model8



reghdfe ext_l_loan   pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear  $cntrl1_l,   absorb(cvrnr  bank_year ILST)  cluster(ind2)
estimates store model9
meany ext_l_loan   model9


esttab  model7 model8 model9 using ${exports}within_industry_analysis_fullsample_prepost_ilst_age_E11E14.txt, replace style(tab) cells(b(star fmt(%9.3f)) se(par fmt(%9.3f))) label stats( r2 N, fmt( %9.3f %9.0fc) labels("R-sq" "N" )) starlevels(* 0.10 ** 0.05 *** 0.01)   keep(pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear lag_lassets_w  lag_fixed_ratio_w lag_leverage_ratio_w lag_roa_w lag_age_above_median lag_age_observed) order(pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear lag_lassets_w  lag_fixed_ratio_w lag_leverage_ratio_w lag_roa_w lag_age_above_median lag_age_observed)



**********regression within brown and non brown industry***********************

************************************************************************************
***clean the industry emission level data and generate brown dummies
************************************************************************************
***generate brown dummy based on scope 1 emission 

preserve
use ${data}transition_risk_v2.dta, replace
tsset ind2 year
capture drop emission_intensity

*deflator (statistik banken: pris112)
gen deflator=.
replace deflator=81.6 if year==2003
replace deflator=82.5 if year==2004
replace deflator=84 if year==2005
replace deflator=85.6 if year==2006
replace deflator=87.1 if year==2007
replace deflator=90.1 if year==2008
replace deflator=91.2 if year==2009
replace deflator=93.3 if year==2010
replace deflator=95.9 if year==2011
replace deflator=98.2 if year==2012
replace deflator=99 if year==2013
replace deflator=99.6 if year==2014
replace deflator=100 if year==2015
replace deflator=100.3 if year==2016
replace deflator=101.4 if year==2017
replace deflator=102.2 if year==2018
replace deflator=103 if year==2019
replace deflator = deflator/100


gen rva_detailed = gva_detailed/deflator 

gen emission_intensity=GHG_total/rva_detailed
label variable emission_intensity "GHG_total/rva_detailed"
su emission_intensity, det



capture drop  brown  
capture drop non_brown
su emission_intensity, det
gen brown = (emission_intensity>= r(p75))
replace brown= . if emission_intensity ==.
tab ind2label if brown ==1



capture drop brown_tradition
gen brown_tradition = .
replace brown_tradition=1 if ind2==5
replace brown_tradition=1 if ind2==6
replace brown_tradition=1 if ind2==7
replace brown_tradition=1 if ind2==8
replace brown_tradition=1 if ind2==9
replace brown_tradition=1 if ind2==19
replace brown_tradition=1 if ind2==35
replace brown_tradition=1 if ind2==20
replace brown_tradition=1 if ind2==23
replace brown_tradition=1 if ind2==24
replace brown_tradition=1 if ind2==49
replace brown_tradition=1 if ind2==50
replace brown_tradition=1 if ind2==51
replace brown_tradition=0 if  brown_tradition == .
tab ind2label if brown_tradition ==1


save  ${temp}transition_risk_E11E14.dta, replace
restore



capture drop _merge
capture drop emission_intensity 
capture drop  change_ei_ind
capture drop  brown  
capture drop non_brown
capture drop rva_detailed
capture drop brown_tradition
merge m:1 ind2 year using ${temp}transition_risk_E11E14.dta
drop if _merge ==2
capture drop _merge 

replace brown=0 if missing(brown)
replace brown_tradition=0 if missing(brown_tradition)


************************************************************************************
*regression within brown industry
*********************Online Appendix TABLE E.12************************************
*********************Online Appendix TABLE E.12************************************
*********************Online Appendix TABLE E.12************************************
tsset id year



reghdfe  l_balance    pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear  $cntrl1_l if brown==1,  absorb(cvrnr  bank_year ILST)  cluster(ind2)
estimates store model7
meany l_balance   model7



reghdfe loan_growth  pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear $cntrl1_l if brown==1,   absorb(cvrnr  bank_year ILST) cluster(ind2)
estimates store model8
meany  loan_growth   model8



reghdfe ext_l_loan   pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear  $cntrl1_l if brown==1,   absorb(cvrnr  bank_year ILST)  cluster(ind2)
estimates store model9
meany ext_l_loan   model9


esttab   model7 model8 model9 using ${exports}within_industry_analysis_fullsample_prepost_brown_ilst_age_E11E14.txt, replace style(tab) cells(b(star fmt(%9.3f)) se(par fmt(%9.3f))) label stats( r2 N, fmt( %9.3f %9.0fc) labels("R-sq" "N" )) starlevels(* 0.10 ** 0.05 *** 0.01)   keep(pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear lag_lassets_w  lag_fixed_ratio_w lag_leverage_ratio_w lag_roa_w lag_age_above_median lag_age_observed) order(pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear lag_lassets_w  lag_fixed_ratio_w lag_leverage_ratio_w lag_roa_w lag_age_above_median lag_age_observed)




************************************************************************************
****non brown
*********************Online Appendix TABLE E.13************************************
*********************Online Appendix TABLE E.13************************************
*********************Online Appendix TABLE E.13************************************
tsset id year



reghdfe  l_balance    pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear  $cntrl1_l if brown==0,  absorb(cvrnr  bank_year ILST)  cluster(ind2)
estimates store model7
meany l_balance   model7



reghdfe loan_growth  pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear $cntrl1_l if brown==0,   absorb(cvrnr  bank_year ILST) cluster(ind2)
estimates store model8
meany  loan_growth   model8



reghdfe ext_l_loan   pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear  $cntrl1_l if brown==0,   absorb(cvrnr  bank_year ILST)  cluster(ind2)
estimates store model9
meany ext_l_loan   model9


esttab   model7 model8 model9 using ${exports}within_industry_analysis_fullsample_prepost_nonbrown_ilst_age_E11E14.txt, replace style(tab) cells(b(star fmt(%9.3f)) se(par fmt(%9.3f))) label stats( r2 N, fmt( %9.3f %9.0fc) labels("R-sq" "N" )) starlevels(* 0.10 ** 0.05 *** 0.01)   keep(pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear lag_lassets_w  lag_fixed_ratio_w lag_leverage_ratio_w lag_roa_w lag_age_above_median lag_age_observed) order(pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear lag_lassets_w  lag_fixed_ratio_w lag_leverage_ratio_w lag_roa_w lag_age_above_median lag_age_observed)







*********************Online Appendix TABLE E.14************************************
*********************Online Appendix TABLE E.14************************************
*********************Online Appendix TABLE E.14************************************

******between industry analysis, include rva growth using LST FEs****************
***construct industry level energy intensity variables
capture drop  ind_energy_intensity
capture drop ind_kene
capture drop  l_ind_energy_intensity 
capture drop emission_intensity_1000
preserve

collapse (mean) kene ind2 rva_detailed pre_paris post_paris emission_intensity, by(firmid year)

sort firmid year
duplicates drop firmid year, force


****generate industry energy intensity and its interactions
bysort ind2 year: egen ind_kene = sum(kene)   
replace ind_kene = ind_kene/1000    //convert to per dkk as  kene is in thousand

xtset firmid year

gen ind_energy_intensity= ind_kene/rva_detailed
label var  ind_energy_intensity "ind_kene/rva_detailed"
su ind_energy_intensity, det

capture drop l_ind_energy_intensity 
gen l_ind_energy_intensity = log(ind_energy_intensity)

capture drop pre_ind_energy_intensity 
gen pre_ind_energy_intensity = pre_paris*L.l_ind_energy_intensity 


capture drop post_ind_energy_intensity 
gen post_ind_energy_intensity = post_paris*L.l_ind_energy_intensity 


capture drop  change_ind_energy_int
gen  change_ind_energy_int= l_ind_energy_intensity-L.l_ind_energy_intensity
su change_ind_energy_int, det

capture drop  change_ind_energy_int_nolog
gen  change_ind_energy_int_nolog= ind_energy_intensity-L.ind_energy_intensity

capture drop pre_change_ind_energy_int
gen pre_change_ind_energy_int= pre_paris*L.change_ind_energy_int


capture drop post_change_ind_energy_int
gen post_change_ind_energy_int= post_paris*L.change_ind_energy_int



****generate industry emission intensity and its interactions
capture drop emission_intensity_1000
gen emission_intensity_1000 = 1000*emission_intensity


capture drop l_ind_emission_intensity 
gen l_ind_emission_intensity  = log(emission_intensity_1000)

capture drop pre_ind_emission_intensity 
gen pre_ind_emission_intensity  = pre_paris*L.l_ind_emission_intensity  


capture drop post_ind_emission_intensity 
gen post_ind_emission_intensity = post_paris*L.l_ind_emission_intensity 


capture drop  change_ind_emission_int
gen  change_ind_emission_int= l_ind_emission_intensity-L.l_ind_emission_intensity 
su change_ind_emission_int, det

capture drop  change_ind_emission_int_nolog
gen  change_ind_emission_int_nolog= emission_intensity_1000-L.emission_intensity_1000


capture drop pre_change_ind_emission_int
gen pre_change_ind_emission_int= pre_paris*L.change_ind_emission_int


capture drop post_change_ind_emission_int
gen post_change_ind_emission_int= post_paris*L.change_ind_emission_int



capture drop rva_growth 
gen rva_growth = (rva_detailed-L.rva_detailed)/(0.5*rva_detailed+0.5*L.rva_detailed)
su rva_growth


save ${temp}ind_energy_intensity_E11E14.dta, replace

restore

capture drop ind_energy_intensity 
capture drop l_ind_energy_intensity 
capture drop pre_ind_energy_intensity 
capture drop post_ind_energy_intensity  
capture drop change_ind_energy_int 
capture drop pre_change_ind_energy_int 
capture drop post_change_ind_energy_int

capture drop pre_ind_emission_intensity 
capture drop post_ind_emission_intensity  
capture drop change_ind_emission_int 
capture drop pre_change_ind_emission_int 
capture drop post_change_ind_emission_int

capture drop  change_ind_emission_int_nolog
capture drop  change_ind_energy_int_nolog_int_nolog
capture drop rva_growth

merge m:1 firmid year using ${temp}ind_energy_intensity_E11E14.dta

capture drop _merge

xtset id year

global cntrl_ind_f "lag_lassets_w  lag_fixed_ratio_w lag_leverage_ratio_w lag_roa_w lag_age_above_median lag_age_observed   rva_growth" 


**generate LST FEs
capture drop LST
egen LST = group(jur_bel_region_kode size_q year)




reghdfe l_balance pre_ind_emission_intensity pre_ind_energy_intensity    pre_change_ind_emission_int pre_change_ind_energy_int post_ind_emission_intensity post_ind_energy_intensity post_change_ind_emission_int post_change_ind_energy_int  $cntrl_ind_f,  absorb(cvrnr  bank_year ind2 LST)  cluster(ind2)
estimates store model7
meany l_balance   model7



reghdfe loan_growth  pre_ind_emission_intensity pre_ind_energy_intensity    pre_change_ind_emission_int pre_change_ind_energy_int post_ind_emission_intensity post_ind_energy_intensity post_change_ind_emission_int post_change_ind_energy_int  $cntrl_ind_f,  absorb(cvrnr  bank_year ind2 LST)  cluster(ind2)
estimates store model8
meany  loan_growth    model8



reghdfe ext_l_loan  pre_ind_emission_intensity pre_ind_energy_intensity    pre_change_ind_emission_int pre_change_ind_energy_int post_ind_emission_intensity post_ind_energy_intensity post_change_ind_emission_int post_change_ind_energy_int  $cntrl_ind_f,  absorb(cvrnr  bank_year ind2 LST)  cluster(ind2)
estimates store model9
meany ext_l_loan   model9



esttab    model7 model8 model9 using ${exports}between_industry_analysis1_fullsample_prepost_lst_age_E11E14.txt, replace style(tab) cells(b(star fmt(%9.3f)) se(par fmt(%9.3f))) label stats( r2 N, fmt( %9.3f %9.0fc) labels( "R-sq" "N" )) starlevels(* 0.10 ** 0.05 *** 0.01)   keep(pre_ind_emission_intensity pre_ind_energy_intensity    pre_change_ind_emission_int pre_change_ind_energy_int post_ind_emission_intensity post_ind_energy_intensity post_change_ind_emission_int post_change_ind_energy_int  $cntrl_ind_f) order(pre_ind_emission_intensity pre_ind_energy_intensity    pre_change_ind_emission_int pre_change_ind_energy_int post_ind_emission_intensity post_ind_energy_intensity post_change_ind_emission_int post_change_ind_energy_int  $cntrl_ind_f) 



log close
