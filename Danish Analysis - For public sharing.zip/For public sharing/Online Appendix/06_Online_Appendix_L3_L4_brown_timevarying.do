********************************************************************************
* Online Appendix Tables L.3-L.4: time-varying dirty-industry thresholds
* run "${do}Online Appendix/06_Online_Appendix_L3_L4_brown_timevarying.do"

********************************************************************************
/*
INPUT:
    ${data}firm_credit_full.dta
    ${data}transition_risk_v2.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}within_industry_analysis_fullsample_prepost_brown_timevarying_L3L4.txt
        -> Online Appendix Table L.3
    ${exports}within_industry_analysis_fullsample_prepost_nonbrown_timevarying_L3L4.txt
        -> Online Appendix Table L.4

LOG:
    ${logs}use_data_reg_full_sample_revision_brown_timevarying_L3L4.log

*/


capture log close
log using ${logs}use_data_reg_full_sample_revision_brown_timevarying_L3L4.log, replace
set scheme lean1

global cntrl1_l "lag_lassets_w lag_fixed_ratio_w lag_leverage_ratio_w lag_roa_w " 
global cntrl1 "lassets_w  fixed_ratio_w leverage_ratio_w   roa_w" 



use  ${data}firm_credit_full.dta, clear

* Same sample rule and timing as baseline; missing size remains included.
keep if f_size >=2
sort cvrnr cvrnr_b year

**********************further data cleaning before regression***********************
**generate dummy bank_id for NEVER firms
destring cvrnr, gen(firmid)
destring cvrnr_b, gen(bankid)

replace bankid =0 if missing(bankid)


***generate firm bank id
capture drop id
egen id = group(firmid  bankid)
format id %19.9g
distinct id  

***generate bank year fixed dummies
capture drop bank_year
egen bank_year = group(bankid year)
format bank_year %19.9g
distinct bank_year  

****construct industry fixed dummies 
replace ind2 =0 if missing(ind2)
capture drop ind2year
egen ind2year= group(ind2 year)
format   ind2year %19.9g


************generate loan outcome vars*********

**fill in zeros and compute log(balance) as l_balance
**fill in zeros 
capture drop nonmissing_balance
gen nonmissing_balance = account_balance
replace nonmissing_balance=0 if missing(account_balance)
capture drop l_balance
gen l_balance= 0
replace l_balance= log(nonmissing_balance) if  nonmissing_balance>0



**log change as growth in 100%
sort firmid bankid year
xtset id year
capture drop l_loan_change
gen l_loan_change = l_balance-l.l_balance  
replace l_loan_change=l_loan_change*100



***alternative definitions: gen loan growth using symmetric growth by taking into account 0
capture drop loan_change
gen loan_change = nonmissing_balance-l.nonmissing_balance

capture drop loan_growth
gen loan_growth = loan_change/(0.5*nonmissing_balance+0.5*l.nonmissing_balance)*100

su loan_growth  l_loan_change l_balance, det



***generate extensive margin variables
capture drop ext_l_loan
gen ext_l_loan = 0
replace ext_l_loan =1 if loan_change>0 & loan_change !=.
tab ext_l_loan 


***fill in zeros for missing vars of loan outcomes
foreach i of varlist  l_balance loan_growth ext_l_loan l_loan_change{
	replace  `i' =0 if missing(`i') 
}


***winsorizing outliers for controls
winsor2  lassets  fixed_ratio leverage_ratio, cuts(1 99) 
winsor2  roa, cuts(1 99) 


***scale leverage ratio by 100 // ration in percentage points
replace leverage_ratio_w = leverage_ratio_w*100
replace roa_w = roa_w*100
replace fixed_ratio_w =  fixed_ratio_w*100

***construct firm-level lags using firm-year panel

preserve

keep firmid year lassets_w  fixed_ratio_w leverage_ratio_w roa_w

duplicates drop
isid firmid year
xtset firmid year

foreach v in lassets_w  fixed_ratio_w leverage_ratio_w roa_w{
	gen lag_`v'=L.`v'
}

keep firmid year lag_*

save  ${temp}firm_controls_lag_L3L4.dta, replace
restore 

merge m:1 firmid year using ${temp}firm_controls_lag_L3L4.dta, keepusing(lag_lassets_w  lag_fixed_ratio_w lag_leverage_ratio_w lag_roa_w) assert(match) nogen

*restore firm-bank panel for loan outcomes

xtset id year



************generate energy intensity variables**********************
*** energy_intensity_1, lenergy_intensity_1, change of energy intensity

***use moving average of energy consumption (kene) after 2016
preserve

collapse (first) kene vtv, by(firmid year)
xtset firmid year
tsegen kene_m3 = rowmean(L(0/4).kene)
replace kene = kene_m3 if year >2016 & missing(kene)

capture drop energy_intensity_1
gen energy_intensity_1 = kene/(vtv/1000000) 
label var energy_intensity_1 "firm level energy purchase per million DKK value added:kene/(vtv/1000000)"

capture drop lenergy_intensity_1
gen lenergy_intensity_1= log(energy_intensity_1)

capture drop change_ei
gen change_ei= lenergy_intensity_1-L.lenergy_intensity_1



capture drop change_ei_nolog //for summary stats
gen change_ei_nolog= energy_intensity_1-L.energy_intensity_1

***generate post paris dummy and interactions
capture drop post_paris
gen post_paris = (year >2016)
tab post_paris

tsset firmid year
capture drop post_paris_lenergy_intensity_1
gen post_paris_lenergy_intensity_1 =post_paris*L.lenergy_intensity_1

capture drop post_paris_change_ei
gen post_paris_change_ei =post_paris*L.change_ei


***generate pre paris dummy and interactions
capture drop pre_paris
gen pre_paris = (year <=2016)
tab pre_paris

capture drop pre_paris_lenergy_intensity_1
gen pre_paris_lenergy_intensity_1 =pre_paris*L.lenergy_intensity_1

capture drop pre_paris_change_ei
gen pre_paris_change_ei =pre_paris*L.change_ei




save ${temp}kene_ma_file_L3L4.dta, replace
restore 

capture drop kene
capture drop kene_m3
capture drop energy_intensity_1
capture drop lenergy_intensity_1
capture drop change_ei
capture drop post_paris
capture drop post_paris_lenergy_intensity_1
capture drop post_paris_change_ei
capture drop change_ei_nolog
capture drop pre_paris
capture drop pre_paris_lenergy_intensity_1
capture drop pre_paris_change_ei

merge m:1 firmid year using ${temp}kene_ma_file_L3L4.dta, assert(match)
capture drop _merge

****tssset the data
capture program drop meany
program def meany, rclass
args var spec
sum `var' if e(sample), mean
estadd scalar Meany=r(mean)
end

tsset id year





**gen size groups
capture drop size_q
xtile size_q =lassets, nq(5)


***baseline: industry(naces2)*location(nuts2)*size(5)*year
capture drop ILST
egen ILST = group(ind2 jur_bel_region_kode size_q year)




********************within industry analysis****************************

capture drop relative_ei_indyear
local var "lenergy_intensity_1"

** collapse by industry to obtain the mean and sd of the industry sample 
capture drop _merge
foreach  v in `var'{
preserve	
collapse (mean) mean_`v' =`v' (sd) sd_`v'  = `v', by(ind2 year) 
save ${temp}collapse_L3L4_`v', replace
restore
capture drop _merge
capture drop mean_`v'
capture drop sd_`v'
merge m:1 ind2 year using ${temp}collapse_L3L4_`v', assert(match)
sort ind2 year
gen relative_ei_indyear = (`v'-mean_`v')/sd_`v'
}
su  relative_ei_indyear, det

gen l_relative_ei_indyear = log(relative_ei_indyear) //Log of relative measure

***construct pre and post dummy interations
capture drop _merge

preserve
collapse (mean) relative_ei_indyear l_relative_ei_indyear post_paris pre_paris, by(firmid year)

sort firmid year
isid firmid year

xtset firmid year
capture drop post_relative_ei_indyear
gen post_relative_ei_indyear =post_paris*L.relative_ei_indyear

capture drop pre_relative_ei_indyear
gen pre_relative_ei_indyear =pre_paris*L.relative_ei_indyear

capture drop change_relative_ei_indyear
gen change_relative_ei_indyear= relative_ei_indyear - L.relative_ei_indyear

capture drop post_change_relative_ei_indyear
gen post_change_relative_ei_indyear =post_paris*L.change_relative_ei_indyear

capture drop pre_change_relative_ei_indyear
gen pre_change_relative_ei_indyear =pre_paris*L.change_relative_ei_indyear

save ${temp}relative_ei_L3L4, replace

restore

capture drop post_relative_ei_indyear
capture drop pre_relative_ei_indyear

capture drop change_relative_ei_indyear
capture drop pre_change_relative_ei_indyear
capture drop post_change_relative_ei_indyear

merge m:1 firmid year using ${temp}relative_ei_L3L4, assert(match)




tsset id year



***regression within brown/nonbrown industry: using moving threshold***********************

************************************************************************************
***clean the industry emission level data and generate brown dummies
************************************************************************************
***generate brown dummy based on scope 1 emission 

preserve
use ${data}transition_risk_v2.dta, replace
tsset ind2 year
capture drop emission_intensity

*deflator (statistik banken: pris112)
gen deflator=.
replace deflator=81.6 if year==2003
replace deflator=82.5 if year==2004
replace deflator=84 if year==2005
replace deflator=85.6 if year==2006
replace deflator=87.1 if year==2007
replace deflator=90.1 if year==2008
replace deflator=91.2 if year==2009
replace deflator=93.3 if year==2010
replace deflator=95.9 if year==2011
replace deflator=98.2 if year==2012
replace deflator=99 if year==2013
replace deflator=99.6 if year==2014
replace deflator=100 if year==2015
replace deflator=100.3 if year==2016
replace deflator=101.4 if year==2017
replace deflator=102.2 if year==2018
replace deflator=103 if year==2019
replace deflator = deflator/100


gen rva_detailed = gva_detailed/deflator 

gen emission_intensity=GHG_total/rva_detailed
label variable emission_intensity "GHG_total/rva_detailed"
su emission_intensity, det



capture drop brown
capture drop non_brown
** use time-varying definition of brown 
gen brown =.
forvalues i= 2003(1)2019{
su  emission_intensity if  year ==`i', det	
replace brown  =1  if emission_intensity>=r(p75)  &   year ==`i'  & !missing(emission_intensity)
replace brown  =0  if emission_intensity<r(p75)   &  year ==`i' &  !missing(emission_intensity)
}

replace brown= . if emission_intensity ==.
tab ind2label if brown ==1



capture drop brown_tradition
gen brown_tradition = .
replace brown_tradition=1 if ind2==5
replace brown_tradition=1 if ind2==6
replace brown_tradition=1 if ind2==7
replace brown_tradition=1 if ind2==8
replace brown_tradition=1 if ind2==9
replace brown_tradition=1 if ind2==19
replace brown_tradition=1 if ind2==35
replace brown_tradition=1 if ind2==20
replace brown_tradition=1 if ind2==23
replace brown_tradition=1 if ind2==24
replace brown_tradition=1 if ind2==49
replace brown_tradition=1 if ind2==50
replace brown_tradition=1 if ind2==51
replace brown_tradition=0 if  brown_tradition == .
tab ind2label if brown_tradition ==1


save  ${temp}transition_risk_L3L4.dta, replace
restore



capture drop _merge
capture drop emission_intensity
capture drop change_ei_ind
capture drop brown
capture drop non_brown
capture drop rva_detailed
capture drop brown_tradition
merge m:1 ind2 year using ${temp}transition_risk_L3L4.dta
drop if _merge ==2
capture drop _merge

replace brown=0 if missing(brown)
replace brown_tradition=0 if missing(brown_tradition)


************************************************************************************
*regression within brown industry: Online Appendix Table L.3
************************************************************************************
tsset id year


reghdfe  l_balance    pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear  $cntrl1_l if brown==1,  absorb(cvrnr  bank_year ILST)  cluster(ind2)
estimates store model7
meany l_balance   model7



reghdfe loan_growth  pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear $cntrl1_l if brown==1,   absorb(cvrnr  bank_year ILST) cluster(ind2)
estimates store model8
meany  loan_growth   model8



reghdfe ext_l_loan   pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear  $cntrl1_l if brown==1,   absorb(cvrnr  bank_year ILST)  cluster(ind2)
estimates store model9
meany ext_l_loan   model9


esttab   model7 model8 model9 using ${exports}within_industry_analysis_fullsample_prepost_brown_timevarying_L3L4.txt, replace style(tab) cells(b(star fmt(%9.3f)) se(par fmt(%9.3f))) label stats( r2 N, fmt( %9.3f %9.0fc) labels("R-sq" "N" )) starlevels(* 0.10 ** 0.05 *** 0.01)   keep(pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear lag_lassets_w lag_fixed_ratio_w lag_leverage_ratio_w lag_roa_w) order(pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear lag_lassets_w lag_fixed_ratio_w lag_leverage_ratio_w lag_roa_w)



distinct cvrnr cvrnr_b year if e(sample)

************************************************************************************
****non brown: Online Appendix Table L.4
************************************************************************************
tsset id year


reghdfe  l_balance    pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear  $cntrl1_l if brown==0,  absorb(cvrnr  bank_year ILST)  cluster(ind2)
estimates store model7
meany l_balance   model7



reghdfe loan_growth  pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear $cntrl1_l if brown==0,   absorb(cvrnr  bank_year ILST) cluster(ind2)
estimates store model8
meany  loan_growth   model8



reghdfe ext_l_loan   pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear  $cntrl1_l if brown==0,   absorb(cvrnr  bank_year ILST)  cluster(ind2)
estimates store model9
meany ext_l_loan   model9


esttab  model7 model8 model9 using ${exports}within_industry_analysis_fullsample_prepost_nonbrown_timevarying_L3L4.txt, replace style(tab) cells(b(star fmt(%9.3f)) se(par fmt(%9.3f))) label stats( r2 N, fmt( %9.3f %9.0fc) labels("R-sq" "N" )) starlevels(* 0.10 ** 0.05 *** 0.01)   keep(pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear lag_lassets_w lag_fixed_ratio_w lag_leverage_ratio_w lag_roa_w) order(pre_relative_ei_indyear pre_change_relative_ei_indyear post_relative_ei_indyear post_change_relative_ei_indyear lag_lassets_w lag_fixed_ratio_w lag_leverage_ratio_w lag_roa_w)



distinct cvrnr cvrnr_b year if e(sample)







log close





