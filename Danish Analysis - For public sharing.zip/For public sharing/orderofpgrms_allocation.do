********************************************************************************
* Danish analysis-only sharing package
* Resolve xxxxx thresholds in the descriptive script before running it.
* Paths below are placeholders. Run lines remain commented out deliberately.
********************************************************************************
* Set the project root directory before running the scripts.
* Replace the placeholder with local project path.
cd "PATH_TO_PROJECT_DIRECTORY"

global do       "`c(pwd)'/DO/"
global data     "`c(pwd)'/DATA/"
global temp     "`c(pwd)'/DATA/temp/"
global tables   "`c(pwd)'/TABLES/"
global graphs   "`c(pwd)'/GRAPHS/"
global exports  "`c(pwd)'/EXPORTS/"
global logs     "`c(pwd)'/LOGS/"
********************************************************************************
* 04. Descriptive figures and allocation-bin datasets
* SCRIPT: Baseline Analysis/00_use_data_plot_tables_full.do
********************************************************************************
* run "${do}Baseline Analysis/00_use_data_plot_tables_full.do"
/*
INPUT:
    ${data}firm_credit_full.dta
    ${data}transition_risk_v2.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}figure_ei_bar_first3.pdf
        -> Figure 6, left
    ${exports}figure_ei_bar_last3.pdf
        -> Figure 6, right
    ${exports}credit_share_general.pdf
        -> Figure 8
    ${exports}credit_share_within.pdf
        -> Figure 9
    ${exports}credit_share_within_top90.pdf
        -> Online Appendix Figure F.1 
    ${exports}figure_ei_bar_first3_ind.pdf
        -> Figure 7, left
    ${exports}figure_ei_bar_last3_ind.pdf
        -> Figure 7, right
    ${exports}credit_share_between.pdf
        -> Figure 11
    ${exports}credit_share_within_brown.pdf
        -> Figure 10, left
    ${exports}credit_share_within_nonbrown.pdf
        -> Figure 10, right
    ${exports}ei_bin_output_credit_share_combined.pdf
        -> Figure 12
    ${exports}forgraph_table_2003_2009_5bins_general.dta
        -> Figure 13 source data; also input to AR analysis, not a rendered figure
    ${exports}ei_bin_output_credit_share_within_combined.pdf
        -> Appendix Figure B.18
    ${exports}forgraph_table_2003_2009_5bins_within.dta
        -> Figure 13 source data (within-industry); 
    ${exports}ei_bin_output_credit_share_between_combined.pdf
        -> Appendix Figure B.19

LOG:
    ${logs}use_data_plot_tables_full_sample.log

*/

********************************************************************************
* 05. Full-sample baseline regressions and summary statistics
* SCRIPT: Baseline Analysis/01_reg_baseline_prepost_ILST.do
********************************************************************************
* run "${do}Baseline Analysis/01_reg_baseline_prepost_ILST.do"
/*
INPUT:
    ${data}firm_credit_full.dta
    ${data}transition_risk_v2.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}general_analysis_fullsample_prepost_ilst_nuts2size5.txt
        -> Online Appendix Table B.2 
    ${exports}within_industry_analysis_fullsample_prepost_ilst_nuts2size5.txt
        -> Appendix Table B.14
    ${exports}within_industry_analysis_fullsample_prepost_brown_ilst_nuts2size5.txt
        -> Appendix Table B.15
    ${exports}within_industry_analysis_fullsample_prepost_nonbrown_ilst_nuts2size5.txt
        -> Appendix Table B.16
    ${data}ind_energy_intensity_full.dta
        -> Intermediate data for industry analysis and Table M.8
    ${exports}between_industry_analysis1_fullsample_prepost_lst.txt
        -> Appendix Table B.18
    ${exports}stats_main_fullsample_nolog_ilst.txt
        -> Appendix Table B.10

SHARED INTERMEDIATE OUTPUTS:
    ${temp}firm_controls_lag.dta
    ${temp}kene_ma_file.dta
    ${temp}relative_ei.dta
    ${temp}transition_risk_v2.dta

LOG:
    ${logs}use_data_reg_full_sample_prepost_ILST.log

*/

********************************************************************************
* 06. Incumbent and entrant indicators
* SCRIPT: Baseline Analysis/02a_create_entrant_incumbent_for_relationship_change.do
********************************************************************************
* run "${do}Baseline Analysis/02a_create_entrant_incumbent_for_relationship_change.do"
/*
INPUT:
    ${data}firm_credit_full.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${temp}incumbent.dta
        -> Intermediate dataset
    ${temp}new_entrants.dta
        -> Intermediate dataset

LOG:
    ${logs}create_entrant_incumbent_for_relationship_change.log

DEPENDENCIES / NOTES:
    Run BEFORE the relationship baseline and Online Appendix C.14
*/

********************************************************************************
* 07. Same-year covariates for balanced observations
* SCRIPT: Baseline Analysis/02b_patch_balanced_covariates.do
********************************************************************************
* run "${do}Baseline Analysis/02b_patch_balanced_covariates.do"
/*
INPUT:
    ${data}firm_credit_full.dta
    ${data}balanced_firm_credit_full.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${data}balanced_firm_credit_full_covfix.dta
        -> Intermediate dataset; 
LOG:
    ${logs}balanced_covariates_covfix.log

DEPENDENCIES / NOTES:
    Run AFTER data setup and BEFORE the relationship baseline and C.14.
    Fills missing covariates from the same firm-year only; no loan changes.
    
*/

********************************************************************************
* 08. Balanced relationship baseline
* SCRIPT: Baseline Analysis/02_reg_relationship_change_full_prepost_ILST.do
********************************************************************************
* run "${do}Baseline Analysis/02_reg_relationship_change_full_prepost_ILST.do"
/*
INPUT:
    ${data}balanced_firm_credit_full_covfix.dta
    ${temp}kene_ma_file.dta
    ${temp}relative_ei
    ${temp}incumbent.dta
    ${temp}new_entrants.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}within_industry_analysis_relations_balanced_all_prepost_ilst_covfix.txt
        -> Appendix Table B.17: 

LOG:
    ${logs}use_data_regs_relationship_full_prepost_ILST_covfix.log

DEPENDENCIES / NOTES:
    Requires baseline, 02a and 02b above. Reads the covfix balanced file.
*/

********************************************************************************
* 09. Industry emissions and energy comparisons
* SCRIPT: Baseline Analysis/03_industry_emissions_energy intensity.do
********************************************************************************
* run "${do}Baseline Analysis/03_industry_emissions_energy intensity.do"
/*
INPUT:
    ${data}ind_energy_intensity_full.dta
    ${data}transition_risk_v2.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}ind_energy_emission_correlation.txt
        -> Appendix Table B.11
    ${exports}ind_energy_emission_correlation_after2016.txt
        -> Post-2016 comparison; 
    ${data}ind_emission_energy_intensity_full.dta
        -> Intermediate data required by G.1
    ${exports}figure_ei_egi_trend.pdf
        -> Figure 5

LOG:
    ${logs}use_data_reg_revision.log


*/

********************************************************************************
* 10. Passive and active credit reallocation: AR specifications
* SCRIPT: Baseline Analysis/04_passive_active_credit_reallocation.do
********************************************************************************
* run "${do}Baseline Analysis/04_passive_active_credit_reallocation.do"
/*
INPUT:
    ${exports}forgraph_table_2003_2009_5bins_general.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}ar1.tex
        -> AR(1) supporting table; Table B.12
    ${exports}ar2.tex
        -> AR(2) supporting table; Table B.12

LOG:
    ${logs}passive_active_analysis.log

*/

********************************************************************************
*****Online Appendix
*****Online Appendix
*****Online Appendix
********************************************************************************
* 11. Without ILST: within-industry regressions
* SCRIPT: Online Appendix/01_Online_Appendix_C10_C13_without_ILST.do
********************************************************************************
* run "${do}Online Appendix/01_Online_Appendix_C10_C13_without_ILST.do"
/*
INPUT:
    ${data}firm_credit_full.dta
    ${data}transition_risk_v2.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}within_industry_analysis_fullsample_prepost_C10C13.txt
        -> Online Appendix Table C.10
    ${exports}within_industry_analysis_fullsample_prepost_brown_C10C13.txt
        -> Online Appendix Table C.11
    ${exports}within_industry_analysis_fullsample_prepost_nonbrown_C10C13.txt
        -> Online Appendix Table C.13
    ${exports}within_industry_analysis_fullsample_prepost_tradbrown_C10C13.txt
        -> Appendix Table C.12

LOG:
    ${logs}use_data_reg_full_sample_prepost_C10C13.log
*/

********************************************************************************
* 12. Without ILST: relationship regressions
* SCRIPT: Online Appendix/02_Online_Appendix_C14_without_ILST.do
********************************************************************************
* run "${do}Online Appendix/02_Online_Appendix_C14_without_ILST.do"
/*
INPUT:
    ${data}balanced_firm_credit_full_covfix.dta
    ${temp}kene_ma_file.dta
    ${temp}relative_ei
    ${temp}incumbent.dta
    ${temp}new_entrants.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}within_industry_analysis_relations_balanced_full_prepost_C14.txt
        -> Online Appendix Table C.14

LOG:
    ${logs}use_data_regs_relationship_full_prepost_C14.log

DEPENDENCIES / NOTES:
    Requires baseline shared files plus 02a/02b; 
*/

********************************************************************************
* 13. Alternative location: NUTS3
* SCRIPT: Online Appendix/09_Online_Appendix_D15D16_NUTS3.do
********************************************************************************
* run "${do}Online Appendix/09_Online_Appendix_D15D16_NUTS3.do"
/*
INPUT:
    ${data}firm_credit_full.dta
    ${data}NUT3_KOM_crosswalk_2010_clean.dta
    ${data}transition_risk_v2.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}Table_D15_general_NUTS3.txt
        -> Online Appendix Table D.15
    ${exports}Table_D16_within_all_NUTS3.txt
        -> Online Appendix Table D.16, full sample
    ${exports}Table_D16_within_brown_NUTS3.txt
        -> Online Appendix Table D.16, dirty industries
    ${exports}Table_D16_within_nonbrown_NUTS3.txt
        -> Online Appendix Table D.16, non-dirty industries

LOG:
    ${logs}Online_Appendix_D15D16_NUTS3.log
*/

********************************************************************************
* 14. Alternative location: municipality
* SCRIPT: Online Appendix/10_Online_Appendix_D17D18_municipality.do
********************************************************************************
* run "${do}Online Appendix/10_Online_Appendix_D17D18_municipality.do"
/*
INPUT:
    ${data}firm_credit_full.dta
    ${data}transition_risk_v2.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}Table_D17_general_municipality.txt
        -> Online Appendix Table D.17
    ${exports}Table_D18_within_all_municipality.txt
        -> Online Appendix Table D.18, full sample
    ${exports}Table_D18_within_brown_municipality.txt
        -> Online Appendix Table D.18, dirty industries
    ${exports}Table_D18_within_nonbrown_municipality.txt
        -> Online Appendix Table D.18, non-dirty industries

LOG:
    ${logs}Online_Appendix_D17D18_municipality.log
*/

********************************************************************************
* 15. Firm-age controls
* SCRIPT: Online Appendix/03_Online_Appendix_E11_E14_firmage.do
********************************************************************************
* run "${do}Online Appendix/03_Online_Appendix_E11_E14_firmage.do"
/*
INPUT:
    ${data}firm_credit_full.dta
    ${data}transition_risk_v2.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}within_industry_analysis_fullsample_prepost_ilst_age_E11E14.txt
        -> Online Appendix Table E.11
    ${exports}within_industry_analysis_fullsample_prepost_brown_ilst_age_E11E14.txt
        -> Online Appendix Table E.12
    ${exports}within_industry_analysis_fullsample_prepost_nonbrown_ilst_age_E11E14.txt
        -> Online Appendix Table E.13
    ${exports}between_industry_analysis1_fullsample_prepost_lst_age_E11E14.txt
        -> Online Appendix Table E.14

LOG:
    ${logs}use_data_reg_full_sample_prepost_ILST_age_E11E14.log
*/

********************************************************************************
* 16. Alternative dirty-industry threshold: top 10 percent
* SCRIPT: Online Appendix/04_Online_Appendix_F3_F4_brown_top10.do
********************************************************************************
* run "${do}Online Appendix/04_Online_Appendix_F3_F4_brown_top10.do"
/*
INPUT:
    ${data}firm_credit_full.dta
    ${data}transition_risk_v2.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}within_industry_analysis_fullsample_prepost_brown_top10_F3F4.txt
        -> Online Appendix Table F.3
    ${exports}within_industry_analysis_fullsample_prepost_nonbrown_top10_F3F4.txt
        -> Online Appendix Table F.4

LOG:
    ${logs}use_data_reg_full_sample_revision_brown_top10_F3F4.log
*/

********************************************************************************
* 17. Alternative post-2016 energy imputation
* SCRIPT: Online Appendix/05_Online_Appendix_G1_alternative_energy_imputation.do
********************************************************************************
* run "${do}Online Appendix/05_Online_Appendix_G1_alternative_energy_imputation.do"
/*
INPUT:
    ${data}ind_emission_energy_intensity_full.dta
    ${data}firm_credit_full.dta
    ${data}transition_risk_v2.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}between_industry_analysis1_fullsample_prepost_lst_altEI_G1.txt
        -> Online Appendix Table G.1

LOG:
    ${logs}use_data_reg_revision_kene_imputation_G1.log

DEPENDENCIES / NOTES:
    Requires the industry-emissions script above. 
*/

********************************************************************************
* 18. Time-varying dirty-industry thresholds
* SCRIPT: Online Appendix/06_Online_Appendix_L3_L4_brown_timevarying.do
********************************************************************************
* run "${do}Online Appendix/06_Online_Appendix_L3_L4_brown_timevarying.do"
/*
INPUT:
    ${data}firm_credit_full.dta
    ${data}transition_risk_v2.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}within_industry_analysis_fullsample_prepost_brown_timevarying_L3L4.txt
        -> Online Appendix Table L.3
    ${exports}within_industry_analysis_fullsample_prepost_nonbrown_timevarying_L3L4.txt
        -> Online Appendix Table L.4

LOG:
    ${logs}use_data_reg_full_sample_revision_brown_timevarying_L3L4.log
*/

********************************************************************************
* 19. EVER-sample robustness
* SCRIPT: Online Appendix/07_Online_Appendix_M1_M7.do
********************************************************************************
* run "${do}Online Appendix/07_Online_Appendix_M1_M7.do"
/*
INPUT:
    ${data}firm_credit_ever.dta
    ${data}transition_risk_v2.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}general_analysis_ever_prepost_M1M7.txt
        -> Online Appendix Table M.2
    ${exports}within_industry_analysis_ever_prepost_M1M7.txt
        -> Online Appendix Table M.3
    ${exports}within_industry_analysis_ever_prepost_brown_M1M7.txt
        -> Online Appendix Table M.4
    ${exports}within_industry_analysis_eversample_prepost_tradbrown_M1M7.txt
        -> Online Appendix Table M.5
    ${exports}within_industry_analysis_ever_prepost_nonbrown_M1M7.txt
        -> Online Appendix Table M.6
    ${exports}between_industry_analysis1_ever_prepost_M1M7.txt
        -> Online Appendix Table M.7
    ${exports}stats_main_eversample_nolog_M1M7.txt
        -> Online Appendix Table M.1

LOG:
    ${logs}use_data_regs_prepost_M1M7.log
*/

********************************************************************************
* 20. Bank loan shares: Figure 16 and Table M.8
* SCRIPT: Online Appendix/08_Figure16_Online_Appendix_M8_bank_ind_level_analysis.do
********************************************************************************
* run "${do}Online Appendix/08_Figure16_Online_Appendix_M8_bank_ind_level_analysis.do"
/*
INPUT:
    ${data}firm_credit_full.dta
    ${temp}kene_ma_file.dta
    ${temp}relative_ei
    ${data}ind_energy_intensity_full.dta
    ${temp}transition_risk_v2.dta

OUTPUT / PAPER CROSS-REFERENCE:
    ${exports}bank_share_green_within_full_prepost_Fig16M8.txt
        -> Online Appendix Table M.8
    ${exports}figure_bank_green_industry_year_fullsample_Fig16M8.pdf
        -> Figure 16, green-industry panel
    ${exports}figure_bank_brown_industry_year_fullsample_Fig16M8.pdf
        -> Figure 16, dirty-industry panel
    ${tables}bank_share_industry_year_fullsample_Fig16M8.txt
        -> Supporting year coefficients for Figure 16; 

LOG:
    ${logs}use_data_regs_bank_ind_share_full_prepost_Fig16M8.log

*/
